<?php

class conn {
    private $conx;
    private $usuario;
    private $pass;
    private $server;
    private $db;

    public function __construct() {
        $this->conx = null;
        $this->usuario = "root"; // Assuming 'root' is your DB user
        $this->pass = ""; // Assuming no password for 'root'
        $this->server = "localhost";
        $this->db = "colegio";
    }

    public function conectar() {
        if ($this->conx === null) {
            $this->conx = new mysqli($this->server, $this->usuario, $this->pass, $this->db);

            if ($this->conx->connect_error) {
                echo "Error conectando a la DB: " . $this->conx->connect_error;
                exit;
            }
        }
    }

    public function desconectar() {
        if ($this->conx) {
            $this->conx->close();
            $this->conx = null;
        }
    }

    public function ejecutarSQL($sql) {
        $this->conectar(); // Ensure connection is established
        $result = $this->conx->query($sql);
        return $result;
    }

    public function ejecutarCommit() {
        $this->conectar(); // Ensure connection is established
        $this->conx->commit();
    }

    public function getConexion() {
        $this->conectar(); // Ensure connection is established
        return $this->conx;
    }

    public function prepare($sql) {
        $this->conectar(); // Ensure connection is established
        return $this->conx->prepare($sql);
    }
}
?>
