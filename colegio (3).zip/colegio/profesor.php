<?php

require_once 'control/profesorcontrol.php';

$controller = new control();
$controller->gestor_procesos();
?>
