
<?php
require_once "libs/smarty-4-5-3/Smarty.class.php";

class config{
    private $smarty;

    public function __construct(){
        $this->smarty = new Smarty();
        $this->set_rutas();
    }

    public function set_rutas(){
        $this->smarty->template_dir = 'view/templates/';
        $this->smarty->compile_dir  = 'view/templates_c/';
        $this->smarty->config_dir   = 'control/configs/';
        $this->smarty->cache_dir    = 'control/cache/';
    }

    public function set_assign($variable,$valor){
       $this->smarty->assign($variable,$valor);
    }
    public function set_display($nombre_archivo){
        $this->smarty->display($nombre_archivo);
    }


}



?>