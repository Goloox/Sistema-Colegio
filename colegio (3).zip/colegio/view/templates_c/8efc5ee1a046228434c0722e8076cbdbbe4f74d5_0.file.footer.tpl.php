<?php
/* Smarty version 4.5.3, created on 2024-06-26 03:30:03
  from 'C:\xampp2\htdocs\progra3\progra3\semana7\view\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_667b6f1bd48112_88906583',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8efc5ee1a046228434c0722e8076cbdbbe4f74d5' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\semana7\\view\\templates\\footer.tpl',
      1 => 1719365325,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_667b6f1bd48112_88906583 (Smarty_Internal_Template $_smarty_tpl) {
?> </body>
</html>
<?php }
}
