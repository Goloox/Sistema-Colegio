<?php
/* Smarty version 4.5.3, created on 2024-08-12 16:46:28
  from 'C:\xampp2\htdocs\progra3\progra3\proyectocorto\view\templates\transfgerenciaexitosa.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66ba2044828ca5_49875652',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '13b17c4a0dfca87ef35da517436e8847dd1b074a' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyectocorto\\view\\templates\\transfgerenciaexitosa.tpl',
      1 => 1723473986,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66ba2044828ca5_49875652 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transferencia Exitosa</title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #121212; /* Tema oscuro */
            color: #ffffff;
        }
        .message-box {
            background-color: #1E1E1E;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
            text-align: center;
            max-width: 600px;
        }
        .message-box h1 {
            color: #4CAF50;
            font-size: 36px;
            margin-bottom: 20px;
        }
        .message-box p {
            font-size: 18px;
            color: #aaaaaa;
        }
        .buttons {
            margin-top: 30px;
        }
        .buttons button {
            padding: 15px 30px;
            border-radius: 5px;
            background-color: #ff9800;
            color: #fff;
            border: none;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-right: 10px;
        }
        .buttons button:hover {
            background-color: #e68a00;
        }
    </style>
</head>
<body>
    <div class="message-box">
        <h1>¡Transferencia Exitosa!</h1>
        <p>La transferencia se ha realizado correctamente.</p>
        <div class="buttons">
       
        </div>
    </div>
</body>
</html>
<?php }
}
