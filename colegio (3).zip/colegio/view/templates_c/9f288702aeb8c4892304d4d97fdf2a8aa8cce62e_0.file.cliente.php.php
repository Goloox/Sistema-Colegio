<?php
/* Smarty version 4.5.3, created on 2024-07-24 07:11:18
  from 'C:\xampp2\htdocs\progra3\progra3\proyecto\ws\soap\cliente.php' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66a08cf652a8e7_83213929',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9f288702aeb8c4892304d4d97fdf2a8aa8cce62e' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyecto\\ws\\soap\\cliente.php',
      1 => 1721797875,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66a08cf652a8e7_83213929 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?php'; ?>



$uri="http://localhost/progra3/progra3/proyecto/ws/soap/";
$url="http://localhost/progra3/progra3/proyecto/ws/soap/server.php";



$cliente = new SoapClient(null,array('location'=>$url,'uri'=>$uri));

//echo $cliente->Saludar();


if(isset($_REQUEST['id_usuario_b'])){

    echo "<br>". $cliente->BorrarUsuario($_REQUEST['id_usuario_b']);

}

//echo "<br>Suma:". $cliente->CalcularSuma(20,34);
//echo "<br>Resta:". $cliente->CalcularResta(20,34);
echo "<br>". $cliente->ListarUsuarios();

<?php echo '?>';
}
}
