<?php
/* Smarty version 4.5.3, created on 2024-07-17 08:38:50
  from 'C:\xampp2\htdocs\progra3\progra3\proyecto\view\templates\homeprofesor.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_669766fa7658e7_82471451',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '82b7dff64ea3d997bfd51f71de6491e13f6481ec' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyecto\\view\\templates\\homeprofesor.tpl',
      1 => 1720951030,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_669766fa7658e7_82471451 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
<head>
<title>W3.CSS Template</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

</style>
</head>
<body class="w3-light-grey">

<!-- Top container -->
<div class="w3-bar w3-top w3-black w3-large" style="z-index:4">
  <button class="w3-bar-item w3-button w3-hide-large w3-hover-none w3-hover-text-light-grey" onclick="w3_open();"><i class="fa fa-bars"></i>  Menu</button>
  <span class="w3-bar-item w3-right">Logo</span>
</div>

<!-- Sidebar/menu -->
<nav class="w3-sidebar w3-collapse w3-white w3-animate-left" style="z-index:3;width:300px;" id="mySidebar"><br>
  <div class="w3-container w3-row">
    <div class="w3-col s4">
      <img src="/w3images/avatar2.png" class="w3-circle w3-margin-right" style="width:46px">
    </div>
    <div class="w3-col s8 w3-bar">
      <span>Welcome, <strong>Mike</strong></span><br>
      <a href="#" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i></a>
      <a href="#" class="w3-bar-item w3-button"><i class="fa fa-user"></i></a>
      <a href="#" class="w3-bar-item w3-button"><i class="fa fa-cog"></i></a>
    </div>
  </div>
  <hr>
  <div class="w3-container">
    <h5>Dashboard</h5>
  </div>
  <div class="w3-bar-block">
    <a href="#" class="w3-bar-item w3-button w3-padding-16 w3-hide-large w3-dark-grey w3-hover-black" onclick="w3_close()" title="close menu"><i class="fa fa-remove fa-fw"></i>  Close Menu</a>
    <a href="#" class="w3-bar-item w3-button w3-padding w3-blue"><i class="fa fa-book fa-fw"></i>  Matricula</a>
    <a href="#" class="w3-bar-item w3-button w3-padding"><i class="fa fa-edit fa-fw"></i>  Editar usuario</a>
    <a href="#" class="w3-bar-item w3-button w3-padding"><i class="fa fa-check fa-fw"></i>  Asistencia</a><br><br>
  </div>
</nav>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:300px;margin-top:43px;">

  <!-- Header -->
  <header class="w3-container" style="padding-top:22px">
    <h5><b><i class="fa fa-dashboard"></i> My Dashboard</b></h5>
  </header>

  <!-- Dashboard content -->
  <div class="w3-container">
    <h2>Sección de Anotaciones</h2>
    <div class="w3-panel w3-border w3-padding">
      <p>Selecciona un estudiante para anotaciones:</p>
      <select id="selectAnotaciones" class="w3-select w3-border">
        <option value="" disabled selected>Elige un estudiante</option>
        <option value="1">Apellido1 Apellido2 Nombre - correo@ejemplo.com</option>
        <option value="2">Apellido1 Apellido2 Nombre - correo@ejemplo.com</option>
        <option value="3">Apellido1 Apellido2 Nombre - correo@ejemplo.com</option>
      </select>
      <p class="w3-margin-top">Aquí puedes agregar tus anotaciones.</p>
      <textarea id="anotacionesTextarea" class="w3-input w3-border" rows="5"></textarea>
      <button class="w3-button w3-blue w3-margin-top" onclick="guardarAnotaciones()">Guardar Anotaciones</button>
    </div>
    
    <h2>Sección de Recordatorios</h2>
    <div class="w3-panel w3-border w3-padding">
      <p>Selecciona un estudiante para recordatorios:</p>
      <select id="selectRecordatorios" class="w3-select w3-border">
        <option value="" disabled selected>Elige un estudiante</option>
        <option value="1">Apellido1 Apellido2 Nombre - correo@ejemplo.com</option>
        <option value="2">Apellido1 Apellido2 Nombre - correo@ejemplo.com</option>
        <option value="3">Apellido1 Apellido2 Nombre - correo@ejemplo.com</option>
      </select>
      <p class="w3-margin-top">Aquí puedes agregar tus recordatorios.</p>
      <textarea id="recordatoriosTextarea" class="w3-input w3-border" rows="5"></textarea>
      <button class="w3-button w3-blue w3-margin-top" onclick="guardarRecordatorios()">Guardar Recordatorios</button>
    </div>
  </div>

  <!-- Footer -->
  <footer class="w3-container w3-padding-16 w3-light-grey">
    <h4>FOOTER</h4>
    <p>Powered by <a href="https://www.w3schools.com/w3css/default.asp" target="_blank">w3.css</a></p>
  </footer>

  <!-- End page content -->
</div>

<?php echo '<script'; ?>
>
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("myOverlay").style.display = "block";
}

function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("myOverlay").style.display = "none";
}

function guardarAnotaciones() {
  var estudiante = document.getElementById("selectAnotaciones").value;
  var anotaciones = document.getElementById("anotacionesTextarea").value;
  console.log("Estudiante seleccionado para anotaciones:", estudiante);
  console.log("Anotaciones guardadas:", anotaciones);
}

function guardarRecordatorios() {
  var estudiante = document.getElementById("selectRecordatorios").value;
  var recordatorios = document.getElementById("recordatoriosTextarea").value;
  console.log("Estudiante seleccionado para recordatorios:", estudiante);
  console.log("Recordatorios guardados:", recordatorios);
}

// Ordenar opciones alfabéticamente
document.addEventListener("DOMContentLoaded", function() {
  ordenarOpcionesAlfabeticamente("selectAnotaciones");
  ordenarOpcionesAlfabeticamente("selectRecordatorios");
});

function ordenarOpcionesAlfabeticamente(selectId) {
  var select = document.getElementById(selectId);
  var options = Array.from(select.options);
  
  options.sort(function(a, b) {
    var textA = a.text.toUpperCase();
    var textB = b.text.toUpperCase();
    if (textA < textB) return -1;
    if (textA > textB) return 1;
    return 0;
  });
  
  // Limpiar y reinsertar opciones ordenadas
  select.innerHTML = "";
  options.forEach(function(option) {
    select.appendChild(option);
  });
}
<?php echo '</script'; ?>
>

</body>
</html>

<?php }
}
