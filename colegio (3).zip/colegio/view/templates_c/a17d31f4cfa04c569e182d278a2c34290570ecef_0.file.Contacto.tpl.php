<?php
/* Smarty version 4.5.3, created on 2024-08-12 16:41:53
  from 'C:\xampp2\htdocs\progra3\progra3\proyectocorto\view\templates\Contacto.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66ba1f31d58151_76340285',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a17d31f4cfa04c569e182d278a2c34290570ecef' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyectocorto\\view\\templates\\Contacto.tpl',
      1 => 1723472644,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66ba1f31d58151_76340285 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacto - Banco Leandro</title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #121212; /* Tema oscuro */
            color: #ffffff;
        }
        .navbar {
            width: 100%;
            background-color: #1E1E1E;
            padding: 15px 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed; /* Fijar el navbar en la parte superior */
            top: 0;
            left: 0;
        }
        .navbar .logo img {
            width: 100px;
            height: auto;
        }
        .navbar ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }
        .navbar ul li {
            margin-left: 20px;
        }
        .navbar ul li a {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 5px;
            background-color: #ff9800;
            color: #ffffff;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }
        .navbar ul li a:hover {
            background-color: #e68a00;
        }
        .content {
            text-align: center;
            padding: 100px 20px 20px; /* Ajustar padding para el navbar fijo */
        }
        .content h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }
        .content p {
            font-size: 18px;
            margin-bottom: 30px;
            color: #aaaaaa;
        }
        table {
            width: 100%;
            max-width: 800px;
            margin: 0 auto;
            border-collapse: collapse;
            background-color: #1E1E1E;
            color: #ffffff;
        }
        table, th, td {
            border: 1px solid #333;
        }
        th, td {
            padding: 15px;
            text-align: left;
        }
        th {
            background-color: #ff9800;
        }
        tr:nth-child(even) {
            background-color: #2c2c2c;
        }
        tr:hover {
            background-color: #333;
        }
    </style>
</head>
<body>

    <div class="navbar">
        <div class="logo">
             <img src="img/logo.png" alt="Banco Leandro">
        </div>
        <ul>
            <li><a href="index.php?accion=Inicio">Inicio</a></li>
            <li><a href="contacto.html">Contacto</a></li>
            <li><a href="#">Cerrar Sesión</a></li>
        </ul>
    </div>
    <div class="content">
        <h1>Datos de Contacto - Banco Leandro</h1>
        <p>A continuación, se detallan los datos de contacto de nuestra sucursal.</p>
        
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Dirección</th>
                    <th>Teléfono</th>
                    <th>Correo Electrónico</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Sucursal Central</td>
                    <td>Avenida Principal, Ciudad</td>
                    <td>+506 1234 5678</td>
                    <td>contacto@bancoleandro.com</td>
                </tr>
                <tr>
                    <td>Sucursal Norte</td>
                    <td>Calle 5, Sector Norte</td>
                    <td>+506 2345 6789</td>
                    <td>norte@bancoleandro.com</td>
                </tr>
                <tr>
                    <td>Sucursal Sur</td>
                    <td>Calle 10, Sector Sur</td>
                    <td>+506 3456 7890</td>
                    <td>sur@bancoleandro.com</td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>
<?php }
}
