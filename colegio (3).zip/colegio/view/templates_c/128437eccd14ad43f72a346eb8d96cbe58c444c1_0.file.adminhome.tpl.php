<?php
/* Smarty version 4.5.3, created on 2024-08-21 02:35:55
  from 'C:\xampp2\htdocs\progra3\progra3\colegio\view\templates\adminhome.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66c5366b527c97_73043849',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '128437eccd14ad43f72a346eb8d96cbe58c444c1' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\view\\templates\\adminhome.tpl',
      1 => 1724200549,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66c5366b527c97_73043849 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio - Administrador</title>
    <link rel="stylesheet" href="path/to/your/css/styles.css">
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #333;
            background-color: #f4f4f4;
        }

        .navbar {
            background-color: #007bff;
            color: #ffffff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        .navbar h1 {
            margin: 0;
            font-size: 1.5em;
        }

        .navbar a {
            color: #ffffff;
            text-decoration: none;
            font-size: 1em;
            padding: 10px 15px;
            transition: background-color 0.3s;
        }

        .navbar a:hover {
            background-color: #0056b3;
            border-radius: 5px;
        }

        .content {
            padding: 80px 20px 20px; /* Space for the fixed navbar */
            text-align: center;
        }

        .content h2 {
            font-size: 2em;
            margin-bottom: 20px;
        }

        .content p {
            font-size: 1.2em;
            color: #666;
        }

        .nav-menu {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 20px;
        }

        .nav-menu a {
            background-color: #007bff;
            color: #ffffff;
            text-decoration: none;
            padding: 15px 25px;
            border-radius: 5px;
            margin: 10px;
            font-size: 1.2em;
            display: block;
            width: 250px;
            text-align: center;
            transition: background-color 0.3s;
        }

        .nav-menu a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>Panel de Administrador</h1>
        <div>
            <!-- Espacio para otros elementos en la barra de navegación si es necesario -->
        </div>
    </div>

    <div class="content">
        <h2>Bienvenido al Sistema de Gestión</h2>
        <p>Utiliza el menú de navegación para acceder a las diferentes secciones de administración y gestionar el colegio de manera efectiva.</p>
    </div>

    <div class="nav-menu">
        <a href="?accion=gestionar_estudiantes">Gestionar Estudiantes</a>
        <a href="?accion=gestionar_profesores">Gestionar Profesores</a>
        <a href="?accion=gestionarasignaturasver">Gestionar Asignaturas</a>
        <a href="?accion=gestionar_clases">Gestionar Clases</a>
    
        <a href="?accion=cerrar_sesion">Cerrar Sesión</a>
    </div>
</body>
</html>
<?php }
}
