<?php
/* Smarty version 4.5.3, created on 2024-07-14 11:58:32
  from 'C:\xampp2\htdocs\progra3\progra3\proyecto\view\templates\homeestudiante.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_6693a148b29582_16626780',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '55e578e8ab1968a5898569e4491f740fa43832b5' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyecto\\view\\templates\\homeestudiante.tpl',
      1 => 1720951109,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6693a148b29582_16626780 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
<head>
<title>W3.CSS Template</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

</style>
</head>
<body class="w3-light-grey">

<!-- Top container -->
<div class="w3-bar w3-top w3-black w3-large" style="z-index:4">
  <button class="w3-bar-item w3-button w3-hide-large w3-hover-none w3-hover-text-light-grey" onclick="w3_open();"><i class="fa fa-bars"></i>  Menu</button>
  <span class="w3-bar-item w3-right">Colegio Santamaria</span>
</div>

<!-- Sidebar/menu -->
<nav class="w3-sidebar w3-collapse w3-white w3-animate-left" style="z-index:3;width:300px;" id="mySidebar"><br>
  <div class="w3-container w3-row">
    <div class="w3-col s4">
        <img src="img/logoescuela.png" alt="Logo del colegio" width="200" height="150">
    </div>
    <div class="w3-col s8 w3-bar">
      <!-- Placeholder for user info -->
    </div>
  </div>
  <hr>
  <div class="w3-container">
    <h5>Dashboard</h5>
  </div>
  <div class="w3-bar-block">
    <a href="#" class="w3-bar-item w3-button w3-padding-16 w3-hide-large w3-dark-grey w3-hover-black" onclick="w3_close()" title="close menu"><i class="fa fa-remove fa-fw"></i>  Close Menu</a>
    <a href="#" class="w3-bar-item w3-button w3-padding w3-blue"><i class="fa fa-book fa-fw"></i>  Matricula</a>
    <a href="#" class="w3-bar-item w3-button w3-padding"><i class="fa fa-edit fa-fw"></i>  Editar usuario</a>
    <a href="#" class="w3-bar-item w3-button w3-padding"><i class="fa fa-check fa-fw"></i>  Asistencia</a><br><br>
  </div>
</nav>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:300px;margin-top:43px;">

  <!-- Header -->
  <header class="w3-container" style="padding-top:22px">
    <h5><b><i class="fa fa-dashboard"></i> My Dashboard</b></h5>
  </header>

  <!-- Dashboard content -->
  <div class="w3-container">
    <h2>Sección de Anotaciones (Comportamiento en Clase)</h2>
    <div class="w3-panel w3-border w3-padding">
      <p>Aquí puedes ver las anotaciones sobre el comportamiento en clase enviadas por los profesores.</p>
      <div class="w3-container w3-border w3-light-grey" style="height:200px; overflow-y:scroll;">
        <!-- Example annotations -->
        <p><strong>Profesor A:</strong> Recuerda revisar el material de la clase 5.</p>
        <p><strong>Profesor B:</strong> Entregar el proyecto final antes del 20 de julio.</p>
      </div>
    </div>
    
    <h2>Sección de Recordatorios</h2>
    <div class="w3-panel w3-border w3-padding">
      <p>Aquí puedes ver los recordatorios enviados por los profesores.</p>
      <div class="w3-container w3-border w3-light-grey" style="height:200px; overflow-y:scroll;">
        <!-- Example reminders -->
        <p><strong>Profesor A:</strong> Reunión el miércoles a las 3 PM.</p>
        <p><strong>Profesor B:</strong> Examen de matemáticas el viernes.</p>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer class="w3-container w3-padding-16 w3-light-grey">
    <h4>FOOTER</h4>
    <p>Powered by <a href="https://www.w3schools.com/w3css/default.asp" target="_blank">w3.css</a></p>
  </footer>

  <!-- End page content -->
</div>

<?php echo '<script'; ?>
>
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("myOverlay").style.display = "block";
}

function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("myOverlay").style.display = "none";
}
<?php echo '</script'; ?>
>

</body>
</html>
<?php }
}
