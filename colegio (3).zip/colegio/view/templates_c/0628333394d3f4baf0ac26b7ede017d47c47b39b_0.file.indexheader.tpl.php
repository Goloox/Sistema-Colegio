<?php
/* Smarty version 4.5.3, created on 2024-07-13 23:17:55
  from 'C:\xampp2\htdocs\progra3\progra3\proyecto\view\templates\indexheader.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_6692ef03ad0628_33594786',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0628333394d3f4baf0ac26b7ede017d47c47b39b' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyecto\\view\\templates\\indexheader.tpl',
      1 => 1720867046,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6692ef03ad0628_33594786 (Smarty_Internal_Template $_smarty_tpl) {
?>



<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Información del Centro</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: white;
        }

        .container {
            display: flex;
            border: 2px solid blue;
            margin: 10px;
            height: calc(100vh - 40px); /* Altura de la pantalla menos margen */
        }

        .sidebar {
            width: 20%;
            display: flex;
            flex-direction: column;
            border-right: 2px solid blue;
            padding: 10px;
            box-sizing: border-box;
            overflow-y: auto;
        }

        .logo, .menu, .login, .register {
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid blue;
            box-sizing: border-box;
        }

        .content {
            flex-grow: 1;
            padding: 10px;
            box-sizing: border-box;
            display: flex;
        }

        .info-section, .photo-section {
            padding: 10px;
            box-sizing: border-box;
        }

        .info-section {
            flex: 3; /* Aumenta el tamaño de esta sección */
        }

        .photo-section {
            flex: 1;
            background-color: #333;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        h2, h3 {
            margin: 0;
            padding-bottom: 10px;
        }

        ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        li {
            padding: 5px 0;
        }

        .login-form input, .register-form input {
            display: block;
            margin: 5px 0;
            padding: 5px;
            width: 100%;
            box-sizing: border-box;
        }

        .login-form button, .register-form button {
            padding: 10px;
            background-color: blue;
            color: white;
            border: none;
            cursor: pointer;
            width: 100%;
            box-sizing: border-box;
        }

        .container-custom {
            max-width: 1200px; /* Ajusta el valor según el ancho deseado */

            <!DOCTYPE html>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Información del Centro</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css">

        }
    </style>
</head><?php }
}
