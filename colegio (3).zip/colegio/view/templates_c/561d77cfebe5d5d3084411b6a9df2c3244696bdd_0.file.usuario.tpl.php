<?php
/* Smarty version 4.5.3, created on 2024-08-12 16:39:48
  from 'C:\xampp2\htdocs\progra3\progra3\proyectocorto\view\templates\usuario.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66ba1eb4d00b04_15079932',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '561d77cfebe5d5d3084411b6a9df2c3244696bdd' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyectocorto\\view\\templates\\usuario.tpl',
      1 => 1723473585,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66ba1eb4d00b04_15079932 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Información del Usuario</title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #121212; /* Tema oscuro */
            color: #ffffff;
        }
        .navbar {
            width: 100%;
            background-color: #1E1E1E;
            padding: 15px 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed; /* Fijar el navbar en la parte superior */
            top: 0;
            left: 0;
        }
        .navbar .logo img {
            width: 100px;
            height: auto;
        }
        .navbar ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }
        .navbar ul li {
            margin-left: 20px;
        }
        .navbar ul li a {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 5px;
            background-color: #ff9800;
            color: #ffffff;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }
        .navbar ul li a:hover {
            background-color: #e68a00;
        }
        .content {
            padding: 100px 20px 20px; /* Ajustar padding para el navbar fijo */
            text-align: center;
        }
        .content h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }
        .content p {
            font-size: 18px;
            margin-bottom: 30px;
            color: #aaaaaa;
        }
        .user-info {
            background-color: #1E1E1E;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
            text-align: left;
            max-width: 600px;
            margin: 0 auto;
        }
        .user-info p {
            margin: 10px 0;
        }
        .buttons {
            margin-top: 30px;
        }
        .buttons button {
            padding: 15px 30px;
            border-radius: 5px;
            background-color: #ff9800;
            color: #fff;
            border: none;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-right: 10px;
        }
        .buttons button:hover {
            background-color: #e68a00;
        }
    </style>
</head>
<body>

    <div class="navbar">
        <div class="logo">
            <img src="img/logo.png" alt="Banco Leandro">
        </div>
        <ul>
            <li><a href="index.php?accion=Inicio">Inicio</a></li>
            <li><a href="index.php?accion=Contacto">Contacto</a></li>
            <li><a href="index.php?accion=Salir">Salir</a></li>
        </ul>
    </div>

    <div class="content">
        <h1>Información del Usuario</h1>
        <div class="user-info">
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['usuario']->value, 'user');
$_smarty_tpl->tpl_vars['user']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['user']->value) {
$_smarty_tpl->tpl_vars['user']->do_else = false;
?>
                <p><strong>ID:</strong> <?php echo $_smarty_tpl->tpl_vars['user']->value['id_usuario'];?>
</p>
                <p><strong>Nombre:</strong> <?php echo $_smarty_tpl->tpl_vars['user']->value['nombre'];?>
 <?php echo $_smarty_tpl->tpl_vars['user']->value['apellido'];?>
 <?php echo $_smarty_tpl->tpl_vars['user']->value['apellido2'];?>
</p>
                <p><strong>Email:</strong> <?php echo $_smarty_tpl->tpl_vars['user']->value['email'];?>
</p>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </div>

        <div class="buttons">
    
            <button onclick="window.location.href='index.php?accion=Inicio'">Volver al Inicio</button>
        </div>
    </div>

</body>
</html>
<?php }
}
