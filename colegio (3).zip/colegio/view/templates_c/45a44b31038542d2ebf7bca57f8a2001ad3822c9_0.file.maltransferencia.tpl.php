<?php
/* Smarty version 4.5.3, created on 2024-08-12 16:52:29
  from 'C:\xampp2\htdocs\progra3\progra3\proyectocorto\view\templates\maltransferencia.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66ba21ad5db5e3_51099246',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '45a44b31038542d2ebf7bca57f8a2001ad3822c9' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyectocorto\\view\\templates\\maltransferencia.tpl',
      1 => 1723474346,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66ba21ad5db5e3_51099246 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transferencia Fallida</title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #121212; /* Tema oscuro */
            color: #ffffff;
        }
        .navbar {
            width: 100%;
            background-color: #1E1E1E;
            padding: 15px 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed; /* Fijar el navbar en la parte superior */
            top: 0;
            left: 0;
        }
        .navbar .logo img {
            width: 100px;
            height: auto;
        }
        .navbar ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }
        .navbar ul li {
            margin-left: 20px;
        }
        .navbar ul li a {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 5px;
            background-color: #ff9800;
            color: #ffffff;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }
        .navbar ul li a:hover {
            background-color: #e68a00;
        }
        .message-box {
            background-color: #1E1E1E;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
            text-align: center;
            max-width: 600px;
            margin-top: 80px; /* Espacio para el navbar */
        }
        .message-box h1 {
            color: #F44336;
            font-size: 36px;
            margin-bottom: 20px;
        }
        .message-box p {
            font-size: 18px;
            color: #aaaaaa;
        }
        .buttons {
            margin-top: 30px;
        }
        .buttons button {
            padding: 15px 30px;
            border-radius: 5px;
            background-color: #ff9800;
            color: #fff;
            border: none;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-right: 10px;
        }
        .buttons button:hover {
            background-color: #e68a00;
        }
    </style>
</head>
<body>

    <div class="navbar">
        <div class="logo">
            <img src="img/logo.png" alt="Banco Leandro">
        </div>
        <ul>
            <li><a href="index.php?accion=Inicio">Inicio</a></li>
            <li><a href="index.php?accion=Contacto">Contacto</a></li>
            <li><a href="index.php?accion=Salir">Salir</a></li>
        </ul>
    </div>

    <div class="message-box">
        <h1>Transferencia Fallida</h1>
        <p>Lo sentimos, la transferencia no se pudo completar.</p>
   
  
        </div>
    </div>
</body>
</html>
<?php }
}
