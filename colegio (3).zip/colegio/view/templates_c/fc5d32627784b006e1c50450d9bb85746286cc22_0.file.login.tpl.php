<?php
/* Smarty version 4.5.3, created on 2024-08-07 16:26:41
  from 'C:\xampp2\htdocs\progra3\progra3\proyectocorto\view\templates\login.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66b38421eef2f7_94596891',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fc5d32627784b006e1c50450d9bb85746286cc22' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyectocorto\\view\\templates\\login.tpl',
      1 => 1723040322,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66b38421eef2f7_94596891 (Smarty_Internal_Template $_smarty_tpl) {
?><!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login-BancoLeandro</title>
    <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #121212; /* Tema oscuro */
            color: #ffffff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
        }
        
        .navbar .logo img {
            width: 100px;
            height: auto;
        }
        .navbar ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }
        .navbar ul li {
            margin-left: 20px;
        }
        .navbar ul li a {
            color: #ffffff;
            text-decoration: none;
            font-size: 16px;
        }
        .navbar ul li a:hover {
            color: #ff9800;
        }
        .form-signin {
            background-color: #1f1f1f;
            border-radius: 0.5rem;
            padding: 2rem;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            max-width: 400px;
            margin: auto;
        }
        .form-control {
            background-color: #333;
            color: #ffffff;
            border: 1px solid #444;
        }
        .form-control::placeholder {
            color: #aaa;
        }
        .form-control:focus {
            border-color: #555;
            box-shadow: none;
        }
        .btn-primary {
            background-color: #ff9800;
            border: none;
            font-size: 14px;
            padding: 10px 20px;
        }
        .btn-primary:hover {
            background-color: #e68a00;
        }
        .btn-primary:focus, .btn-primary:active {
            background-color: #c97500;
            border: none;
        }
        .btn-primary:disabled {
            background-color: #6c757d;
            border: none;
        }
        .text-body-secondary {
            color: #888;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <div class="logo">
      
        </div>
        <ul>
        
    </div>
    <main class="form-signin">
     <img class="mb-4" src="img/logo.png" alt="" width="72" height="57">
        <form id="loginForm" action="index.php" method="post" onsubmit="return validateForm()">
            <h1 class="h3 mb-3 fw-normal">Ingresa</h1>
            <div class="form-floating">
                <input type="email" name="email" class="form-control" id="floatingInput" placeholder="name@example.com">
                <label for="floatingInput">Email address</label>
            </div>
            <div class="form-floating">
                <input type="password" name="pass" class="form-control" id="floatingPassword" placeholder="Password">
                <label for="floatingPassword">Password</label>
            </div>
            <div class="form-check text-start my-3">
                <input class="form-check-input" type="checkbox" value="remember-me" id="flexCheckDefault">
                <label class="form-check-label" for="flexCheckDefault">
                    Remember me
                </label>
            </div>
            <button class="btn btn-primary w-100 py-2" type="submit" name="accion" value="validarlogin">Ir</button>
            <p class="fw-bold text-center">Si no tienes cuenta, crea una</p>
            <button class="btn btn-primary w-100 py-2" type="submit" name="accion" value="signin">Sign in</button>
            <p class="mt-5 mb-3 text-body-secondary text-center">&copy; 2017–2024</p>
        </form>
    </main>

    <?php echo '<script'; ?>
>
        function validateForm() {
            var password = document.getElementById('floatingPassword').value;
            if (password === "") {
                alert("Por favor, ingrese su contraseña.");
                return false;
            }
            return true;
        }
    <?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="assets/dist/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
</body>
</html>

<?php }
}
