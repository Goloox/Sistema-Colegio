<?php
/* Smarty version 4.5.3, created on 2024-08-21 03:36:45
  from 'C:\xampp2\htdocs\progra3\progra3\colegio\view\templates\gestionarestudiantes.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66c544ad8321e8_83816469',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7b0f98d3e1bc6ff8893d84c06857eb1ea0f04b23' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\view\\templates\\gestionarestudiantes.tpl',
      1 => 1724204077,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66c544ad8321e8_83816469 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestionar Estudiantes</title>
    <style>
        body {
            background-color: #f5f5f5;
            color: #333;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
        h1, h2 {
            color: #007bff;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #007bff;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #e9ecef;
        }
        tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="number"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #007bff;
            border-radius: 4px;
            background-color: #fff;
            color: #333;
        }
        button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            margin: 5px 0;
        }
        button:hover {
            background-color: #0056b3;
        }
        .form-container {
            margin-bottom: 20px;
        }
        .form-container form {
            margin-bottom: 20px;
        }
        .classes-list {
            margin-top: 10px;
            font-size: 0.9em;
            color: #007bff;
        }
        .home-button {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <h1>Gestionar Estudiantes</h1>
    
    <!-- Botón para volver a Home -->
    <div class="home-button">
        <form action="index.php" method="post">
            <input type="hidden" name="accion" value="Home">
            <button type="submit">Volver a Home</button>
        </form>
    </div>
    
    <?php if ((isset($_smarty_tpl->tpl_vars['mensaje']->value))) {?>
        <div><?php echo $_smarty_tpl->tpl_vars['mensaje']->value;?>
</div>
    <?php }?>
    
    <div class="form-container">
        <form action="index.php" method="post">
            <input type="hidden" name="action" value="guardar_estudiante">
            <input type="text" name="nombre" placeholder="Nombre" required>
            <input type="text" name="apellido" placeholder="Apellido" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="pass" placeholder="Contraseña" required>
            <input type="number" name="grado" placeholder="Grado" required>
            <button name="accion" value="guardar_estudiante" type="submit">Guardar Estudiante</button>
        </form>
    </div>

    <h2>Lista de Estudiantes</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Email</th>
            <th>Grado</th>
            <th>Clases</th>
            <th>Acciones</th>
        </tr>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['estudiantes']->value, 'estudiante');
$_smarty_tpl->tpl_vars['estudiante']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['estudiante']->value) {
$_smarty_tpl->tpl_vars['estudiante']->do_else = false;
?>
        <tr>
            <td><?php echo $_smarty_tpl->tpl_vars['estudiante']->value['id_estudiante'];?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['estudiante']->value['nombre'];?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['estudiante']->value['apellido'];?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['estudiante']->value['email'];?>
</td>
            <td><?php if ((isset($_smarty_tpl->tpl_vars['estudiante']->value['grado']))) {
echo $_smarty_tpl->tpl_vars['estudiante']->value['grado'];
} else { ?>No disponible<?php }?></td>
            <td>
                <?php if ((isset($_smarty_tpl->tpl_vars['estudiante']->value['clases'])) && count($_smarty_tpl->tpl_vars['estudiante']->value['clases']) > 0) {?>
                    <div class="classes-list">
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['estudiante']->value['clases'], 'clase');
$_smarty_tpl->tpl_vars['clase']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['clase']->value) {
$_smarty_tpl->tpl_vars['clase']->do_else = false;
?>
                            <?php echo $_smarty_tpl->tpl_vars['clase']->value['nombre'];?>
<br>
                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </div>
                <?php } else { ?>
                    No tiene clases asignadas
                <?php }?>
            </td>
            <td>
                <form action="index.php" method="post" style="display:inline;">
                    <input type="hidden" name="action" value="actualizar_estudiante">
                    <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['estudiante']->value['id_estudiante'];?>
">
                    <input type="text" name="nombre" value="<?php echo $_smarty_tpl->tpl_vars['estudiante']->value['nombre'];?>
" required>
                    <input type="text" name="apellido" value="<?php echo $_smarty_tpl->tpl_vars['estudiante']->value['apellido'];?>
" required>
                    <input type="email" name="email" value="<?php echo $_smarty_tpl->tpl_vars['estudiante']->value['email'];?>
" required>
                    <input type="number" name="grado" value="<?php echo $_smarty_tpl->tpl_vars['estudiante']->value['grado'];?>
" required>
                    <input type="password" name="pass" placeholder="Nueva Contraseña">
                    <button name="accion" value="actualizar_estudiante" type="submit">Actualizar</button>
                </form>
                <form action="index.php" method="post" style="display:inline;">
                    <input type="hidden" name="action" value="eliminar_estudiante">
                    <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['estudiante']->value['id_estudiante'];?>
">
                    <button name="accion" value="eliminar_estudiante" type="submit">Eliminar</button>
                </form>
            </td>
        </tr>
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </table>
</body>
</html>
<?php }
}
