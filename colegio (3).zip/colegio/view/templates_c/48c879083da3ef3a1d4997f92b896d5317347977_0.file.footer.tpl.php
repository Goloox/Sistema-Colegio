<?php
/* Smarty version 4.5.3, created on 2024-06-26 16:42:07
  from 'C:\xampp2\htdocs\progra3\progra3\proyecto\view\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_667c28bf086bb7_45599169',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '48c879083da3ef3a1d4997f92b896d5317347977' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyecto\\view\\templates\\footer.tpl',
      1 => 1719365325,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_667c28bf086bb7_45599169 (Smarty_Internal_Template $_smarty_tpl) {
?> </body>
</html>
<?php }
}
