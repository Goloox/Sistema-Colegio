<?php
/* Smarty version 4.5.3, created on 2024-08-14 22:13:31
  from 'C:\xampp2\htdocs\progra3\progra3\colegio\view\templates\info.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66bd0febbb51f2_96039989',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6e4a8f033f9917c2f4a38a0362b289ab8a084eb5' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\view\\templates\\info.tpl',
      1 => 1723666410,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66bd0febbb51f2_96039989 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Información</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            overflow: hidden;
        }
        header {
            background: #333;
            color: #fff;
            padding-top: 30px;
            min-height: 70px;
            border-bottom: #c0c0c0 3px solid;
        }
        header a {
            color: #fff;
            text-decoration: none;
            text-transform: uppercase;
            font-size: 16px;
        }
        header ul {
            padding: 0;
            margin: 0;
            list-style: none;
            line-height: 0;
        }
        header li {
            float: left;
            display: inline;
            padding: 0 20px 0 20px;
        }
        footer {
            background: #333;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div id="branding">
                <h1>Nombre del Sitio</h1>
            </div>
            <nav>
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="contacto.php">Contacto</a></li>
                    <li><a href="logout.php">Cerrar Sesión</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <div class="container">
        <section id="info">
            <h2>Información del Usuario</h2>
            <p>Aquí se muestra la información del usuario logueado. Puedes incluir cualquier tipo de información relevante para el usuario en esta sección.</p>
        </section>
    </div>
    <footer>
        <p>Nombre del Sitio &copy; 2024</p>
    </footer>
</body>
</html>
<?php }
}
