<?php
/* Smarty version 4.5.3, created on 2024-08-21 01:57:08
  from 'C:\xampp2\htdocs\progra3\progra3\colegio\view\templates\gestionarasignaturas.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66c52d54d152d1_02651342',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0a430d927c8889c80a57b6ec5abd7478b5686f15' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\view\\templates\\gestionarasignaturas.tpl',
      1 => 1724198227,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66c52d54d152d1_02651342 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionar Asignaturas</title>
    <link rel="stylesheet" href="path/to/your/css/styles.css">
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #333;
            background-color: #f4f4f4;
        }

        .navbar {
            background-color: #007bff;
            color: #ffffff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        .navbar h1 {
            margin: 0;
            font-size: 1.5em;
        }

        .navbar a {
            color: #ffffff;
            text-decoration: none;
            font-size: 1em;
            padding: 10px 15px;
            transition: background-color 0.3s;
        }

        .navbar a:hover {
            background-color: #0056b3;
            border-radius: 5px;
        }

        .content {
            padding: 80px 20px 20px; /* Space for the fixed navbar */
            text-align: center;
        }

        .content h2 {
            font-size: 2em;
            margin-bottom: 20px;
        }

        .form-container {
            background-color: #ffffff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: auto;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input, .form-group select {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }

        .form-group input:focus, .form-group select:focus {
            border-color: #007bff;
            outline: none;
        }

        .btn-primary {
            background-color: #007bff;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>Gestionar Asignaturas</h1>
        <div>
          
        </div>
    </div>

    <div class="content">
        <h2>Añadir Nueva Asignatura</h2>
        
        <div class="form-container">
        <!-- Botón para volver a Home -->
        <div class="home-button">
            <form action="index.php" method="post">
                <input type="hidden" name="accion" value="Home">
                <button type="submit">Volver a Home</button>
            </form>
        </div>
            <form id="asignaturaForm" action="index.php" method="post">
                <div class="form-group">
                    <label for="nombre_asignatura">Nombre de la Asignatura:</label>
                    <input type="text" id="nombre_asignatura" name="nombre_asignatura" placeholder="Nombre de la asignatura" required>
                </div>
                <div class="form-group">
                    <label for="descripcion_asignatura">Descripción:</label>
                    <input type="text" id="descripcion_asignatura" name="descripcion_asignatura" placeholder="Descripción de la asignatura" required>
                </div>
                <div class="form-group">
                    <button type="submit" name=accion value="guardar_asignatura" class="btn-primary">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
<?php }
}
