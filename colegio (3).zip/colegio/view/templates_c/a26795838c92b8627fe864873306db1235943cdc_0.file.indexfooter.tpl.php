<?php
/* Smarty version 4.5.3, created on 2024-06-26 16:51:41
  from 'C:\xampp2\htdocs\progra3\progra3\proyecto\view\templates\indexfooter.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_667c2afd3ac980_03299807',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a26795838c92b8627fe864873306db1235943cdc' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyecto\\view\\templates\\indexfooter.tpl',
      1 => 1719412452,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_667c2afd3ac980_03299807 (Smarty_Internal_Template $_smarty_tpl) {
?> </style>
</head><?php }
}
