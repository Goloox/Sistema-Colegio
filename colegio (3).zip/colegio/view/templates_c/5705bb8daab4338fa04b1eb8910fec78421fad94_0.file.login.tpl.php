<?php
/* Smarty version 4.5.3, created on 2024-08-14 20:06:08
  from 'C:\xampp2\htdocs\progra3\progra3\colegio\view\templates\login.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66bcf210a142c1_33037723',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5705bb8daab4338fa04b1eb8910fec78421fad94' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\view\\templates\\login.tpl',
      1 => 1723658764,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66bcf210a142c1_33037723 (Smarty_Internal_Template $_smarty_tpl) {
?><!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistema Escolar</title>
    <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f0f0; /* Fondo claro para la página */
            color: #333333;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
        }
        
        .form-signin {
            background-color: #ffffff; /* Fondo blanco para el formulario */
            border-radius: 0.5rem;
            padding: 2rem;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            max-width: 400px;
            margin: auto;
            margin-top: 100px;
        }
        
        .form-control {
            background-color: #e0e0e0;
            color: #333333;
            border: 1px solid #cccccc;
        }
        .form-control::placeholder {
            color: #888888;
        }
        .form-control:focus {
            border-color: #007bff;
            box-shadow: none;
        }
        
        .btn-primary {
            background-color: #007bff; /* Azul para el botón de iniciar sesión */
            border: none;
            font-size: 14px;
            padding: 10px 20px;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .btn-primary:focus, .btn-primary:active {
            background-color: #004080;
            border: none;
        }

        .btn-secondary {
            background-color: #007bff; /* Azul para los botones de profesor y estudiante */
            border: none;
            color: #ffffff;
            font-size: 14px;
            padding: 10px 20px;
            margin: 5px 0;
        }
        .btn-secondary:hover {
            background-color: #0056b3;
        }
        .btn-secondary:focus, .btn-secondary:active {
            background-color: #004080;
            border: none;
        }
    </style>
</head>
<body>
    <main class="form-signin">
        <form id="loginForm" action="index.php" method="post">
            <h1 class="h3 mb-3 fw-normal text-center">Administrador</h1>
            <div class="form-floating mb-3">
                <input type="email" name="email" class="form-control" id="floatingInput" placeholder="name@example.com" required>
                <label for="floatingInput">Correo electrónico</label>
            </div>
            <div class="form-floating mb-3">
                <input type="password" name="pass" class="form-control" id="floatingPassword" placeholder="Contraseña" required>
                <label for="floatingPassword">Contraseña</label>
            </div>
            <button class="btn btn-secondary w-100 py-2" type="submit" name="accion" value="verprofe">Profesor</button>
            <button class="btn btn-secondary w-100 py-2" type="submit" name="accion" value="verestu">Estudiante</button>
            <button class="btn btn-primary w-100 py-2" type="submit" name="accion" value="loginadministrador">Iniciar Sesión</button>
            <p class="mt-5 mb-3 text-muted text-center">&copy; 2024</p>
        </form>
    </main>

    <?php echo '<script'; ?>
 src="assets/dist/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
