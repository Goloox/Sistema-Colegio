<?php
/* Smarty version 4.5.3, created on 2024-08-12 16:29:04
  from 'C:\xampp2\htdocs\progra3\progra3\proyectocorto\view\templates\listarcuentas.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66ba1c30debc79_79909195',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bcad16d3c2ef01174a3478c2366c72b2bf685a3d' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyectocorto\\view\\templates\\listarcuentas.tpl',
      1 => 1723472552,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66ba1c30debc79_79909195 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp2\\htdocs\\progra3\\progra3\\proyectocorto\\libs\\smarty-4-5-3\\plugins\\modifier.count.php','function'=>'smarty_modifier_count',),));
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listar Cuentas - Banco</title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #121212; /* Tema oscuro */
            color: #ffffff;
        }
        .navbar {
            width: 100%;
            background-color: #1E1E1E;
            padding: 15px 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            top: 0;
            left: 0;
        }
        .navbar .logo img {
            width: 100px;
            height: auto;
        }
        .navbar ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }
        .navbar ul li {
            margin-left: 20px;
        }
        .navbar ul li a {
            color: #ffffff;
            text-decoration: none;
            font-size: 16px;
        }
        .navbar ul li a:hover {
            color: #ff9800;
        }
        .content {
            text-align: center;
            padding: 100px 20px 20px; 
        }
        .content h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }
        .content table {
            border-collapse: collapse;
            width: 100%;
            max-width: 800px;
            margin: 0 auto;
            margin-bottom: 30px;
        }
        .content table, .content th, .content td {
            border: 1px solid #ffffff;
        }
        .content th, .content td {
            padding: 10px;
            text-align: left;
        }
        .actions {
            display: flex;
            flex-direction: column;
            gap: 10px;
            align-items: center;
        }
        .actions form {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        .actions button {
            padding: 12px 25px;
            border-radius: 8px;
            background-color: #ff9800;
            color: #fff;
            border: none;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        .actions button:hover {
            background-color: #e68a00;
            transform: scale(1.05);
        }
        .actions button:active {
            transform: scale(0.95);
        }
        /* Modal */
        .modal {
            display: none; 
            position: fixed; 
            z-index: 1; 
            left: 0;
            top: 0;
            width: 100%; 
            height: 100%; 
            overflow: auto; 
            background-color: rgb(0,0,0); 
            background-color: rgba(0,0,0,0.4); 
            padding-top: 60px;
        }
        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%; 
            max-width: 600px;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        /* Responsividad */
        @media (max-width: 768px) {
            .navbar ul {
                flex-direction: column;
                align-items: center;
            }
            .navbar ul li {
                margin-left: 0;
                margin-bottom: 10px;
            }
            .actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="navbar">
        <div class="logo">
            <img src="img/logo.png" alt="Banco Leandro">
        </div>
        <ul>
            <li><a href="index.php?accion=Inicio">Inicio</a></li>
            <li><a href="index.php?accion=Contacto">Contacto</a></li>
            <li><a href="index.php?accion=Salir">Salir</a></li>

                <button type="submit" style="background: none; border: none; color: #ffffff; cursor: pointer;">Cerrar Sesión</button>
            </form>
        </ul>
    </div>
    <div class="content">
        <h1>Mis Cuentas</h1>
        <?php if ((isset($_smarty_tpl->tpl_vars['cuentas']->value)) && smarty_modifier_count($_smarty_tpl->tpl_vars['cuentas']->value) > 0) {?>
            <table>
                <thead>
                    <tr>
                        <th>Número de Cuenta</th>
                        <th>Tipo de Cuenta</th>
                        <th>Saldo</th>
                        <th>Fecha de Creación</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['cuentas']->value, 'cuenta');
$_smarty_tpl->tpl_vars['cuenta']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['cuenta']->value) {
$_smarty_tpl->tpl_vars['cuenta']->do_else = false;
?>
                        <tr>
                            <td><?php echo $_smarty_tpl->tpl_vars['cuenta']->value['numero_cuenta'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['cuenta']->value['tipo_cuenta'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['cuenta']->value['saldo'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['cuenta']->value['fecha_creacion'];?>
</td>
                            <td class="actions">
                                <form method="POST" action="index.php">
                                    <input type="hidden" name="accion" value="borrarCuenta">
                                    <input type="hidden" name="numero_cuenta" value="<?php echo $_smarty_tpl->tpl_vars['cuenta']->value['numero_cuenta'];?>
">
                                    <button  name="accion"  value="borrarCuenta type="submit">Borrar</button>
                                </form>
                                <button id="openTransferModal<?php echo $_smarty_tpl->tpl_vars['cuenta']->value['numero_cuenta'];?>
">Realizar Transferencia</button>

                                <form method="POST" action="index.php">
                                    <input type="hidden" name="accion" value="retiro_efectivo">
                                    <input type="hidden" name="numero_cuenta" value="<?php echo $_smarty_tpl->tpl_vars['cuenta']->value['numero_cuenta'];?>
">
                                    <input type="number" name="monto" placeholder="Monto">
                                    <button type="submit">Retirar</button>
                                </form>
                            </td>
                        </tr>
                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                </tbody>
            </table>
        <?php } else { ?>
            <p>No hay cuentas disponibles.</p>
        <?php }?>
        <!-- Modal -->
        <div id="transferModal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <form method="POST" action="index.php?accion=realizartransferencia">
                    <input type="hidden" name="id_usuario" value="<?php echo '<?php'; ?>
 echo $_SESSION['id_usuario']; <?php echo '?>'; ?>
">
                    
                    <label for="cuenta_origen">Cuenta Origen:</label>
                    <select name="cuenta_origen" id="cuenta_origen" required>
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['cuentas']->value, 'cuenta');
$_smarty_tpl->tpl_vars['cuenta']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['cuenta']->value) {
$_smarty_tpl->tpl_vars['cuenta']->do_else = false;
?>
                            <option value="<?php echo $_smarty_tpl->tpl_vars['cuenta']->value['numero_cuenta'];?>
"><?php echo $_smarty_tpl->tpl_vars['cuenta']->value['numero_cuenta'];?>
 - <?php echo $_smarty_tpl->tpl_vars['cuenta']->value['tipo_cuenta'];?>
</option>
                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </select>
                    
                    <label for="cuenta_destino">Cuenta Destino:</label>
                    <input type="text" name="cuenta_destino" id="cuenta_destino" required>
                    
                    <label for="monto">Monto a Transferir:</label>
                    <input type="number" name="monto" id="monto" required>
                    
                    <button type="submit">Realizar Transferencia</button>
                </form>
            </div>
        </div>
    </div>

    <?php echo '<script'; ?>
>
        // Modal
        var modal = document.getElementById("transferModal");
        var btns = document.querySelectorAll("[id^='openTransferModal']");
        var span = document.getElementsByClassName("close")[0];

        btns.forEach(function(btn) {
            btn.onclick = function() {
                modal.style.display = "block";
            }
        });

        span.onclick = function() {
            modal.style.display = "none";
        }

        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    <?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
