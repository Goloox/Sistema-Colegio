<?php
/* Smarty version 4.5.3, created on 2024-07-13 11:26:01
  from 'C:\xampp2\htdocs\progra3\progra3\proyecto\view\templates\indexcopy.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66924829b523d1_41933576',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5333457078cfba16bfbca528a0df87bf4b1f5785' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyecto\\view\\templates\\indexcopy.tpl',
      1 => 1720862758,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66924829b523d1_41933576 (Smarty_Internal_Template $_smarty_tpl) {
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Información del Centro</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: white;
        }

        .container {
            display: flex;
            border: 2px solid blue;
            margin: 10px;
            height: calc(100vh - 40px); /* Altura de la pantalla menos margen */
        }

        .sidebar {
            width: 20%;
            display: flex;
            flex-direction: column;
            border-right: 2px solid blue;
            padding: 10px;
            box-sizing: border-box;
            overflow-y: auto;
        }

        .logo, .menu, .login, .register {
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid blue;
            box-sizing: border-box;
        }

        .content {
            flex-grow: 1;
            padding: 10px;
            box-sizing: border-box;
            display: flex;
        }

        .info-section, .photo-section {
            padding: 10px;
            box-sizing: border-box;
        }

        .info-section {
            flex: 3; /* Aumenta el tamaño de esta sección */
        }

        .photo-section {
            flex: 1;
            background-color: #333;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        h2, h3 {
            margin: 0;
            padding-bottom: 10px;
        }

        ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        li {
            padding: 5px 0;
        }

        .login-form input, .register-form input {
            display: block;
            margin: 5px 0;
            padding: 5px;
            width: 100%;
            box-sizing: border-box;
        }

        .login-form button, .register-form button {
            padding: 10px;
            background-color: blue;
            color: white;
            border: none;
            cursor: pointer;
            width: 100%;
            box-sizing: border-box;
        }

        .container-custom {
            max-width: 1200px; /* Ajusta el valor según el ancho deseado */
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <div class="logo text-center mb-2">
                <img src="img/logoescuela.png" alt="Logo del colegio" width="200" height="150">
            </div>
            <div class="menu">
                <h3 class="text-center">Menú</h3>
                <ul class="list-group">
                    <li class="list-group-item">Ubicación</li>
                    <li class="list-group-item">Características</li>
                    <li class="list-group-item">Servicios</li>
                    <li class="list-group-item">Información</li>
                    <li class="list-group-item">Proyectos de escuela</li>
                </ul>
            </div>
        </div>
        <div class="content">
            <div class="info-section">
                <div class="container-custom">
                    <h2 class="text-center mb-4">Información del Centro</h2>
                    <table class="table table-bordered table-striped">
                        <tbody>
                            <tr>
                                <th scope="row">Código del centro</th>
                                <td>XXXXXX</td>
                            </tr>
                            <tr>
                                <th scope="row">CIF</th>
                                <td>XXXXXXXXX</td>
                            </tr>
                            <tr>
                                <th scope="row">Dirección</th>
                                <td>Calle Ejemplo, 123</td>
                            </tr>
                            <tr>
                                <th scope="row">CP</th>
                                <td>28000</td>
                            </tr>
                            <tr>
                                <th scope="row">Teléfono</th>
                                <td>123 456 789</td>
                            </tr>
                            <tr>
                                <th scope="row">Móvil</th>
                                <td>987 654 321</td>
                            </tr>
                            <tr>
                                <th scope="row">Fax</th>
                                <td>123 456 789</td>
                            </tr>
                            <tr>
                                <th scope="row">Email</th>
                                <td>info@colegio.com</td>
                            </tr>
                            <tr>
                                <th scope="row">Modalidad lingüística</th>
                                <td>Bilingüe</td>
                            </tr>
                            <tr>
                                <th scope="row">Educación infantil 2 ciclo</th>
                                <td>Disponible</td>
                            </tr>
                            <tr>
                                <th scope="row">Educación primaria</th>
                                <td>Disponible</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="photo-section">
                <div class="text-center">
                    <h3 class="text-center">Fotos</h3>
                    <ul class="list-group">
                        <li class="mb-2"><img src="img/1.png" alt="Foto 1" width="200" height="150"></li>
                        <li class="mb-2"><img src="img/2.png" alt="Foto 2" width="200" height="150"></li>
                        <li class="mb-2"><img src="img/3.png" alt="Foto 3" width="200" height="150"></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-3.5.1.slim.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"><?php echo '</script'; ?>
>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Off-Canvas Navigation with Page Transitions</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400|Raleway:300,700">
    <style>
        /* Global Variables */
        :root {
            --primary: #7d87a8;
            --primary-ultralight: #d0d5e1;
            --primary-light: #aab0c1;
            --primary-dark: #4e566e;
            --primary-ultradark: #333b4e;
            --black: #333333;
            --white: #eeeeee;
            --max-width: 800px;
            --mobile-width: 600px;
            --ease-in-out-cubic: cubic-bezier(0.645, 0.045, 0.355, 1.000);
            --cubic-transition: 0.55s var(--ease-in-out-cubic);
            --nav-bar-width: 60px;
            --bar-length: 28px;
            --bar-thickness: 4px;
        }

        /* Global Styles */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Roboto', sans-serif;
            background-color: var(--white);
            color: var(--black);
            overflow-x: hidden;
        }

        .nav__bar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            width: var(--nav-bar-width);
            height: 100vh;
            background-color: var(--primary-ultradark);
            border-right: 1px solid rgba(125, 135, 168, 0.25);
            z-index: 1000;
        }

        .nav__trigger {
            display: block;
            position: absolute;
            top: 50%;
            left: calc((var(--nav-bar-width) - var(--bar-length)) / 2);
            transform: translateY(-50%);
            width: var(--bar-length);
            height: var(--bar-thickness);
            background-color: var(--primary);
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .nav__trigger.is-active {
            transform: rotate(45deg);
        }

        .nav__trigger .bars {
            position: absolute;
            top: 50%;
            left: 0;
            transform: translateY(-50%);
            width: var(--bar-length);
            height: var(--bar-thickness);
            background-color: var(--primary);
            transition: all 0.3s ease;
        }

        .nav__trigger .bars:before,
        .nav__trigger .bars:after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: var(--bar-length);
            height: var(--bar-thickness);
            background-color: var(--primary);
            transition: all 0.3s ease;
        }

        .nav__trigger .bars:before {
            transform: translateY(-10px);
        }

        .nav__trigger .bars:after {
            transform: translateY(10px);
        }

        .main {
            position: relative;
            width: calc(100% - var(--nav-bar-width));
            height: 100vh;
            margin-left: var(--nav-bar-width);
            transition: all var(--cubic-transition);
            overflow: hidden;
        }

        .hero {
            background-color: var(--primary-ultralight);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 0 20px;
        }

        .hero__content h1 {
            font-size: 3rem;
            margin-bottom: 20px;
        }

        .hero__content h4 {
            font-size: 1.2rem;
            color: var(--primary-dark);
        }

        .content {
            padding: 20px;
        }

        .article {
            margin-bottom: 30px;
            padding: 20px;
            border-bottom: 1px solid #ccc;
        }

        .article:last-child {
            border-bottom: none;
        }

        .article__title {
            font-size: 1.5rem;
            color: var(--primary-dark);
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .article__title:hover {
            color: var(--primary);
        }

        .article__time {
            font-size: 0.8rem;
            color: #999;
            margin-top: 5px;
        }

        .article__content {
            font-size: 1rem;
            line-height: 1.6;
            color: var(--black);
        }

        .nav {
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            width: 0;
            overflow: hidden;
            background-color: var(--primary-ultradark);
            transition: width 0.3s ease;
            z-index: 999;
        }

        .nav__list {
            list-style: none;
            padding: 20px;
            text-align: center;
        }

        .nav__item {
            margin-bottom: 10px;
        }

        .nav__item a {
            font-size: 1.2rem;
            color: var(--primary);
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .nav__item a:hover {
            color: var(--primary-light);
        }

        .is-active .nav {
            width: calc(100% - var(--nav-bar-width));
        }

        .is-froze {
            overflow: hidden;
        }

        @media (max-width: var(--mobile-width)) {
            .nav__trigger {
                left: 10px;
            }

            .nav__list {
                padding: 100px 20px;
            }
        }
    </style>
</head>
<body>
    <div class="nav__bar">
        <a href="#" class="nav__trigger">
            <div class="bars">
                <div class="bar"></div>
                <div class="bar"></div>
                <div class="bar"></div>
            </div>
        </a>
    </div>

    <main class="main">
        <section class="hero">
            <div class="hero__content">
                <h1 class="hero__heading">Off-Canvas Navigation<br>w/Page Transitions</h1>
                <h4 class="hero__subheading">By: <a href="http://kylebrumm.com" target="_blank">Kyle Brumm</a></h4>
            </div>
        </section>

        <section class="content">
            <article class="article">
                <a href="#" class="article__title">Vinegar Polaroid Tote Bag Vegan Street</a>
                <time class="article__time">NOVEMBER 15, 2015</time>
                <p class="article__content">
                    Seitan wayfarers bitters direct trade keytar lomo fanny pack pop-up Carles yr forage drinking vinegar polaroid tote bag vegan street art next level Odd Future gentrify sustainable hella.
                </p>
            </article>

            <article class="article">
                <a href="#" class="article__title">Tofu Vinyl Salvia Readymade Mixtape Viral</a>
                <time class="article__time">SEPTEMBER 29, 2015</time>
                <p class="article__content">
                    Retro keffiyeh flannel kogi asymmetrical Portland Etsy mumblecore craft beer occupy fap Neutra organic 3 wolf moon pour-over tofu vinyl salvia readymade mixtape viral 90's single-origin coffee Bushwick kale chips church-key art party Thundercats...
                </p>
            </article>

            <article class="article">
                <a href="#" class="article__title">Umami Quinoa Blog Kitsch Gluten-Free Plaid Pug</a>
                <time class="article__time">AUGUST 17, 2015</time>
                <p class="article__content">
                    Before they sold out crucifix Kickstarter Godard Marfa chambray four loko wolf scenester Tumblr heirloom chia put a bird on it umami quinoa blog kitsch gluten-free plaid pug.
                </p>
            </article>

            <article class="article">
                <a href="#" class="article__title">Chillwave Stumptown Leggings Raw Denim</a>
                <time class="article__time">AUGUST 05, 2015</time>
                <p class="article__content">
                    Intelligentsia pickled photo booth McSweeney's +1 actually Schlitz whatever 8-bit sriracha iPhone stumptown leggings raw denim Williamsburg food truck aesthetic narwhal authentic selvage Wes Anderson disrupt.
                </p>
            </article>

            <article class="article">
                <a href="#" class="article__title">Shoreditch Cardigan Farm-to-Table Butcher</a>
                <time class="article__time">JULY 31, 2015</time>
                <p class="article__content">
                    Tonx PBR ethical banjo trust fund meggings fingerstache ennui ugh cornhole fixie meh try-hard Shoreditch cardigan farm-to-table butcher synth DIY irony Banksy paleo mustache.
                </p>
            </article>

            <article class="article">
                <a href="#" class="article__title">Artisan Echo Park Gastropub Brunch</a>
                <time class="article__time">JULY 13, 2015</time>
                <p class="article__content">
                    Brooklyn cliche cray Blue Bottle skateboard distillery small batch master cleanse semiotics swag lo-fi High Life hoodie hashtag artisan Echo Park gastropub brunch.
                </p>
            </article>
        </section>
    </main>

    <nav class="nav">
        <ul class="nav__list">
            <li class="nav__item"><a href="#">Sriracha</a></li>
            <li class="nav__item"><a href="#">Wolf Moon</a></li>
            <li class="nav__item"><a href="#">Raw Denim</a></li>
            <li class="nav__item"><a href="#">Mumblecore</a></li>
            <li class="nav__item"><a href="#">Fingerstache</a></li>
            <li class="nav__item"><a href="#">Chillwave</a></li>
        </ul>
    </nav>

    <?php echo '<script'; ?>
>
        const navTrigger = document.querySelector('.nav__trigger');
        const navList = document.querySelector('.nav__list');
        const main = document.querySelector('.main');
        const body = document.querySelector('body');

        navTrigger.addEventListener('click', () => {
            navTrigger.classList.toggle('is-active');
            main.classList.toggle('is-active');
            body.classList.toggle('is-froze');
            navList.classList.toggle('is-active');
        });
    <?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
