<?php
/* Smarty version 4.5.3, created on 2024-07-11 19:00:04
  from 'C:\xampp\htdocs\progra3\proyecto\view\templates\indexfooter.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66900f9478f5a0_22018550',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '07f708ddb2b467efbe4a2802a84e09b976cd7ebd' => 
    array (
      0 => 'C:\\xampp\\htdocs\\progra3\\proyecto\\view\\templates\\indexfooter.tpl',
      1 => 1720716927,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66900f9478f5a0_22018550 (Smarty_Internal_Template $_smarty_tpl) {
?> </style>
</head><?php }
}
