<?php
/* Smarty version 4.5.3, created on 2024-08-21 02:48:15
  from 'C:\xampp2\htdocs\progra3\progra3\colegio\view\templates\profesorhome.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66c5394f0ee154_21087946',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9ec0c4f997cf1d4dadff5d24204cbd15ad39a1d9' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\view\\templates\\profesorhome.tpl',
      1 => 1724201291,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66c5394f0ee154_21087946 (Smarty_Internal_Template $_smarty_tpl) {
?><!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio - Sistema Escolar</title>
    <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #343a40; /* Fondo oscuro para la página */
            color: #ffffff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
        }
        
        .navbar {
            background-color: #212529;
        }
        
        .navbar-brand {
            color: #ffffff;
        }
        .navbar-nav .nav-link {
            color: #ffffff;
        }
        .navbar-nav .nav-link:hover {
            color: #007bff;
        }
        
        .container {
            margin-top: 20px;
        }
        
        .btn-primary {
            background-color: #007bff; /* Azul para los botones */
            border: none;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .btn-primary:focus, .btn-primary:active {
            background-color: #004080;
            border: none;
        }
        
        .card {
            background-color: #495057;
            border: none;
            color: #ffffff;
        }
        .card-header {
            background-color: #343a40;
            border-bottom: 1px solid #6c757d;
        }
        
        .btn-custom {
            background-color: #28a745; /* Verde para los botones adicionales */
            border: none;
        }
        .btn-custom:hover {
            background-color: #218838;
        }
        .btn-custom:focus, .btn-custom:active {
            background-color: #1e7e34;
            border: none;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="#">Sistema Escolar</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="profesor.php?accion=verinfoprofesor">Mi Perfil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="profesor.php?accion=clases">Mis Clases</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="profesor.php?accion=cerrarSesion">Cerrar Sesión</a>
                </li>
            </ul>
        </div>
    </nav>

<div class="container">
        <!-- Logo Button -->
        <div class="logo-container">
            <a href="estudiante.php?accion=normal">
                <img src="img/logoescuela.png" alt="Logo Sistema Escolar" class="logo-button">
            </a>
        </div>

        <div class="d-flex justify-content-center mt-4">
           
    </div>
    <?php echo '<script'; ?>
 src="assets/dist/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
