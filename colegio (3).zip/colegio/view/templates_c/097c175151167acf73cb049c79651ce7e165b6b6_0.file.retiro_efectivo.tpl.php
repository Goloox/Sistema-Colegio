<?php
/* Smarty version 4.5.3, created on 2024-08-04 08:54:43
  from 'C:\xampp2\htdocs\progra3\progra3\proyectocorto\view\templates\retiro_efectivo.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66af25b3920e52_48026600',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '097c175151167acf73cb049c79651ce7e165b6b6' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyectocorto\\view\\templates\\retiro_efectivo.tpl',
      1 => 1722750043,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66af25b3920e52_48026600 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Retiro de Efectivo - Banco</title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #121212; /* Tema oscuro */
            color: #ffffff;
        }
        .navbar {
            width: 100%;
            background-color: #1E1E1E;
            padding: 15px 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            top: 0;
            left: 0;
        }
        .navbar .logo img {
            width: 100px;
            height: auto;
        }
        .navbar ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }
        .navbar ul li {
            margin-left: 20px;
        }
        .navbar ul li a {
            color: #ffffff;
            text-decoration: none;
            font-size: 16px;
        }
        .navbar ul li a:hover {
            color: #ff9800;
        }
        .content {
            text-align: center;
            padding: 100px 20px 20px; 
        }
        .content h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }
        .content form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .content form input {
            padding: 10px;
            margin-bottom: 20px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
        }
        .content form button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background-color: #ff9800;
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .content form button:hover {
            background-color: #e68a00;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <div class="logo">
            <img src="logo.png" alt="Logo del Banco">
        </div>
        <ul>
            <li><a href="#">Inicio</a></li>
            <li><a href="#">Servicios</a></li>
            <li><a href="#">Contacto</a></li>
            <li><a href="#">Cerrar Sesión</a></li>
        </ul>
    </div>
    <div class="content">
        <h1>Retiro de Efectivo</h1>
        <form action="#" method="POST">
            <input type="number" name="monto" placeholder="Monto a retirar" required>
            <button type="submit">Retirar</button>
        </form>
    </div>
</body>
</html>
<?php }
}
