<?php
/* Smarty version 4.5.3, created on 2024-07-19 07:37:07
  from 'C:\xampp2\htdocs\progra3\progra3\proyecto\view\templates\signin.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_6699fb833b4740_84410020',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c2220041c9ad6a31f20569b703638dd0463fe181' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyecto\\view\\templates\\signin.tpl',
      1 => 1721367140,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6699fb833b4740_84410020 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registro</title>
  <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    html,
    body {
      height: 100%;
      background-color: #343a40;
      color: #ffffff;
    }
    .form-signin {
      max-width: 330px;
      padding: 1rem;
      background-color: #454d55;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      margin: auto;
      margin-top: 4rem;
    }
    .form-signin input,
    .form-signin select {
      margin-bottom: 10px;
      background-color: #6c757d;
      color: #ffffff;
      border: none;
    }
    .form-signin input::placeholder,
    .form-signin select::placeholder {
      color: rgba(255, 255, 255, 0.5);
    }
    .form-signin input:focus,
    .form-signin select:focus {
      background-color: #495057;
    }
    .form-signin input[type="checkbox"] {
      background-color: #6c757d;
      border-color: #6c757d;
    }
    .form-signin input[type="checkbox"]:checked {
      background-color: #6c757d;
    }
    .form-signin .btn-primary {
      background-color: #007bff;
      border: none;
    }
    .form-signin .btn-primary:hover {
      background-color: #0069d9;
    }
    .form-signin a {
      color: #ffffff;
    }
    .form-signin a:hover {
      color: #ffffff;
      text-decoration: none;
    }
    .text-body-secondary {
      color: rgba(255, 255, 255, 0.5);
    }
    .error {
      color: red;
      margin-bottom: 10px;
    }
  </style>
</head>
<body>
  <main class="form-signin">
    <form id="registerForm" action="signin.php" method="post" onsubmit="return validateForm()">
      <img class="mb-4" src="img/logoescuela.png" alt="" width="72" height="57">
      <h1 class="h3 mb-3 fw-normal">Registro</h1>

      <!-- Mostrar mensaje de error si existe -->
      <?php if ((isset($_smarty_tpl->tpl_vars['error']->value)) && $_smarty_tpl->tpl_vars['error']->value) {?>
      <div class="error"><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
</div>
      <?php }?>

      <!-- Intentionally hiding the user ID field -->
      <input type="hidden" name="idusuario" value="auto_incremented_value_here">

      <div class="form-floating mb-3">
        <input type="text" name="nombre" class="form-control" id="floatingNombre" placeholder="Nombre" required>
        <label for="floatingNombre">Nombre</label>
      </div>
      <div class="form-floating mb-3">
        <input type="text" name="apellido1" class="form-control" id="floatingApellido1" placeholder="Primer Apellido" required>
        <label for="floatingApellido1">Primer Apellido</label>
      </div>
      <div class="form-floating mb-3">
        <input type="text" name="apellido2" class="form-control" id="floatingApellido2" placeholder="Segundo Apellido" required>
        <label for="floatingApellido2">Segundo Apellido</label>
      </div>
      <div class="form-floating mb-3">
        <input type="email" name="email" class="form-control" id="floatingEmail" placeholder="name@example.com" required>
        <label for="floatingEmail">Correo Electrónico</label>
      </div>
      <div class="form-floating mb-3">
        <input type="password" name="contrasenia" class="form-control" id="floatingPassword" placeholder="Contraseña" required>
        <label for="floatingPassword">Contraseña</label>
      </div>
      <div class="form-floating mb-3">
        <input type="date" name="fechaNacimiento" class="form-control" id="floatingFechaNacimiento" placeholder="Fecha de Nacimiento" required>
        <label for="floatingFechaNacimiento">Fecha de Nacimiento</label>
      </div>
      <div class="form-floating mb-3">
        <select class="form-select" name="tipo" id="floatingTipo" required>
          <option selected>Selecciona un tipo</option>
          <option value="Estudiante">Estudiante</option>
          <option value="Profesor">Profesor</option>
          <option value="Administrador">Administrador</option>
        </select>
        <label for="floatingTipo">Tipo</label>
      </div>

      <button class="btn btn-primary w-100 py-2" type="submit" name="accion" value="registrarse">Registrarse</button>
     <button class="nav__button" type="submit" name="accion" input type="hidden" value="login">login</button>
      <p class="mt-5 mb-3 text-body-secondary">&copy; 2017–2024</p>
    </form>
  </main>

  <?php echo '<script'; ?>
>
    function validateForm() {
      var password = document.getElementById('floatingPassword').value;
      if (password === "") {
        alert("Por favor, ingrese su contraseña.");
        return false;
      }
      // Additional validation if needed
      return true;
    }
  <?php echo '</script'; ?>
>

  <?php echo '<script'; ?>
 src="assets/dist/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
