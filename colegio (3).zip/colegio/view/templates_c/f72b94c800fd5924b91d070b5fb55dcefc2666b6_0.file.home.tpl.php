<?php
/* Smarty version 4.5.3, created on 2024-08-12 16:28:58
  from 'C:\xampp2\htdocs\progra3\progra3\proyectocorto\view\templates\home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66ba1c2af1b216_80277506',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f72b94c800fd5924b91d070b5fb55dcefc2666b6' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyectocorto\\view\\templates\\home.tpl',
      1 => 1723472936,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66ba1c2af1b216_80277506 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Banco</title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #121212; /* Tema oscuro */
            color: #ffffff;
        }
        .navbar {
            width: 100%;
            background-color: #1E1E1E;
            padding: 15px 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed; /* Fijar el navbar en la parte superior */
            top: 0;
            left: 0;
        }
        .navbar .logo img {
            width: 100px;
            height: auto;
        }
        .navbar ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }
        .navbar ul li {
            margin-left: 20px;
        }
        .navbar ul li a {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 5px;
            background-color: #ff9800;
            color: #ffffff;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }
        .navbar ul li a:hover {
            background-color: #e68a00;
        }
        .content {
            text-align: center;
            padding: 100px 20px 20px; /* Ajustar padding para el navbar fijo */
        }
        .content h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }
        .content p {
            font-size: 18px;
            margin-bottom: 30px;
            color: #aaaaaa;
        }
        .content .buttons {
            display: flex;
            flex-direction: column; /* Alinear los botones en columna en dispositivos móviles */
            gap: 20px;
            align-items: center;
        }
        .content .buttons form {
            margin: 0;
        }
        .content .buttons button {
            padding: 15px 30px;
            border-radius: 5px;
            background-color: #ff9800;
            color: #fff;
            border: none;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .content .buttons button:hover {
            background-color: #e68a00;
        }
        /* Responsividad */
        @media (max-width: 768px) {
            .navbar ul {
                flex-direction: column;
                align-items: center;
            }
            .navbar ul li {
                margin-left: 0;
                margin-bottom: 10px;
            }
            .content .buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>

    <div class="navbar">
        <div class="logo">
             <img src="img/logo.png" alt="Banco Leandro">
        </div>
        <ul>
            <li><a href="index.php?accion=Inicio">Inicio</a></li>
            <li><a href="index.php?accion=Contacto">Contacto</a></li>
            <li><a href="index.php?accion=Salir">Salir</a></li>
        </ul>
    </div>
    <div class="content">
        <h1>Bienvenido a su Banco</h1>
        <p>Acceda a sus servicios bancarios de manera rápida y segura.</p>
        
        <div class="buttons">
            <form action="index.php" method="post">
                <button type="submit" name="accion" value="versaldo">Cuentas</button>
                <button type="submit" name="accion" value="verinfo">Informacion Usuario</button>
            </form>
        
        </div>
    </div>
</body>
</html>
<?php }
}
