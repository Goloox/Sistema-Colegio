<?php
/* Smarty version 4.5.3, created on 2024-07-24 07:18:02
  from 'C:\xampp2\htdocs\progra3\progra3\proyecto\ws\soap\server.php' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66a08e8a30b868_86838710',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ac3b201f22ae243f6a54c808fb74fcd82c0d22cf' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyecto\\ws\\soap\\server.php',
      1 => 1721797852,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66a08e8a30b868_86838710 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?php'; ?>


    $uri = "http://localhost/progra3/progra3/proyecto/ws/soap/";
    //wsdl
    $servidor = new  SoapServer(null,array('uri'=>$uri));


    
    $servidor->addFunction('BorrarUsuario');
    $servidor->addFunction('ListarUsuarios');



    $servidor->handle();

  

    function BorrarUsuario($idUsuario){

        $conx = new mysqli("localhost","root","","progra3_m");

        if($conx->connect_error){
            echo "Errror conectando a la DB";
            exit;
        }


        $sql="delete from usuarios where id_usuario=$idUsuario";
        $rs = $conx->query($sql);
        $conx->commit();
        mysqli_close($conx);
        return "El usuario $idUsuario se borro correctamente!!";
    }   

    function ListarUsuarios(){

        $conx = new mysqli("localhost","root","","progra3_m");

        if($conx->connect_error){
            echo "Errror conectando a la DB";
            exit;
        }
        $sql = "SELECT id_usuario, nombre, apellido, apellido2, email, fechanacimiento, tipo FROM usuarios";
        $rs = $conx->query($sql);


        $tabla = "<table>";
        $tabla .= "<tr>";

            $tabla .= "<th>ID</th>";
            $tabla .= "<th>Nombre</th>";
            $tabla .= "<th>Apellido 1</th>";
            $tabla .= "<th>Apellido 2</th>";
            $tabla .= "<th>Usuario</th>";
            $tabla .= "<th>Accion</th>";
    
        $tabla .= "</tr>";


        
        while ($fila = $rs->fetch_assoc()) {
            $tabla .= "<tr>";

            $tabla .= "<td>".$fila['id_usuario']."</td>";
            $tabla .= "<td>".$fila['nombre']."</td>";
            $tabla .= "<td>".$fila['apellido']."</td>";
            $tabla .= "<td>".$fila['apellido2']."</td>";
            $tabla .= "<td>".$fila['email']."</td>";
            $tabla .= "<td>".$fila['fechanacimiento']."</td>";
            $tabla .= "<td>".$fila['tipo']."</td>";
            $tabla .= "<td><a href='cliente.php?id_usuario_b=".$fila['id_usuario']."'>Borrar</a></td>";
    
            $tabla .= "</tr>";
        }

        $tabla .= "</table>";

        return $tabla;

    }
<?php echo '?>';
}
}
