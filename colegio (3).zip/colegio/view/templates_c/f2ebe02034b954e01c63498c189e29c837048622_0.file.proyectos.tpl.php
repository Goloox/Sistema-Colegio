<?php
/* Smarty version 4.5.3, created on 2024-08-18 18:12:26
  from 'C:\xampp2\htdocs\progra3\progra3\colegio\view\templates\proyectos.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66c21d6a4d8e81_09028179',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f2ebe02034b954e01c63498c189e29c837048622' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\view\\templates\\proyectos.tpl',
      1 => 1723997430,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66c21d6a4d8e81_09028179 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proyectos del Colegio</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            color: #343a40;
        }

        .container {
            display: flex;
            border: 2px solid #007bff;
            margin: 20px auto;
            padding: 0;
            max-width: 1200px;
            height: calc(100vh - 40px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: white;
        }

        .sidebar {
            width: 20%;
            display: flex;
            flex-direction: column;
            border-right: 2px solid #007bff;
            padding: 20px;
            background-color: #007bff;
            color: white;
            box-sizing: border-box;
            overflow-y: auto;
        }

        .logo {
            margin-bottom: 20px;
            text-align: center;
        }

        .logo img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
        }

        .menu h3 {
            font-size: 1.2em;
            text-align: center;
            margin-bottom: 15px;
        }

        .menu ul {
            padding: 0;
            margin: 0;
            list-style: none;
        }

        .menu li {
            margin-bottom: 10px;
            background-color: #0069d9;
            padding: 10px;
            text-align: center;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .menu li:hover {
            background-color: #0056b3;
            cursor: pointer;
        }

        .content {
            flex-grow: 1;
            padding: 20px;
            box-sizing: border-box;
            overflow-y: auto;
        }

        .project-list {
            margin-top: 20px;
        }

        .project-item {
            padding: 15px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 15px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
        }

        .project-item h4 {
            margin-top: 0;
        }

        .project-item p {
            margin: 0;
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                border-right: none;
                border-bottom: 2px solid #007bff;
            }

            .content {
                padding: 15px;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="sidebar">
            <div class="logo">
                <img src="img/logoescuela.png" alt="Logo del colegio">
            </div>
            <div class="menu">
                <h3 class="text-center">Menú</h3>
                <ul class="list-group">
                    <li class="list-group-item">
                        <form action="usuario.php" method="post">
                            <input type="hidden" name="accion" value="ver_caracteristicas">
                            <button type="submit" class="btn btn-link p-0">Características</button>
                        </form>
                    </li>
                    <li class="list-group-item">
                        <a href="https://maps.app.goo.gl/RHZhURU3iaT9qPst8" target="_blank" class="btn btn-link p-0">Ubicación</a>
                    </li>
                    <li class="list-group-item">
                        <form action="usuario.php" method="post">
                            <input type="hidden" name="accion" value="ver_servicios">
                            <button type="submit" class="btn btn-link p-0">Servicios</button>
                        </form>
                    </li>
                    <li class="list-group-item">
                        <form action="usuario.php" method="post">
                            <input type="hidden" name="accion" value="ver_informacion">
                            <button type="submit" class="btn btn-link p-0">Información</button>
                        </form>
                    </li>
                    <li class="list-group-item">
                        <form action="usuario.php" method="post">
                            <input type="hidden" name="accion" value="ver_proyectos">
                            <button type="submit" class="btn btn-link p-0">Proyectos de escuela</button>
                        </form>
                    </li>
                </ul>
            </div>
        </div>

        <div class="content">
            <h2 class="text-center">Proyectos del Colegio</h2>
            <div class="project-list">
                <div class="project-item">
                    <h4>Proyecto de Renovación de Infraestructura</h4>
                    <p>Este proyecto busca renovar las instalaciones del colegio, incluyendo la modernización de aulas y áreas comunes.</p>
                </div>
                <div class="project-item">
                    <h4>Programa de Integración Tecnológica</h4>
                    <p>Implementación de nuevas tecnologías en el aula para mejorar el aprendizaje de los estudiantes y prepararles para el futuro digital.</p>
                </div>
                <div class="project-item">
                    <h4>Iniciativa de Sostenibilidad Ambiental</h4>
                    <p>Un programa destinado a promover prácticas ecológicas en el colegio, incluyendo reciclaje y reducción de la huella de carbono.</p>
                </div>
                <!-- Puedes agregar más proyectos aquí -->
            </div>
        </div>
    </div>

    <?php echo '<script'; ?>
 src="https://kit.fontawesome.com/a076d05399.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-3.5.1.slim.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"><?php echo '</script'; ?>
>
</body>

</html>
<?php }
}
