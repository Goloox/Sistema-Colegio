<?php
/* Smarty version 4.5.3, created on 2024-07-11 18:59:05
  from 'C:\xampp\htdocs\progra3\proyecto\view\templates\indexcopy.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66900f594746f4_38238557',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4a70d0f9e5826337ca93824c07e08217419fe0ea' => 
    array (
      0 => 'C:\\xampp\\htdocs\\progra3\\proyecto\\view\\templates\\indexcopy.tpl',
      1 => 1720716927,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66900f594746f4_38238557 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Información del Centro</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: white;
        }

        .container {
            display: flex;
            border: 2px solid blue;
            margin: 10px;
            height: calc(100vh - 40px); /* Altura de la pantalla menos margen */
        }

        .sidebar {
            width: 20%;
            display: flex;
            flex-direction: column;
            border-right: 2px solid blue;
            padding: 10px;
            box-sizing: border-box;
            overflow-y: auto;
        }

        .logo, .menu, .login, .register {
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid blue;
            box-sizing: border-box;
        }

        .content {
            flex-grow: 1;
            padding: 10px;
            box-sizing: border-box;
            display: flex;
        }

        .info-section, .photo-section {
            padding: 10px;
            box-sizing: border-box;
        }

        .info-section {
            flex: 3; /* Aumenta el tamaño de esta sección */
        }

        .photo-section {
            flex: 1;
            background-color: #333;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        h2, h3 {
            margin: 0;
            padding-bottom: 10px;
        }

        ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        li {
            padding: 5px 0;
        }

        .login-form input, .register-form input {
            display: block;
            margin: 5px 0;
            padding: 5px;
            width: 100%;
            box-sizing: border-box;
        }

        .login-form button, .register-form button {
            padding: 10px;
            background-color: blue;
            color: white;
            border: none;
            cursor: pointer;
            width: 100%;
            box-sizing: border-box;
        }

        .container-custom {
            max-width: 1200px; /* Ajusta el valor según el ancho deseado */
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <div class="logo text-center mb-2">
                <img src="img/logoescuela.png" alt="Logo del colegio" width="200" height="150">
            </div>
            <div class="menu">
                <h3 class="text-center">Menú</h3>
                <ul class="list-group">
                    <li class="list-group-item">Ubicación</li>
                    <li class="list-group-item">Características</li>
                    <li class="list-group-item">Servicios</li>
                    <li class="list-group-item">Información</li>
                    <li class="list-group-item">Proyectos de escuela</li>
                </ul>
            </div>
        </div>
        <div class="content">
            <div class="info-section">
                <div class="container-custom">
                    <h2 class="text-center mb-4">Información del Centro</h2>
                    <table class="table table-bordered table-striped">
                        <tbody>
                            <tr>
                                <th scope="row">Código del centro</th>
                                <td>XXXXXX</td>
                            </tr>
                            <tr>
                                <th scope="row">CIF</th>
                                <td>XXXXXXXXX</td>
                            </tr>
                            <tr>
                                <th scope="row">Dirección</th>
                                <td>Calle Ejemplo, 123</td>
                            </tr>
                            <tr>
                                <th scope="row">CP</th>
                                <td>28000</td>
                            </tr>
                            <tr>
                                <th scope="row">Teléfono</th>
                                <td>123 456 789</td>
                            </tr>
                            <tr>
                                <th scope="row">Móvil</th>
                                <td>987 654 321</td>
                            </tr>
                            <tr>
                                <th scope="row">Fax</th>
                                <td>123 456 789</td>
                            </tr>
                            <tr>
                                <th scope="row">Email</th>
                                <td>info@colegio.com</td>
                            </tr>
                            <tr>
                                <th scope="row">Modalidad lingüística</th>
                                <td>Bilingüe</td>
                            </tr>
                            <tr>
                                <th scope="row">Educación infantil 2 ciclo</th>
                                <td>Disponible</td>
                            </tr>
                            <tr>
                                <th scope="row">Educación primaria</th>
                                <td>Disponible</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="photo-section">
                <div class="text-center">
                    <h3 class="text-center">Fotos</h3>
                    <ul class="list-group">
                        <li class="mb-2"><img src="img/1.png" alt="Foto 1" width="200" height="150"></li>
                        <li class="mb-2"><img src="img/2.png" alt="Foto 2" width="200" height="150"></li>
                        <li class="mb-2"><img src="img/3.png" alt="Foto 3" width="200" height="150"></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-3.5.1.slim.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"><?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
