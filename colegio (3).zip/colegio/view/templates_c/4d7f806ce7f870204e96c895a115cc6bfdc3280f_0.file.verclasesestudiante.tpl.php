<?php
/* Smarty version 4.5.3, created on 2024-08-18 09:39:55
  from 'C:\xampp2\htdocs\progra3\progra3\colegio\view\templates\verclasesestudiante.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66c1a54bb46058_98472301',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4d7f806ce7f870204e96c895a115cc6bfdc3280f' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\view\\templates\\verclasesestudiante.tpl',
      1 => 1723966792,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66c1a54bb46058_98472301 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\libs\\smarty-4-5-3\\plugins\\modifier.count.php','function'=>'smarty_modifier_count',),));
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clases Inscritas - Sistema Escolar</title>
    <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #121212;
            color: #ffffff;
        }
        .navbar {
            background-color: #1f1f1f;
        }
        .navbar-brand, .nav-link {
            color: #ffffff !important;
        }
        .card {
            background-color: #1f1f1f;
            color: #ffffff;
            margin-bottom: 20px;
        }
        .btn-custom {
            background-color: #ff6600;
            border: none;
            color: #ffffff;
        }
        .btn-custom:hover {
            background-color: #e65c00;
            color: #ffffff;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="#">Sistema Escolar</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="estudiante.php?accion=verinfoestudiante">Mi Perfil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="estudiante.php?accion=verclasesestudiante">Mis Clases</a>
                </li>
                <li class="nav-item">
                      <a class="nav-link" href="estudiante.php?accion=matricular" >Matricular</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="estudiante.php?accion=cerrarSesion">Cerrar Sesión</a>
                </li>
            </ul>
        </div>
    </nav>

                <!-- Add other navigation items -->
            </ul>
        </div>
    </nav>
    <div class="container">
        <h1 class="text-center mt-5">Clases Inscritas</h1>
        <?php if (smarty_modifier_count($_smarty_tpl->tpl_vars['clases']->value) > 0) {?>
            <div class="row">
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['clases']->value, 'clase');
$_smarty_tpl->tpl_vars['clase']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['clase']->value) {
$_smarty_tpl->tpl_vars['clase']->do_else = false;
?>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <?php echo $_smarty_tpl->tpl_vars['clase']->value['nombre'];?>

                            </div>
                            <div class="card-body">
                                <p><strong>Grado:</strong> <?php echo $_smarty_tpl->tpl_vars['clase']->value['grado'];?>
</p>
                                <p><strong>Horario:</strong> <?php echo $_smarty_tpl->tpl_vars['clase']->value['horario'];?>
</p>
                                <p><strong>calificacion:</strong> <?php echo $_smarty_tpl->tpl_vars['clase']->value['calificacion'];?>
</p>
                                <p><strong>tardias:</strong> <?php echo $_smarty_tpl->tpl_vars['clase']->value['tardias'];?>
</p>
                                <a href="?accion=ver_clase&id_clase=<?php echo $_smarty_tpl->tpl_vars['clase']->value['id_clase'];?>
" class="btn btn-custom">Ver companieros</a>
                            </div>
                        </div>
                    </div>
                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            </div>
        <?php } else { ?>
            <p class="text-center">No estás inscrito en ninguna clase.</p>
        <?php }?>
    </div>
    <?php echo '<script'; ?>
 src="assets/dist/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
