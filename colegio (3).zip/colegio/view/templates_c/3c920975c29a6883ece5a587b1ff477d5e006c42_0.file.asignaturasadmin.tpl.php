<?php
/* Smarty version 4.5.3, created on 2024-07-31 03:02:26
  from 'C:\xampp2\htdocs\progra3\progra3\proyecto\view\templates\asignaturasadmin.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66a98d2290a838_47402191',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3c920975c29a6883ece5a587b1ff477d5e006c42' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyecto\\view\\templates\\asignaturasadmin.tpl',
      1 => 1722387683,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66a98d2290a838_47402191 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Crear Asignatura</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #333;
            color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: #444;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #f4f4f4;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            font-weight: bold;
            margin: 10px 0 5px;
        }
        input[type="text"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #666;
            border-radius: 4px;
            box-sizing: border-box;
            background-color: #555;
            color: #f4f4f4;
        }
        textarea {
            resize: vertical;
        }
        input[type="submit"] {
            background-color: #28a745;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        input[type="submit"]:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Crear Asignatura</h1>
        <form action="asignaturasadmin.php" method="post">
            <div class="form-group">
                <label for="nombre_asignatura">Nombre de Asignatura:</label>
                <input type="text" name="nombre_asignatura" id="nombre_asignatura" required>
            </div>
            <div class="form-group">
                <label for="descripcion_asignatura">Descripción:</label>
                <textarea name="descripcion_asignatura" id="descripcion_asignatura" rows="4"></textarea>
            </div>
            <input type="submit" name="accion" value="Crear Asignatura">
        </form>
    </div>
</body>
</html>
<?php }
}
