<?php
/* Smarty version 4.5.3, created on 2024-07-31 03:26:12
  from 'C:\xampp2\htdocs\progra3\progra3\proyecto\view\templates\menuadministrador.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66a992b4f140c3_19007176',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '32d3341656669c5c47ce8ff34823a4481af90b60' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyecto\\view\\templates\\menuadministrador.tpl',
      1 => 1722389170,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66a992b4f140c3_19007176 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Concept</title>
    <style>
        :root {
            --background-color: #1e2023;
            --icon-color: #1e2023;
            --font-color: #ffffff;
            --font-color-active: #000000;
            --font-primary: 'Fira Sans', sans-serif;
            --transition-length: 0.8s;
        }

        body {
            background-color: var(--background-color);
            font-family: var(--font-primary);
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .site-content {
            max-width: 1100px;
            height: 100vh;
            margin: auto;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .site-content__headline {
            font-weight: 200;
            color: var(--font-color);
            font-size: calc(2vw + 10px);
        }

        .menu-icon {
            height: 30px;
            width: 30px;
            position: fixed;
            z-index: 2;
            left: 50px;
            top: 30px;
            cursor: pointer;
        }

        .menu-icon__line {
            height: 2px;
            width: 30px;
            display: block;
            background-color: var(--font-color);
            margin-bottom: 4px;
            transition: transform 0.2s ease, background-color 0.5s ease;
        }

        .menu-icon__line-left {
            width: 15px;
        }

        .menu-icon__line-right {
            width: 15px;
            float: right;
        }

        .nav {
            position: fixed;
            z-index: 1;
        }

        .nav:before,
        .nav:after {
            content: "";
            position: fixed;
            width: 100vw;
            height: 100vh;
            background: rgba(234, 234, 234, 0.2);
            z-index: -1;
            transition: transform cubic-bezier(0.77, 0, 0.175, 1) var(--transition-length);
            transform: translateX(0%) translateY(-100%);
        }

        .nav:after {
            background: rgba(255, 255, 255, 1);
            transition-delay: 0s;
        }

        .nav:before {
            transition-delay: 0.1s;
        }

        .nav__content {
            position: fixed;
            top: 50%;
            transform: translate(0%, -50%);
            width: 100%;
            text-align: center;
            font-size: calc(2vw + 10px);
            font-weight: 200;
        }

        .nav__list-item {
            position: relative;
            display: inline-block;
            transition-delay: var(--transition-length);
            opacity: 0;
            transform: translate(0%, 100%);
            transition: opacity 0.2s ease, transform 0.3s ease;
            margin-right: 25px;
        }

        .nav__list-item:before {
            content: "";
            position: absolute;
            background: var(--font-color-active);
            width: 20px;
            height: 1px;
            top: 100%;
            transform: translate(0%, 0%);
            transition: all 0.3s ease;
            z-index: -1;
        }

        .nav__list-item:hover:before {
            width: 100%;
        }

        body.nav-active .menu-icon__line {
            background-color: #000;
            transform: translateX(0px) rotate(-45deg);
        }

        body.nav-active .menu-icon__line-left {
            transform: translateX(1px) rotate(45deg);
        }

        body.nav-active .menu-icon__line-right {
            transform: translateX(-2px) rotate(45deg);
        }

        body.nav-active .nav:before,
        body.nav-active .nav:after {
            transform: translateX(0%) translateY(0%);
        }

        body.nav-active .nav:after {
            transition-delay: 0.1s;
        }

        body.nav-active .nav:before {
            transition-delay: 0s;
        }

        body.nav-active .nav__list-item {
            opacity: 1;
            transform: translateX(0%);
            transition: opacity 0.3s ease, transform 0.3s ease, color 0.3s ease;
        }

        body.nav-active .nav__list-item:nth-child(1) {
            transition-delay: calc(var(--transition-length) * 1 / 8 + 0.5s);
        }

        body.nav-active .nav__list-item:nth-child(2) {
            transition-delay: calc(var(--transition-length) * 2 / 8 + 0.5s);
        }

        body.nav-active .nav__list-item:nth-child(3) {
            transition-delay: calc(var(--transition-length) * 3 / 8 + 0.5s);
        }

        body.nav-active .nav__list-item:nth-child(4) {
            transition-delay: calc(var(--transition-length) * 4 / 8 + 0.5s);
        }

        .nav__button {
            background: var(--font-color);
            border: none;
            color: var(--font-color-active);
            font-size: calc(1.5vw + 5px);
            cursor: pointer;
            padding: 10px 20px;
            margin: 10px;
            font-family: var(--font-primary);
            transition: background-color 0.3s ease, color 0.3s ease;
            border-radius: 5px;
        }

        .nav__button:hover {
            background: var(--font-color-active);
            color: var(--font-color);
        }
    </style>
</head>
<body>
    <main class="form-signin w-100 m-auto">
        <form id="menu" action="menuadmin.php" method="post">
            <nav class="nav">
                <div class="nav__content">
                    <ul class="nav__list">
                        <li class="nav__list-item">
                        <button class="nav__button" type="submit" name="accion" input type="hidden" value="home">Usuarios</button>
                        <button class="nav__button" type="submit" name="accion" input type="hidden" value="asignaturas">Crear Asignatura</button>
                        <button class="nav__button" type="submit" name="accion" input type="hidden" value="clase">Crear clase</button>
                        <button class="nav__button" type="submit" name="accion" input type="hidden" value="Asignarprofesor">Asignar Profesor</button>
                        <button class="nav__button" type="submit" name="accion" input type="hidden" value="notas">Notas</button>
                        <button class="nav__button" type="submit" name="accion" input type="hidden" value="info">Info</button>
                           
                                
                            </form>
                        </li>
                    </ul>
                </div>
            </nav>
        </form>
    </main>

    <div class="menu-icon" aria-label="Menu">
        <span class="menu-icon__line menu-icon__line-left"></span>
        <span class="menu-icon__line"></span>
        <span class="menu-icon__line menu-icon__line-right"></span>
    </div>

    <div class="site-content">
        <h1 class="site-content__headline">Menu Concept</h1>
    </div>

    <?php echo '<script'; ?>
>
        const body = document.body;
        const menuIcon = document.querySelector('.menu-icon');

        menuIcon.addEventListener('click', () => {
            body.classList.toggle('nav-active');
        });
    <?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
