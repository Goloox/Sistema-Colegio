<?php
/* Smarty version 4.5.3, created on 2024-08-12 16:19:05
  from 'C:\xampp2\htdocs\progra3\progra3\proyectocorto\view\templates\signin.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66ba19d9d85f31_56301688',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a1e0e5f0580a1841987c9f871bd4aeeeb5723c33' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyectocorto\\view\\templates\\signin.tpl',
      1 => 1723472338,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66ba19d9d85f31_56301688 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inicio de Sesión</title>
  <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    html,
    body {
      height: 100%;
      background-color: #000000; /* Black background */
      color: #ffffff;
    }
    .form-signin {
      max-width: 400px;
      padding: 2rem;
      background-color: #333333; /* Dark gray background */
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
      margin: auto;
      margin-top: 5rem;
    }
    .form-signin input,
    .form-signin select {
      margin-bottom: 10px;
      background-color: #555555; /* Darker gray background for inputs */
      color: #ffffff;
      border: none;
    }
    .form-signin input::placeholder,
    .form-signin select::placeholder {
      color: rgba(255, 255, 255, 0.7);
    }
    .form-signin input:focus,
    .form-signin select:focus {
      background-color: #444444; /* Slightly lighter gray for focus */
    }
    .form-signin .btn-primary {
      background-color: #ffa500; /* Orange color */
      border: none;
    }
    .form-signin .btn-primary:hover {
      background-color: #e69500; /* Darker orange for hover */
    }
    .form-signin a {
      color: #ffffff;
    }
    .form-signin a:hover {
      color: #cccccc; /* Light gray on hover */
      text-decoration: none;
    }
    .text-body-secondary {
      color: rgba(255, 255, 255, 0.7);
    }
    .error {
      color: red;
      margin-bottom: 10px;
    }
  </style>
</head>
<body>
  <main class="form-signin">
    <form id="loginForm" action="index.php" method="post" onsubmit="return validateForm()">
      <img class="mb-4" src="img/logoescuela.png" alt="" width="72" height="57">
      <h1 class="h3 mb-3 fw-normal">Iniciar Sesión</h1>

      <!-- Mostrar mensaje de error si existe -->
      <?php if ((isset($_smarty_tpl->tpl_vars['error']->value)) && $_smarty_tpl->tpl_vars['error']->value) {?>
      <div class="error"><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
</div>
      <?php }?>

      <!-- Campos del formulario -->
      <div class="form-floating mb-3">
        <input type="text" name="nombre" class="form-control" id="floatingNombre" placeholder="Nombre" required>
        <label for="floatingNombre">Nombre</label>
      </div>
      <div class="form-floating mb-3">
        <input type="text" name="apellido" class="form-control" id="floatingApellido" placeholder="Apellido" required>
        <label for="floatingApellido">Apellido</label>
      </div>
      <div class="form-floating mb-3">
        <input type="text" name="apellido2" class="form-control" id="floatingApellido2" placeholder="Segundo Apellido" required>
        <label for="floatingApellido2">Segundo Apellido</label>
      </div>
      <div class="form-floating mb-3">
        <input type="email" name="email" class="form-control" id="floatingEmail" placeholder="name@example.com" required>
        <label for="floatingEmail">Correo Electrónico</label>
      </div>
      <div class="form-floating mb-3">
        <input type="password" name="pass" class="form-control" id="floatingPassword" placeholder="Contraseña" required>
        <label for="floatingPassword">Contraseña</label>
      </div>

      <button class="btn btn-primary w-100 py-2" type="submit" name="accion" value="registrarse">Iniciar Sesión</button>
      <p class="mt-5 mb-3 text-body-secondary">&copy; 2017–2024</p>
    </form>
  </main>

  <?php echo '<script'; ?>
>
    function validateForm() {
      var password = document.getElementById('floatingPassword').value;
      if (password === "") {
        alert("Por favor, ingrese su contraseña.");
        return false;
      }
      // Additional validation if needed
      return true;
    }
  <?php echo '</script'; ?>
>

  <?php echo '<script'; ?>
 src="assets/dist/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
