<?php
/* Smarty version 4.5.3, created on 2024-07-02 02:39:26
  from 'C:\xampp2\htdocs\progra3\progra3\proyecto\view\templates\loginfooter.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66834c3e2e30e4_74041615',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4f955ce4e71fb5bfa1684d6ff8f04342f5f38cc4' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyecto\\view\\templates\\loginfooter.tpl',
      1 => 1719365325,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66834c3e2e30e4_74041615 (Smarty_Internal_Template $_smarty_tpl) {
?> </body>
</html>
<?php }
}
