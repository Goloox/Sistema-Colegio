<?php
/* Smarty version 4.5.3, created on 2024-08-18 17:44:30
  from 'C:\xampp2\htdocs\progra3\progra3\colegio\view\templates\homeestudiante.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66c216de02a258_86587481',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a56df65bb6c5faec65a4be4aa50a8859da48412b' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\view\\templates\\homeestudiante.tpl',
      1 => 1723995855,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66c216de02a258_86587481 (Smarty_Internal_Template $_smarty_tpl) {
?><!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio - Sistema Escolar Estudiante</title>
    <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #343a40; /* Dark background for the page */
            color: #ffffff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
        }
        
        .navbar {
            background-color: #212529;
        }
        
        .navbar-brand {
            color: #ffffff;
        }
        
        .navbar-nav .nav-link {
            color: #ffffff;
        }
        
        .navbar-nav .nav-link:hover {
            color: #007bff;
        }
        
        .container {
            margin-top: 20px;
        }
        
        .btn-primary {
            background-color: #007bff; /* Blue for primary buttons */
            border: none;
        }
        
        .btn-primary:hover {
            background-color: #0056b3;
        }
        
        .btn-primary:focus, .btn-primary:active {
            background-color: #004080;
            border: none;
        }
        
        .card {
            background-color: #495057;
            border: none;
            color: #ffffff;
        }
        
        .card-header {
            background-color: #343a40;
            border-bottom: 1px solid #6c757d;
        }
        
        .btn-custom {
            background-color: #28a745; /* Green for additional buttons */
            border: none;
        }
        
        .btn-custom:hover {
            background-color: #218838;
        }
        
        .btn-custom:focus, .btn-custom:active {
            background-color: #1e7e34;
            border: none;
        }

        .logo-button {
            display: block;
            margin: 40px auto;
            max-width: 200px;
            max-height: 200px;
        }

        .logo-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 50vh; /* Centers the logo in the vertical middle of the screen */
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="#">Sistema Escolar</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="estudiante.php?accion=verinfoestudiante">Mi Perfil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="estudiante.php?accion=verclasesestudiante">Mis Clases</a>
                </li>
                <li class="nav-item">
                      <a class="nav-link" href="estudiante.php?accion=matricular" >Matricular</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="estudiante.php?accion=cerrarSesion">Cerrar Sesión</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <!-- Logo Button -->
        <div class="logo-container">
            <a href="estudiante.php?accion=normal">
                <img src="img/logoescuela.png" alt="Logo Sistema Escolar" class="logo-button">
            </a>
        </div>

        <div class="d-flex justify-content-center mt-4">
           
    </div>

    <?php echo '<script'; ?>
 src="assets/dist/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
