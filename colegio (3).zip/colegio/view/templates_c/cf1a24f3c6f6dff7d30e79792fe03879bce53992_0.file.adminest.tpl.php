<?php
/* Smarty version 4.5.3, created on 2024-08-21 02:25:33
  from 'C:\xampp2\htdocs\progra3\progra3\colegio\view\templates\adminest.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66c533fd4d0849_84185408',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cf1a24f3c6f6dff7d30e79792fe03879bce53992' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\view\\templates\\adminest.tpl',
      1 => 1724199926,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66c533fd4d0849_84185408 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\libs\\smarty-4-5-3\\plugins\\modifier.count.php','function'=>'smarty_modifier_count',),));
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrar Estudiantes</title>
    <link rel="stylesheet" href="path/to/your/css/styles.css"> <!-- Ajusta el path según sea necesario -->
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #333;
            background-color: #f4f4f4;
        }

        .navbar {
            background-color: #007bff;
            color: #ffffff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        .navbar h1 {
            margin: 0;
            font-size: 1.5em;
        }

        .navbar a {
            color: #ffffff;
            text-decoration: none;
            font-size: 1em;
            padding: 10px 15px;
            transition: background-color 0.3s;
        }

        .navbar a:hover {
            background-color: #0056b3;
            border-radius: 5px;
        }

        .content {
            padding: 80px 20px 20px; /* Space for the fixed navbar */
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin: 20px;
        }

        .content h2 {
            font-size: 2em;
            margin-bottom: 20px;
        }

        .content label {
            display: block;
            margin: 10px 0 5px;
        }

        .content input, .content select, .content button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .content button {
            background-color: #007bff;
            color: #ffffff;
            border: none;
            cursor: pointer;
            font-size: 1.2em;
        }

        .content button:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        table th {
            background-color: #007bff;
            color: #ffffff;
        }

        table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>Administrar Estudiantes</h1>
    </div>

    <div class="content">
        <h2>Ver Estudiantes Inscritos en una Clase</h2>
        
        <!-- Formulario para seleccionar la clase -->
        <form action="?accion=ver_estudiantes_inscritos" method="post">
            <label for="id_clase">Selecciona una Clase:</label>
            <select id="id_clase" name="id_clase" required>
                <?php if ((isset($_smarty_tpl->tpl_vars['clases']->value)) && smarty_modifier_count($_smarty_tpl->tpl_vars['clases']->value) > 0) {?>
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['clases']->value, 'clase');
$_smarty_tpl->tpl_vars['clase']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['clase']->value) {
$_smarty_tpl->tpl_vars['clase']->do_else = false;
?>
                        <option value="<?php echo $_smarty_tpl->tpl_vars['clase']->value['id_clase'];?>
"><?php echo $_smarty_tpl->tpl_vars['clase']->value['nombre'];?>
</option>
                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                <?php } else { ?>
                    <option value="">No hay clases disponibles</option>
                <?php }?>
            </select>
            <button name="accion"value="verporclase"type="submit">Ver Estudiantes</button>
        </form>

        <?php if ((isset($_smarty_tpl->tpl_vars['estudiantes']->value)) && smarty_modifier_count($_smarty_tpl->tpl_vars['estudiantes']->value) > 0) {?>
            <h3>Estudiantes Inscritos</h3>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Email</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['estudiantes']->value, 'estudiante');
$_smarty_tpl->tpl_vars['estudiante']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['estudiante']->value) {
$_smarty_tpl->tpl_vars['estudiante']->do_else = false;
?>
                        <tr>
                            <td><?php echo $_smarty_tpl->tpl_vars['estudiante']->value['id_estudiante'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['estudiante']->value['nombre'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['estudiante']->value['apellido'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['estudiante']->value['email'];?>
</td>
                        </tr>
                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                </tbody>
            </table>
        <?php } else { ?>
            <p>No hay estudiantes inscritos en esta clase.</p>
        <?php }?>
    </div>
</body>
</html>
<?php }
}
