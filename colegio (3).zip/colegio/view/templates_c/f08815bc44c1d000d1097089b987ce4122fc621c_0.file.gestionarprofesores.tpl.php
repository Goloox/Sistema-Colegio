<?php
/* Smarty version 4.5.3, created on 2024-08-21 01:58:21
  from 'C:\xampp2\htdocs\progra3\progra3\colegio\view\templates\gestionarprofesores.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66c52d9d045db5_13228291',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f08815bc44c1d000d1097089b987ce4122fc621c' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\view\\templates\\gestionarprofesores.tpl',
      1 => 1724198298,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66c52d9d045db5_13228291 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Profesores</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin: 10px 0 5px;
        }
        input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-bottom: 10px;
        }
        button {
            padding: 10px;
            background-color: #007bff;
            border: none;
            border-radius: 4px;
            color: #fff;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .mensaje {
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 10px;
        }
        .mensaje.success {
            background-color: #d4edda;
            color: #155724;
        }
        .mensaje.error {
            background-color: #f8d7da;
            color: #721c24;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f4f4f4;
        }
        .actions button {
            background-color: #28a745;
            border: none;
            color: #fff;
            cursor: pointer;
            padding: 5px 10px;
            margin-right: 5px;
            border-radius: 4px;
        }
        .actions button.delete {
            background-color: #dc3545;
        }
        .actions button:hover {
            opacity: 0.8;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Gestión de Profesores</h1>
        <!-- Botón para volver a Home -->
        <div class="home-button">
            <form action="index.php" method="post">
                <input type="hidden" name="accion" value="Home">
                <button type="submit">Volver a Home</button>
            </form>
        </div>

        <?php if ((isset($_smarty_tpl->tpl_vars['mensaje']->value))) {?>
            <div class="mensaje <?php if (strpos($_smarty_tpl->tpl_vars['mensaje']->value,'Error') !== false) {?>error<?php } else { ?>success<?php }?>">
                <?php echo $_smarty_tpl->tpl_vars['mensaje']->value;?>

            </div>
        <?php }?>

        <form method="post" action="index.php">
            <input type="hidden" name="accion" value="guardar_profesor">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required>

            <label for="apellido">Apellido:</label>
            <input type="text" id="apellido" name="apellido" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="pass">Contraseña:</label>
            <input type="password" id="pass" name="pass" required>

            <label for="telefono">Teléfono:</label>
            <input type="text" id="telefono" name="telefono" required>

            <label for="especialidad">Especialidad:</label>
            <input type="text" id="especialidad" name="especialidad" required>

            <button type="submit">Guardar</button>
        </form>

        <h2>Lista de Profesores</h2>
        <table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Email</th>
            <th>Teléfono</th>
            <th>Especialidad</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['profesores']->value, 'profesor');
$_smarty_tpl->tpl_vars['profesor']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['profesor']->value) {
$_smarty_tpl->tpl_vars['profesor']->do_else = false;
?>
        <tr>
            <td><?php echo $_smarty_tpl->tpl_vars['profesor']->value['id_profesor'];?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['profesor']->value['nombre'];?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['profesor']->value['apellido'];?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['profesor']->value['email'];?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['profesor']->value['telefono'];?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['profesor']->value['especialidad'];?>
</td>
            <td>
               
                <!-- Botón para Eliminar -->
                <form action="index.php" method="post" style="display:inline;">
                    <input type="hidden" name="accion" value="eliminar_profesor">
                    <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['profesor']->value['id_profesor'];?>
">
                    <button type="submit" onclick="return confirm('¿Estás seguro de que quieres eliminar este profesor?');">Eliminar</button>
                </form>
            </td>
        </tr>
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </tbody>
</table>

    </div>
</body>
</html>
<?php }
}
