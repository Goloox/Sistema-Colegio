<?php
/* Smarty version 4.5.3, created on 2024-08-14 02:02:35
  from 'C:\xampp2\htdocs\progra3\progra3\colegio\view\templates\gestionar_profesores.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66bbf41b7cf2d9_52050945',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c37dff3cd4fcc4daa35c822221a74873b7af03c8' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\view\\templates\\gestionar_profesores.tpl',
      1 => 1723593753,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66bbf41b7cf2d9_52050945 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Profesores</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin: 10px 0 5px;
        }
        input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-bottom: 10px;
        }
        button {
            padding: 10px;
            background-color: #007bff;
            border: none;
            border-radius: 4px;
            color: #fff;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .mensaje {
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 10px;
        }
        .mensaje.success {
            background-color: #d4edda;
            color: #155724;
        }
        .mensaje.error {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Gestión de Profesores</h1>

        <?php if ((isset($_smarty_tpl->tpl_vars['mensaje']->value))) {?>
            <div class="mensaje <?php if (strpos($_smarty_tpl->tpl_vars['mensaje']->value,'Error') !== false) {?>error<?php } else { ?>success<?php }?>">
                <?php echo $_smarty_tpl->tpl_vars['mensaje']->value;?>

            </div>
        <?php }?>

        <form method="post" action="index.php">
    <input type="hidden" name="accion" value="guardar_profesor">
    <label for="nombre">Nombre:</label>
    <input type="text" id="nombre" name="nombre" required><br><br>

    <label for="apellido">Apellido:</label>
    <input type="text" id="apellido" name="apellido" required><br><br>

    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required><br><br>

    <label for="pass">Contraseña:</label>
    <input type="password" id="pass" name="pass" required><br><br>

    <label for="telefono">Teléfono:</label>
    <input type="text" id="telefono" name="telefono" required><br><br>

    <label for="especialidad">Especialidad:</label>
    <input type="text" id="especialidad" name="especialidad" required><br><br>

    <button type="submit">Guardar</button>
        </form>
    </div>
</body>
</html>
<?php }
}
