<?php
/* Smarty version 4.5.3, created on 2024-06-19 04:47:02
  from 'C:\xampp2\htdocs\progra3\progra3\semana6\view\templates\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_667246a60e8530_90577440',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '244410d13afd3f1019c179d7705384b46058bc8c' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\semana6\\view\\templates\\index.tpl',
      1 => 1718765205,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_667246a60e8530_90577440 (Smarty_Internal_Template $_smarty_tpl) {
?><html> 
<head>
<title>Progra3</title>
</head>
<body>

    <h1> Esto es smarty <?php echo $_smarty_tpl->tpl_vars['titulo']->value;?>
 </h1>


    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['lista']->value, 'nombre');
$_smarty_tpl->tpl_vars['nombre']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['nombre']->value) {
$_smarty_tpl->tpl_vars['nombre']->do_else = false;
?>

    <?php echo $_smarty_tpl->tpl_vars['nombre']->value;?>


    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

</body>
</html><?php }
}
