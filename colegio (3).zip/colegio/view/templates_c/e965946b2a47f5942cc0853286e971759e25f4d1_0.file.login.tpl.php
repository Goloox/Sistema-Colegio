<?php
/* Smarty version 4.5.3, created on 2024-07-17 22:10:15
  from 'C:\xampp2\htdocs\progra3\progra3\proyecto\view\templates\login.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_669825276f2780_56193257',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e965946b2a47f5942cc0853286e971759e25f4d1' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyecto\\view\\templates\\login.tpl',
      1 => 1721246944,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:loginheader.tpl' => 1,
    'file:loginfooter.tpl' => 1,
  ),
),false)) {
function content_669825276f2780_56193257 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:loginheader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<body class="d-flex align-items-center py-4 bg-body-tertiary">
  <!-- Your SVG and other HTML content -->

  <main class="form-signin w-100 m-auto">
    <form id="loginForm" action="index.php" method="post" onsubmit="return validateForm()">
      <img class="mb-4" src="img/logoescuela.png" alt="" width="72" height="57">
      <h1 class="h3 mb-3 fw-normal">Ingresa</h1>

      <div class="form-floating">
        <input type="email" name="email" class="form-control" id="floatingInput" placeholder="name@example.com">
        <label for="floatingInput">Email address</label>
      </div>
      <div class="form-floating">
        <input type="password" name="pass" class="form-control" id="floatingPassword" placeholder="Password">
        <label for="floatingPassword">Password</label>
      </div>

      <div class="form-check text-start my-3">
        <input class="form-check-input" type="checkbox" value="remember-me" id="flexCheckDefault">
        <label class="form-check-label" for="flexCheckDefault">
          Remember me
        </label>
      </div>

      <button class="btn btn-primary w-100 py-2" type="submit" name="accion" value="validarlogin">ir</button> <p class="fw-bold">Si no tienes cuenta, crea una</p>
      <button class="btn btn-primary w-100 py-2" type="submit" name="accion" value="signin">Sign in</button>
        <br>
    

      <p class="mt-5 mb-3 text-body-secondary">&copy; 2017–2024</p>
    </form>
  </main>

  <?php echo '<script'; ?>
>
    function validateForm() {
      var password = document.getElementById('floatingPassword').value;
      if (password === "") {
        alert("Por favor, ingrese su contraseña.");
        return false;
      }
      return true;
    }
  <?php echo '</script'; ?>
>

  <?php echo '<script'; ?>
 src="assets/dist/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
  <?php $_smarty_tpl->_subTemplateRender("file:loginfooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
</body>
<?php }
}
