<?php
/* Smarty version 4.5.3, created on 2024-07-11 19:36:15
  from 'C:\xampp\htdocs\progra3\proyecto\view\templates\menu.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_6690180f370125_06383512',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'dafbe6fc1cb20de09f16b9f288cd6ea6b834b1ae' => 
    array (
      0 => 'C:\\xampp\\htdocs\\progra3\\proyecto\\view\\templates\\menu.tpl',
      1 => 1720719370,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6690180f370125_06383512 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Off-Canvas Navigation with Page Transitions</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400|Raleway:300,700">
    <style>
        /* Variables */
        $primary: #7d87a8;
        $primary-ultralight: mix(white, $primary, 65%);
        $primary-light: mix(white, $primary, 40%);
        $primary-dark: mix(black, $primary, 40%);
        $primary-ultradark: mix(black, $primary, 80%);
        $black: #333333;
        $white: #eeeeee;

        /* Fonts */
        @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400&display=swap');

        /* Misc */
        $max-width: 800px;
        $mobile-width: 600px;
        $ease-in-out-cubic: cubic-bezier(0.645, 0.045, 0.355, 1.000);
        $cubic-transition: 0.55s $ease-in-out-cubic;
        $nav-bar-width: 60px;
        $bar-length: 28px;
        $bar-thickness: 4px;

        /* Global Styles */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Roboto', sans-serif;
            background-color: $white;
            color: $black;
            overflow-x: hidden;
        }

        .nav__bar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            width: $nav-bar-width;
            height: 100vh;
            background-color: $primary-ultradark;
            border-right: 1px solid rgba($primary, 0.25);
            z-index: 1000;
        }

        .nav__trigger {
            display: block;
            position: absolute;
            top: 50%;
            left: calc((#<?php echo $_smarty_tpl->tpl_vars['nav']->value-'bar'-'width';?>
 - #<?php echo $_smarty_tpl->tpl_vars['bar']->value-'length';?>
) / 2);
            transform: translateY(-50%);
            width: $bar-length;
            height: $bar-thickness;
            background-color: $primary;
            transition: all 0.3s ease;
            cursor: pointer;

            &.is-active {
                transform: rotate(45deg);
            }

            .bars {
                position: absolute;
                top: 50%;
                left: 0;
                transform: translateY(-50%);
                width: $bar-length;
                height: $bar-thickness;
                background-color: $primary;
                transition: all 0.3s ease;

                &:before,
                &:after {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: $bar-length;
                    height: $bar-thickness;
                    background-color: $primary;
                    transition: all 0.3s ease;
                }

                &:before {
                    transform: translateY(-10px);
                }

                &:after {
                    transform: translateY(10px);
                }
            }
        }

        .main {
            position: relative;
            width: calc(100% - #<?php echo $_smarty_tpl->tpl_vars['nav']->value-'bar'-'width';?>
);
            height: 100vh;
            margin-left: $nav-bar-width;
            transition: all $cubic-transition;
            overflow: hidden;
        }

        .hero {
            background-color: $primary-ultralight;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 0 20px;

            h1 {
                font-size: 3rem;
                margin-bottom: 20px;
            }

            h4 {
                font-size: 1.2rem;
                color: $primary-dark;
            }
        }

        .content {
            padding: 20px;
        }

        .article {
            margin-bottom: 30px;
            padding: 20px;
            border-bottom: 1px solid #ccc;

            &:last-child {
                border-bottom: none;
            }

            .article__title {
                font-size: 1.5rem;
                color: $primary-dark;
                text-decoration: none;
                transition: color 0.3s ease;

                &:hover {
                    color: $primary;
                }
            }

            .article__time {
                font-size: 0.8rem;
                color: #999;
                margin-top: 5px;
            }

            .article__content {
                font-size: 1rem;
                line-height: 1.6;
                color: $black;
            }
        }

        .nav {
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            width: 0;
            overflow: hidden;
            background-color: $primary-ultradark;
            transition: width 0.3s ease;
            z-index: 999;
        }

        .nav__list {
            list-style: none;
            padding: 20px;
            text-align: center;

            .nav__item {
                margin-bottom: 10px;

                a {
                    font-size: 1.2rem;
                    color: $primary;
                    text-decoration: none;
                    transition: color 0.3s ease;

                    &:hover {
                        color: $primary-light;
                    }
                }
            }
        }

        .is-active .nav {
            width: calc(100% - #<?php echo $_smarty_tpl->tpl_vars['nav']->value-'bar'-'width';?>
);
        }

        .is-froze {
            overflow: hidden;
        }

        @media (max-width: $mobile-width) {
            .nav__trigger {
                left: 10px;
            }

            .nav__list {
                padding: 100px 20px;
            }
        }
    </style>
</head>
<body>
    <div class="nav__bar">
        <a href="#" class="nav__trigger">
            <div class="bars">
                <div class="bar"></div>
                <div class="bar"></div>
                <div class="bar"></div>
            </div>
        </a>
    </div>

    <main class="main">
        <section class="hero">
            <div class="hero__content">
                <h1 class="hero__heading">Off-Canvas Navigation<br>w/Page Transitions</h1>
                <h4 class="hero__subheading">By: <a href="http://kylebrumm.com" target="_blank">Kyle Brumm</a></h4>
            </div>
        </section>

        <section class="content">
            <article class="article">
                <a href="#" class="article__title">Vinegar Polaroid Tote Bag Vegan Street</a>
                <time class="article__time">NOVEMBER 15, 2015</time>
                <p class="article__content">
                    Seitan wayfarers bitters direct trade keytar lomo fanny pack pop-up Carles yr forage drinking vinegar polaroid tote bag vegan street art next level Odd Future gentrify sustainable hella.
                </p>
            </article>

            <article class="article">
                <a href="#" class="article__title">Tofu Vinyl Salvia Readymade Mixtape Viral</a>
                <time class="article__time">SEPTEMBER 29, 2015</time>
                <p class="article__content">
                    Retro keffiyeh flannel kogi asymmetrical Portland Etsy mumblecore craft beer occupy fap Neutra organic 3 wolf moon pour-over tofu vinyl salvia readymade mixtape viral 90's single-origin coffee Bushwick kale chips church-key art party Thundercats...
                </p>
            </article>

            <article class="article">
                <a href="#" class="article__title">Umami Quinoa Blog Kitsch Gluten-Free Plaid Pug</a>
                <time class="article__time">AUGUST 17, 2015</time>
                <p class="article__content">
                    Before they sold out crucifix Kickstarter Godard Marfa chambray four loko wolf scenester Tumblr heirloom chia put a bird on it umami quinoa blog kitsch gluten-free plaid pug.
                </p>
            </article>

            <article class="article">
                <a href="#" class="article__title">Chillwave Stumptown Leggings Raw Denim</a>
                <time class="article__time">AUGUST 05, 2015</time>
                <p class="article__content">
                    Intelligentsia pickled photo booth McSweeney's +1 actually Schlitz whatever 8-bit sriracha iPhone stumptown leggings raw denim Williamsburg food truck aesthetic narwhal authentic selvage Wes Anderson disrupt.
                </p>
            </article>

            <article class="article">
                <a href="#" class="article__title">Shoreditch Cardigan Farm-to-Table Butcher</a>
                <time class="article__time">JULY 31, 2015</time>
                <p class="article__content">
                    Tonx PBR ethical banjo trust fund meggings fingerstache ennui ugh cornhole fixie meh try-hard Shoreditch cardigan farm-to-table butcher synth DIY irony Banksy paleo mustache.
                </p>
            </article>

            <article class="article">
                <a href="#" class="article__title">Artisan Echo Park Gastropub Brunch</a>
                <time class="article__time">JULY 13, 2015</time>
                <p class="article__content">
                    Brooklyn cliche cray Blue Bottle skateboard distillery small batch master cleanse semiotics swag lo-fi High Life hoodie hashtag artisan Echo Park gastropub brunch.
                </p>
            </article>
        </section>
    </main>

    <nav class="nav">
        <ul class="nav__list">
            <li class="nav__item"><a href="#">Sriracha</a></li>
            <li class="nav__item"><a href="#">Wolf Moon</a></li>
            <li class="nav__item"><a href="#">Raw Denim</a></li>
            <li class="nav__item"><a href="#">Mumblecore</a></li>
            <li class="nav__item"><a href="#">Fingerstache</a></li>
            <li class="nav__item"><a href="#">Chillwave</a></li>
        </ul>
    </nav>

    <?php echo '<script'; ?>
>
        const navTrigger = document.querySelector('.nav__trigger');
        const navList = document.querySelector('.nav__list');
        const main = document.querySelector('.main');
        const body = document.querySelector('body');

        navTrigger.addEventListener('click', () => {
            navTrigger.classList.toggle('is-active');
            main.classList.toggle('is-active');
            body.classList.toggle('is-froze');
            navList.classList.toggle('is-active');
        });
    <?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
