<?php
/* Smarty version 4.5.3, created on 2024-07-29 16:52:57
  from 'C:\xampp2\htdocs\progra3\progra3\proyecto\view\templates\lista_usuarios.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66a7acc9bb9653_34160622',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'edb74e4f95865cd75abff638280a4f904d5f052a' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyecto\\view\\templates\\lista_usuarios.tpl',
      1 => 1721370585,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66a7acc9bb9653_34160622 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Usuarios</title>
    <style>
        body {
            background-color: #1e2023;
            color: #ffffff;
            font-family: 'Fira Sans', sans-serif;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ffffff;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #333333;
        }
        tr:nth-child(even) {
            background-color: #2e2e2e;
        }
        tr:nth-child(odd) {
            background-color: #242424;
        }
        .btn-delete {
            background-color: #ff4c4c;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
        }
        .btn-delete:hover {
            background-color: #ff1c1c;
        }
    </style>
</head>
<body>
    <h1>Lista de Usuarios</h1>
    <?php echo '<?php'; ?>
 if (isset($lista_usuarios) && count($lista_usuarios) > 0) { <?php echo '?>'; ?>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Apellido 1</th>
                    <th>Apellido 2</th>
                    <th>Email</th>
                    <th>Tipo</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php echo '<?php'; ?>
 foreach ($lista_usuarios as $usuario) { <?php echo '?>'; ?>

                <tr>
                    <td><?php echo '<?php'; ?>
 echo $usuario['id_usuario']; <?php echo '?>'; ?>
</td>
                    <td><?php echo '<?php'; ?>
 echo $usuario['nombre']; <?php echo '?>'; ?>
</td>
                    <td><?php echo '<?php'; ?>
 echo $usuario['apellido']; <?php echo '?>'; ?>
</td>
                    <td><?php echo '<?php'; ?>
 echo $usuario['apellido2']; <?php echo '?>'; ?>
</td>
                    <td><?php echo '<?php'; ?>
 echo $usuario['email']; <?php echo '?>'; ?>
</td>
                    <td><?php echo '<?php'; ?>
 echo $usuario['tipo']; <?php echo '?>'; ?>
</td>
                    <td>
                        <form action="adminhomecontrol.php" method="post">
                            <input type="hidden" name="accion" value="borrar_usuario">
                            <input type="hidden" name="id_usuario" value="<?php echo '<?php'; ?>
 echo $usuario['id_usuario']; <?php echo '?>'; ?>
">
                            <button type="submit" class="btn-delete">Borrar</button>
                        </form>
                    </td>
                </tr>
                <?php echo '<?php'; ?>
 } <?php echo '?>'; ?>

            </tbody>
        </table>
    <?php echo '<?php'; ?>
 } else { <?php echo '?>'; ?>

        <p>No hay usuarios registrados.</p>
    <?php echo '<?php'; ?>
 } <?php echo '?>'; ?>

</body>
</html>
<?php }
}
