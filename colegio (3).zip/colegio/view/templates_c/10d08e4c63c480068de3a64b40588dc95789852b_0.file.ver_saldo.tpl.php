<?php
/* Smarty version 4.5.3, created on 2024-08-12 16:24:11
  from 'C:\xampp2\htdocs\progra3\progra3\proyectocorto\view\templates\ver_saldo.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66ba1b0b722379_20865587',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '10d08e4c63c480068de3a64b40588dc95789852b' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyectocorto\\view\\templates\\ver_saldo.tpl',
      1 => 1723472640,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66ba1b0b722379_20865587 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp2\\htdocs\\progra3\\progra3\\proyectocorto\\libs\\smarty-4-5-3\\plugins\\modifier.count.php','function'=>'smarty_modifier_count',),));
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Saldo - Banco</title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #121212; /* Tema oscuro */
            color: #ffffff;
        }
        .navbar {
            width: 100%;
            background-color: #1E1E1E;
            padding: 15px 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            top: 0;
            left: 0;
        }
        .navbar .logo img {
            width: 100px;
            height: auto;
        }
        .navbar ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }
        .navbar ul li {
            margin-left: 20px;
        }
        .navbar ul li a {
            color: #ffffff;
            text-decoration: none;
            font-size: 16px;
        }
        .navbar ul li a:hover {
            color: #ff9800;
        }
        .content {
            text-align: center;
            padding: 100px 20px 20px; 
        }
        .content h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }
        .content table {
            border-collapse: collapse;
            width: 100%;
            max-width: 600px;
            margin: 0 auto;
            margin-bottom: 30px;
        }
        .content table, .content th, .content td {
            border: 1px solid #ffffff;
        }
        .content th, .content td {
            padding: 10px;
            text-align: left;
        }
        .buttons {
            display: flex;
            flex-direction: column; /* Alinear los botones en columna en dispositivos móviles */
            gap: 20px;
            align-items: center;
        }
        .buttons form {
            margin: 0;
        }
        .buttons button {
            padding: 15px 30px;
            border-radius: 5px;
            background-color: #ff9800;
            color: #fff;
            border: none;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .buttons button:hover {
            background-color: #e68a00;
        }
        /* Responsividad */
        @media (max-width: 768px) {
            .navbar ul {
                flex-direction: column;
                align-items: center;
            }
            .navbar ul li {
                margin-left: 0;
                margin-bottom: 10px;
            }
            .buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="navbar">
        <div class="logo">
            <img src="img/logo.png" alt="Banco Leandro">
        </div>
        <ul>
           <li><a href="index.php?accion=Inicio">Inicio</a></li>
            <li><a href="index.php?accion=Contacto">Contacto</a></li>
            <li><a href="index.php?accion=Salir">Salir</a></li>
        </ul>
    </div>
    <div class="content">
        <h1>Mis Cuentas</h1>
        <div class="buttons">
            <form method="POST" action="index.php">
                <button type="submit" name="accion" value="listarCuentasUsuario">Cargar Cuentas</button>
            </form>
        </div>
        <?php if ((isset($_smarty_tpl->tpl_vars['cuentas']->value)) && smarty_modifier_count($_smarty_tpl->tpl_vars['cuentas']->value) > 0) {?>
            <table>
                <thead>
                    <tr>
                        <th>Número de Cuenta</th>
                        <th>Tipo de Cuenta</th>
                        <th>Saldo</th>
                        <th>Fecha de Creación</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['cuentas']->value, 'cuenta');
$_smarty_tpl->tpl_vars['cuenta']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['cuenta']->value) {
$_smarty_tpl->tpl_vars['cuenta']->do_else = false;
?>
                        <tr>
                            <td><?php echo $_smarty_tpl->tpl_vars['cuenta']->value['numero_cuenta'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['cuenta']->value['tipo_cuenta'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['cuenta']->value['saldo'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['cuenta']->value['fecha_creacion'];?>
</td>
                            <td>
                                <form method="POST" action="index.php">
                                    <input type="hidden" name="accion" value="borrar_cuenta">
                                    <input type="hidden" name="numero_cuenta" value="<?php echo $_smarty_tpl->tpl_vars['cuenta']->value['numero_cuenta'];?>
">
                                    <button type="submit">Borrar</button>
                                </form>
                                <form method="POST" action="index.php">
                                    <input type="hidden" name="accion" value="realizartransferencia">
                                    <input type="hidden" name="numero_cuenta" value="<?php echo $_smarty_tpl->tpl_vars['cuenta']->value['numero_cuenta'];?>
">
                                    <button type="submit">Transferir</button>
                                </form>
                                <form method="POST" action="index.php">
                                    <input type="hidden" name="accion" value="retiro_efectivo">
                                    <input type="hidden" name="numero_cuenta" value="<?php echo $_smarty_tpl->tpl_vars['cuenta']->value['numero_cuenta'];?>
">
                                    <button type="submit">Retirar</button>
                                </form>
                            </td>
                        </tr>
                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                </tbody>
            </table>
        <?php } else { ?>
            <p>No hay cuentas disponibles.</p>
        <?php }?>
    </div>
    <div class="buttons">
        <form action="index.php" method="post">
            <button type="submit" name="accion" value="vercrearcuenta">Crear Cuenta</button>
        </form>
    </div>
</body>
</html>
<?php }
}
