<?php
/* Smarty version 4.5.3, created on 2024-07-31 08:59:37
  from 'C:\xampp2\htdocs\progra3\progra3\proyecto\view\templates\claseadmin.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66a9e0d919cd83_14585394',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1557bf4e8ef3fc058f93fbac1e608c6df2074598' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyecto\\view\\templates\\claseadmin.tpl',
      1 => 1722409173,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66a9e0d919cd83_14585394 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Crear Clase</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #333;
            color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: #444;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #f4f4f4;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            font-weight: bold;
            margin: 10px 0 5px;
        }
        input[type="text"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #666;
            border-radius: 4px;
            box-sizing: border-box;
            background-color: #555;
            color: #f4f4f4;
        }
        textarea {
            resize: vertical;
        }
        input[type="submit"] {
            background-color: #28a745;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        input[type="submit"]:hover {
            background-color: #218838;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .user-card {
            background-color: #555;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Lista de Usuarios por MVC</h1>
        <form action="claseadmin.php" method="get">
            <select class="form-select" aria-label="Default select example" name="lista_usuarios2" id="lista_usuarios2">
                <option selected>Seleccione un usuario para edición</option>
                <?php
$__section_indice_0_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['lista_usuarios']->value) ? count($_loop) : max(0, (int) $_loop));
$__section_indice_0_total = $__section_indice_0_loop;
$_smarty_tpl->tpl_vars['__smarty_section_indice'] = new Smarty_Variable(array());
if ($__section_indice_0_total !== 0) {
for ($__section_indice_0_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_indice']->value['index'] = 0; $__section_indice_0_iteration <= $__section_indice_0_total; $__section_indice_0_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_indice']->value['index']++){
?>
                <option value="<?php echo $_smarty_tpl->tpl_vars['lista_usuarios']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_indice']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_indice']->value['index'] : null)]['id_usuario'];?>
">
                    <?php echo $_smarty_tpl->tpl_vars['lista_usuarios']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_indice']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_indice']->value['index'] : null)]['nombre'];?>
 <?php echo $_smarty_tpl->tpl_vars['lista_usuarios']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_indice']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_indice']->value['index'] : null)]['apellido'];?>
 <?php echo $_smarty_tpl->tpl_vars['lista_usuarios']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_indice']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_indice']->value['index'] : null)]['apellido2'];?>

                </option>
                <?php
}
}
?>
            </select>
            <input type='button' value='Cargar lista de Usuarios' name="accion">
        </form>
        
        <hr>
        <div>
            
        </div>
    </div>
</body>
</html>
<?php }
}
