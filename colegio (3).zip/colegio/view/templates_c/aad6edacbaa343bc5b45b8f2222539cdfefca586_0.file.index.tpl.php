<?php
/* Smarty version 4.5.3, created on 2024-07-13 23:17:55
  from 'C:\xampp2\htdocs\progra3\progra3\proyecto\view\templates\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_6692ef03abc667_62635498',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'aad6edacbaa343bc5b45b8f2222539cdfefca586' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyecto\\view\\templates\\index.tpl',
      1 => 1720865617,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:indexheader.tpl' => 1,
    'file:indexfooter.tpl' => 1,
  ),
),false)) {
function content_6692ef03abc667_62635498 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:indexheader.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<body>
    
    <div class="container">
        <div class="sidebar">
            <div class="logo text-center mb-2">
                <img src="img/logoescuela.png" alt="Logo del colegio" width="200" height="150">
            </div>
            <div class="menu">
                <h3 class="text-center">Menú</h3>
                <ul class="list-group">
                    <li class="list-group-item"><a href="#ubicacion">Ubicación</a></li>
                    <li class="list-group-item"><a href="#caracteristicas">Características</a></li>
                    <li class="list-group-item"><a href="#servicios">Servicios</a></li>
                    <li class="list-group-item"><a href="#informacion">Información</a></li>
                    <li class="list-group-item"><a href="#proyectos">Proyectos de escuela</a></li>
                </ul>
            </div>
        </div>
        <div class="content">
            <div class="info-section">
                <div class="container-custom">
                    <h2 class="text-center mb-4">Información del Centro</h2>
                    <table class="table table-bordered table-striped">
                        <tbody>
                            <tr>
                                <th scope="row">Código del centro</th>
                                <td>XXXXXX</td>
                            </tr>
                            <tr>
                                <th scope="row">CIF</th>
                                <td>XXXXXXXXX</td>
                            </tr>
                            <tr>
                                <th scope="row">Dirección</th>
                                <td>Calle Ejemplo, 123</td>
                            </tr>
                            <tr>
                                <th scope="row">CP</th>
                                <td>28000</td>
                            </tr>
                            <tr>
                                <th scope="row">Teléfono</th>
                                <td>123 456 789</td>
                            </tr>
                            <tr>
                                <th scope="row">Móvil</th>
                                <td>987 654 321</td>
                            </tr>
                            <tr>
                                <th scope="row">Fax</th>
                                <td>123 456 789</td>
                            </tr>
                            <tr>
                                <th scope="row">Email</th>
                                <td>info@colegio.com</td>
                            </tr>
                            <tr>
                                <th scope="row">Modalidad lingüística</th>
                                <td>Bilingüe</td>
                            </tr>
                            <tr>
                                <th scope="row">Educación infantil 2 ciclo</th>
                                <td>Disponible</td>
                            </tr>
                            <tr>
                                <th scope="row">Educación primaria</th>
                                <td>Disponible</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="photo-section">
                <div class="text-center">
                    <h3 class="text-center">Fotos</h3>
                    <ul class="list-group">
                        <li class="mb-2"><img src="img/1.png" alt="Foto 1" width="200" height="150"></li>
                        <li class="mb-2"><img src="img/2.png" alt="Foto 2" width="200" height="150"></li>
                        <li class="mb-2"><img src="img/3.png" alt="Foto 3" width="200" height="150"></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-3.5.1.slim.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"><?php echo '</script'; ?>
>


    <?php $_smarty_tpl->_subTemplateRender("file:indexfooter.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
