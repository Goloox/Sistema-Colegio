<?php
/* Smarty version 4.5.3, created on 2024-08-18 17:58:30
  from 'C:\xampp2\htdocs\progra3\progra3\colegio\view\templates\usuario_normal.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66c21a268cce31_08518399',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'caab60dac8624beacc933b815b580f12465d75bd' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\view\\templates\\usuario_normal.tpl',
      1 => 1723996709,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66c21a268cce31_08518399 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Información del Centro</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            color: #343a40;
        }

        .container {
            display: flex;
            border: 2px solid #007bff;
            margin: 20px auto;
            padding: 0;
            max-width: 1200px;
            height: calc(100vh - 40px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: white;
        }

        .sidebar {
            width: 20%;
            display: flex;
            flex-direction: column;
            border-right: 2px solid #007bff;
            padding: 20px;
            background-color: #007bff;
            color: white;
            box-sizing: border-box;
            overflow-y: auto;
        }

        .logo {
            margin-bottom: 20px;
            text-align: center;
        }

        .logo img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
        }

        .menu h3 {
            font-size: 1.2em;
            text-align: center;
            margin-bottom: 15px;
        }

        .menu ul {
            padding: 0;
            margin: 0;
            list-style: none;
        }

        .menu li {
            margin-bottom: 10px;
            background-color: #0069d9;
            padding: 10px;
            text-align: center;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .menu li:hover {
            background-color: #0056b3;
            cursor: pointer;
        }

        .content {
            flex-grow: 1;
            padding: 20px;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .info-section {
            margin-bottom: 20px;
        }

        .info-section h2 {
            font-size: 1.8em;
            text-align: center;
            margin-bottom: 20px;
            color: #007bff;
        }

        .table {
            background-color: #f8f9fa;
        }

        .table th, .table td {
            vertical-align: middle;
        }

        .photo-section {
            padding: 20px;
            background-color: #343a40;
            color: white;
            border-radius: 10px;
        }

        .photo-section h3 {
            text-align: center;
            margin-bottom: 20px;
            color: #ffc107;
        }

        .photo-section ul {
            padding: 0;
            margin: 0;
            list-style: none;
        }

        .photo-section li {
            margin-bottom: 15px;
            text-align: center;
        }

        .photo-section img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }

        .photo-section img:hover {
            transform: scale(1.05);
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                border-right: none;
                border-bottom: 2px solid #007bff;
            }

            .content {
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <div class="logo">
                <img src="img/logoescuela.png" alt="Logo del colegio">
            </div>
            <div class="menu">
                <h3 class="text-center">Menú</h3>
                <ul class="list-group">
                    <li class="list-group-item">
                        <form action="usuario.php" method="post">
                            <input type="hidden" name="accion" value="ver_caracteristicas">
                            <button type="submit" class="btn btn-link p-0">Características</button>
                        </form>
                    </li>
                    <li class="list-group-item">
                        <form action="usuario.php" method="post">
                            <input type="hidden" name="accion" value="ver_ubicacion">
                            <button type="submit" class="btn btn-link p-0">Ubicación</button>
                        </form>
                    </li>
                    <li class="list-group-item">
                        <form action="usuario.php" method="post">
                            <input type="hidden" name="accion" value="ver_servicios">
                            <button type="submit" class="btn btn-link p-0">Servicios</button>
                        </form>
                    </li>
                    <li class="list-group-item">
                        <form action="usuario.php" method="post">
                            <input type="hidden" name="accion" value="ver_informacion">
                            <button type="submit" class="btn btn-link p-0">Información</button>
                        </form>
                    </li>
                    <li class="list-group-item">
                        <form action="usuario.php" method="post">
                            <input type="hidden" name="accion" value="ver_proyectos">
                            <button type="submit" class="btn btn-link p-0">Proyectos de escuela</button>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
        <div class="content">
            <div class="info-section">
                <h2>Información del Centro</h2>
                <table class="table table-bordered table-striped">
                    <tbody>
                        <tr>
                            <th scope="row">Código del centro</th>
                            <td>XXXXXX</td>
                        </tr>
                        <tr>
                            <th scope="row">CIF</th>
                            <td>XXXXXXXXX</td>
                        </tr>
                        <tr>
                            <th scope="row">Dirección</th>
                            <td>Calle Ejemplo, 123</td>
                        </tr>
                        <tr>
                            <th scope="row">CP</th>
                            <td>28000</td>
                        </tr>
                        <tr>
                            <th scope="row">Teléfono</th>
                            <td>123 456 789</td>
                        </tr>
                        <tr>
                            <th scope="row">Móvil</th>
                            <td>987 654 321</td>
                        </tr>
                        <tr>
                            <th scope="row">Fax</th>
                            <td>123 456 789</td>
                        </tr>
                        <tr>
                            <th scope="row">Email</th>
                            <td>info@colegio.com</td>
                        </tr>
                        <tr>
                            <th scope="row">Modalidad lingüística</th>
                            <td>Bilingüe</td>
                        </tr>
                        <tr>
                            <th scope="row">Educación infantil 2 ciclo</th>
                            <td>Disponible</td>
                        </tr>
                        <tr>
                            <th scope="row">Educación primaria</th>
                            <td>Disponible</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="photo-section">
                <h3>Fotos</h3>
                <ul>
                    <li><img src="img/1.png" alt="Foto 1"></li>
                    <li><img src="img/2.png" alt="Foto 2"></li>
                    <li><img src="img/3.png" alt="Foto 3"></li>
                </ul>
            </div>
        </div>
    </div>

    <?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-3.5.1.slim.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"><?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
