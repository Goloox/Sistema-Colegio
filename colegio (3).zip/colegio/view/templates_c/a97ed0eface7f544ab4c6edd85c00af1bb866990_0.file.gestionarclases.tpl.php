<?php
/* Smarty version 4.5.3, created on 2024-08-21 02:09:34
  from 'C:\xampp2\htdocs\progra3\progra3\colegio\view\templates\gestionarclases.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66c5303e4241a4_56544410',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a97ed0eface7f544ab4c6edd85c00af1bb866990' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\view\\templates\\gestionarclases.tpl',
      1 => 1724198973,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66c5303e4241a4_56544410 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\libs\\smarty-4-5-3\\plugins\\modifier.count.php','function'=>'smarty_modifier_count',),));
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionar Clases</title>
    <link rel="stylesheet" href="path/to/your/css/styles.css"> <!-- Ajusta el path según sea necesario -->
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #333;
            background-color: #f4f4f4;
        }

        .navbar {
            background-color: #007bff;
            color: #ffffff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        .navbar h1 {
            margin: 0;
            font-size: 1.5em;
        }

        .navbar a {
            color: #ffffff;
            text-decoration: none;
            font-size: 1em;
            padding: 10px 15px;
            transition: background-color 0.3s;
        }

        .navbar a:hover {
            background-color: #0056b3;
            border-radius: 5px;
        }

        .form-container {
            padding: 80px 20px 20px; /* Space for the fixed navbar */
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin: 20px;
        }

        .form-container h2 {
            font-size: 2em;
            margin-bottom: 20px;
        }

        .form-container label {
            display: block;
            margin: 10px 0 5px;
        }

        .form-container input, .form-container select, .form-container button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-container button {
            background-color: #007bff;
            color: #ffffff;
            border: none;
            cursor: pointer;
            font-size: 1.2em;
        }

        .form-container button:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        table th {
            background-color: #007bff;
            color: #ffffff;
        }

        table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .delete-btn {
            color: #ff0000;
            border: none;
            background: none;
            cursor: pointer;
            font-size: 1em;
            text-decoration: underline;
        }

        .delete-btn:hover {
            color: #cc0000;
        }
    </style>
</head>
<body>
  

    <div class="form-container">
        <h2>Gestionar Clases</h2>
          <!-- Botón para volver a Home -->
    <div class="home-button">
        <form action="index.php" method="post">
            <input type="hidden" name="accion" value="Home">
            <button type="submit">Volver a Home</button>
        </form>
    </div>

        <!-- Formulario para agregar una nueva clase -->
        <form action="?accion=guardar_clase" method="post">
            <label for="nombre_clase">Nombre de la Clase:</label>
            <input type="text" id="nombre_clase" name="nombre_clase" required>

            <label for="grado">Grado:</label>
            <input type="number" id="grado" name="grado" required>

            <label for="id_profesor">Profesor:</label>
            <select id="id_profesor" name="id_profesor" required>
                <?php if ((isset($_smarty_tpl->tpl_vars['profesores']->value)) && smarty_modifier_count($_smarty_tpl->tpl_vars['profesores']->value) > 0) {?>
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['profesores']->value, 'profesor');
$_smarty_tpl->tpl_vars['profesor']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['profesor']->value) {
$_smarty_tpl->tpl_vars['profesor']->do_else = false;
?>
                        <option value="<?php echo $_smarty_tpl->tpl_vars['profesor']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['profesor']->value['id'];?>
 - <?php echo $_smarty_tpl->tpl_vars['profesor']->value['nombre'];?>
 </option>
                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                <?php } else { ?>
                    <option value="">No hay profesores disponibles</option>
                <?php }?>
            </select>

            <label for="id_asignatura">Asignatura:</label>
            <select id="id_asignatura" name="id_asignatura" required>
                <?php if ((isset($_smarty_tpl->tpl_vars['asignaturas']->value)) && smarty_modifier_count($_smarty_tpl->tpl_vars['asignaturas']->value) > 0) {?>
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['asignaturas']->value, 'asignatura');
$_smarty_tpl->tpl_vars['asignatura']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['asignatura']->value) {
$_smarty_tpl->tpl_vars['asignatura']->do_else = false;
?>
                        <option value="<?php echo $_smarty_tpl->tpl_vars['asignatura']->value['id_asignatura'];?>
"><?php echo $_smarty_tpl->tpl_vars['asignatura']->value['nombre'];?>
</option>
                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                <?php } else { ?>
                    <option value="">No hay asignaturas disponibles</option>
                <?php }?>
            </select>

            <label for="horario">Horario:</label>
            <input type="text" id="horario" name="horario" required>

            <button type="submit">Guardar Clase</button>
        </form>

        <h3>Lista de Clases</h3>

        <?php if ((isset($_smarty_tpl->tpl_vars['clases']->value)) && smarty_modifier_count($_smarty_tpl->tpl_vars['clases']->value) > 0) {?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Grado</th>
                        <th>Profesor</th>
                        <th>Asignatura</th>
                        <th>Horario</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['clases']->value, 'clase');
$_smarty_tpl->tpl_vars['clase']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['clase']->value) {
$_smarty_tpl->tpl_vars['clase']->do_else = false;
?>
                        <tr>
                            <td><?php echo $_smarty_tpl->tpl_vars['clase']->value['id_clase'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['clase']->value['nombre'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['clase']->value['grado'];?>
</td>
                            <td>
                                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['profesores']->value, 'profesor');
$_smarty_tpl->tpl_vars['profesor']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['profesor']->value) {
$_smarty_tpl->tpl_vars['profesor']->do_else = false;
?>
                                    <?php if ($_smarty_tpl->tpl_vars['profesor']->value['id'] == $_smarty_tpl->tpl_vars['clase']->value['id_profesor']) {?>
                                        <?php echo $_smarty_tpl->tpl_vars['profesor']->value['nombre'];?>

                                    <?php }?>
                                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                            </td>
                            <td>
                                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['asignaturas']->value, 'asignatura');
$_smarty_tpl->tpl_vars['asignatura']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['asignatura']->value) {
$_smarty_tpl->tpl_vars['asignatura']->do_else = false;
?>
                                    <?php if ($_smarty_tpl->tpl_vars['asignatura']->value['id_asignatura'] == $_smarty_tpl->tpl_vars['clase']->value['id_asignatura']) {?>
                                        <?php echo $_smarty_tpl->tpl_vars['asignatura']->value['nombre'];?>

                                    <?php }?>
                                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                            </td>
                            <td><?php echo $_smarty_tpl->tpl_vars['clase']->value['horario'];?>
</td>
                            <td>
                                <form action="index.php" method="post">
    <input type="hidden" name="id_clase" value="<?php echo $_smarty_tpl->tpl_vars['clase']->value['id_clase'];?>
">
    <button name="accion" value="eliminarClase" type="submit">Eliminar</button>
</form>


                            </td>
                        </tr>
                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                </tbody>
            </table>
        <?php } else { ?>
            <p>No hay clases disponibles.</p>
        <?php }?>
    </div>
</body>
</html>
<?php }
}
