<?php
/* Smarty version 4.5.3, created on 2024-08-18 09:34:29
  from 'C:\xampp2\htdocs\progra3\progra3\colegio\view\templates\infoprofesor.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66c1a405167299_85356570',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3ceb17ee4ad3b06c1501b236ed5a94d127eff165' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\view\\templates\\infoprofesor.tpl',
      1 => 1723966465,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66c1a405167299_85356570 (Smarty_Internal_Template $_smarty_tpl) {
?><!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Información del Profesor</title>
    <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #343a40;
            color: #ffffff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
        }
        
        .navbar {
            background-color: #212529;
        }
        
        .navbar-brand {
            color: #ffffff;
        }
        .navbar-nav .nav-link {
            color: #ffffff;
        }
        .navbar-nav .nav-link:hover {
            color: #007bff;
        }

        .card {
            background-color: #495057;
            border: none;
            color: #ffffff;
            margin: 20px;
        }
        .card-header {
            background-color: #343a40;
            border-bottom: 1px solid #6c757d;
        }
        
        .btn-custom {
            background-color: #28a745;
            border: none;
        }
        .btn-custom:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="#">Sistema Escolar</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
           <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="profesor.php?accion=verinfoprofesor">Mi Perfil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="profesor.php?accion=clases">Mis Clases</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="profesor.php?accion=cerrarSesion">Cerrar Sesión</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Información del Profesor</h5>
            </div>
            <div class="card-body">
                <p><strong>ID:</strong> <?php echo $_smarty_tpl->tpl_vars['profesor']->value['id_profesor'];?>
</p>
                <p><strong>Nombre:</strong> <?php echo $_smarty_tpl->tpl_vars['profesor']->value['nombre'];?>
 <?php echo $_smarty_tpl->tpl_vars['profesor']->value['apellido'];?>
</p>
                <p><strong>Email:</strong> <?php echo $_smarty_tpl->tpl_vars['profesor']->value['email'];?>
</p>
                <p><strong>Teléfono:</strong> <?php echo $_smarty_tpl->tpl_vars['profesor']->value['telefono'];?>
</p>
                <p><strong>Especialidad:</strong> <?php echo $_smarty_tpl->tpl_vars['profesor']->value['especialidad'];?>
</p>
                <p><strong>Contraseña (hashed):</strong> <?php echo $_smarty_tpl->tpl_vars['profesor']->value['pass'];?>
</p> <!-- Displaying hashed password is generally not recommended -->
            </div>
        </div>

    </div>

    <?php echo '<script'; ?>
 src="assets/dist/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
