<?php
/* Smarty version 4.5.3, created on 2024-08-18 09:35:41
  from 'C:\xampp2\htdocs\progra3\progra3\colegio\view\templates\verestudiantesporclase.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66c1a44d285b31_40572958',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e90cb320ff39bfab4a084a0010daff968d70ee36' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\view\\templates\\verestudiantesporclase.tpl',
      1 => 1723966539,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66c1a44d285b31_40572958 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\libs\\smarty-4-5-3\\plugins\\modifier.count.php','function'=>'smarty_modifier_count',),));
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estudiantes por Materia - Sistema Escolar</title>
    <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #121212;
            color: #ffffff;
        }
        .navbar {
            background-color: #1f1f1f;
        }
        .navbar-brand, .nav-link {
            color: #ffffff !important;
        }
        .card {
            background-color: #1f1f1f;
            color: #ffffff;
            margin-bottom: 20px;
        }
        .btn-custom {
            background-color: #ff6600;
            border: none;
            color: #ffffff;
        }
        .btn-custom:hover {
            background-color: #e65c00;
            color: #ffffff;
        }
        .modal-content {
            background-color: #1f1f1f;
            color: #ffffff;
        }
        .form-control {
            background-color: #333333;
            color: #ffffff;
            border: 1px solid #444444;
        }
        .form-control:focus {
            background-color: #333333;
            color: #ffffff;
            border-color: #ff6600;
            box-shadow: 0 0 0 0.2rem rgba(255, 102, 0, 0.25);
        }
        .form-label {
            color: #ffffff;
        }
        .readonly-field {
            background-color: #444444;
            border: 1px solid #444444;
            color: #ffffff;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand" href="#">Sistema Escolar</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
           <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="profesor.php?accion=verinfoprofesor">Mi Perfil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="profesor.php?accion=clases">Mis Clases</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="profesor.php?accion=cerrarSesion">Cerrar Sesión</a>
                </li>
            </ul>
        </div>
    </nav>
    <div class="container">
        <h1 class="text-center mt-5">Estudiantes Inscritos en la Materia</h1>
        <?php if (smarty_modifier_count($_smarty_tpl->tpl_vars['estudiantes']->value) > 0) {?>
            <h2 class="text-center mt-3">Clase: <?php echo $_smarty_tpl->tpl_vars['clase']->value['nombre_clase'];?>
</h2>
            <table class="table table-dark mt-4">
                <thead>
                    <tr>
                        <th>ID Estudiante</th>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Calificación</th>
                        <th>Tardías</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['estudiantes']->value, 'estudiante');
$_smarty_tpl->tpl_vars['estudiante']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['estudiante']->value) {
$_smarty_tpl->tpl_vars['estudiante']->do_else = false;
?>
                        <tr>
                            <td><?php echo $_smarty_tpl->tpl_vars['estudiante']->value['id_estudiante'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['estudiante']->value['nombre'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['estudiante']->value['apellido'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['estudiante']->value['calificacion'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['estudiante']->value['tardias'];?>
</td>
                            <td>
                                <button type="button" class="btn btn-custom" data-bs-toggle="modal" data-bs-target="#ingresarDatosModal" data-id="<?php echo $_smarty_tpl->tpl_vars['estudiante']->value['id_estudiante'];?>
" data-nombre="<?php echo $_smarty_tpl->tpl_vars['estudiante']->value['nombre'];?>
" data-apellido="<?php echo $_smarty_tpl->tpl_vars['estudiante']->value['apellido'];?>
" data-calificacion="<?php echo $_smarty_tpl->tpl_vars['estudiante']->value['calificacion'];?>
" data-tardias="<?php echo $_smarty_tpl->tpl_vars['estudiante']->value['tardias'];?>
" data-id_clase="<?php echo $_smarty_tpl->tpl_vars['clase']->value['id_clase'];?>
">
                                    Actualizar Datos
                                </button>
                            </td>
                        </tr>
                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                </tbody>
            </table>
        <?php } else { ?>
            <p class="text-center">No hay estudiantes inscritos en esta materia.</p>
        <?php }?>
    </div>

    <!-- Modal para Ingresar Datos -->
    <div class="modal fade" id="ingresarDatosModal" tabindex="-1" aria-labelledby="ingresarDatosModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="ingresarDatosModalLabel">Ingresar Datos del Estudiante</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="post" action="profesor.php">
                        <div class="mb-3">
                            <label for="id_estudiante" class="form-label">ID Estudiante</label>
                            <div id="id_estudiante" class="form-control readonly-field"></div>
                        </div>
                        <div class="mb-3">
                            <label for="id_clase" class="form-label">ID Clase</label>
                            <div id="id_clase" class="form-control readonly-field"></div>
                        </div>
                        <div class="mb-3">
                            <label for="calificacion" class="form-label">Calificación</label>
                            <input type="number" id="calificacion" name="calificacion" min="0" max="100" class="form-control" placeholder="Calificación">
                        </div>
                        <div class="mb-3">
                            <label for="tardias" class="form-label">Número de Tardías</label>
                            <input type="number" id="tardias" name="tardias" min="0" class="form-control" placeholder="Número de Tardías">
                        </div>
                        <input type="hidden" id="id_estudiante_hidden" name="id_estudiante">
                        <input type="hidden" id="id_clase_hidden" name="id_clase">
                        <button type="submit" name="accion" value="actualizar_estudiante" class="btn btn-custom">Actualizar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php echo '<script'; ?>
 src="assets/dist/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
>
        document.addEventListener('DOMContentLoaded', function() {
            var ingresarDatosModal = document.getElementById('ingresarDatosModal');
            ingresarDatosModal.addEventListener('show.bs.modal', function(event) {
                var button = event.relatedTarget;
                var idEstudiante = button.getAttribute('data-id');
                var calificacion = button.getAttribute('data-calificacion');
                var tardias = button.getAttribute('data-tardias');
                var idClase = button.getAttribute('data-id_clase');

                var modalBodyInputIdEstudiante = ingresarDatosModal.querySelector('#id_estudiante');
                var modalBodyInputIdClase = ingresarDatosModal.querySelector('#id_clase');
                var modalBodyInputCalificacion = ingresarDatosModal.querySelector('#calificacion');
                var modalBodyInputTardias = ingresarDatosModal.querySelector('#tardias');
                var modalBodyInputIdEstudianteHidden = ingresarDatosModal.querySelector('#id_estudiante_hidden');
                var modalBodyInputIdClaseHidden = ingresarDatosModal.querySelector('#id_clase_hidden');

                modalBodyInputIdEstudiante.textContent = idEstudiante;
                modalBodyInputIdClase.textContent = idClase;
                modalBodyInputCalificacion.value = calificacion;
                modalBodyInputTardias.value = tardias;
                modalBodyInputIdEstudianteHidden.value = idEstudiante;
                modalBodyInputIdClaseHidden.value = idClase;
            });
        });
    <?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
