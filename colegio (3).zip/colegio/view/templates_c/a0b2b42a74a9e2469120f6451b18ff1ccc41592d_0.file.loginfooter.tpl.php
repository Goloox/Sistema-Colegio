<?php
/* Smarty version 4.5.3, created on 2024-07-11 18:59:55
  from 'C:\xampp\htdocs\progra3\proyecto\view\templates\loginfooter.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66900f8b51a4c0_24966993',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a0b2b42a74a9e2469120f6451b18ff1ccc41592d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\progra3\\proyecto\\view\\templates\\loginfooter.tpl',
      1 => 1720716927,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66900f8b51a4c0_24966993 (Smarty_Internal_Template $_smarty_tpl) {
?> </body>
</html>
<?php }
}
