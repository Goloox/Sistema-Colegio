<?php
/* Smarty version 4.5.3, created on 2024-08-21 03:28:09
  from 'C:\xampp2\htdocs\progra3\progra3\colegio\view\templates\profeclases.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66c542a9352ab6_10283605',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '284bff66381ff1292d3a31f66b0e815ef633c8d9' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\colegio\\view\\templates\\profeclases.tpl',
      1 => 1724203688,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66c542a9352ab6_10283605 (Smarty_Internal_Template $_smarty_tpl) {
?><!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Clases - Sistema Escolar</title>
    <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #343a40;
            color: #ffffff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
        }
        
        .navbar {
            background-color: #212529;
        }
        
        .navbar-brand {
            color: #ffffff;
        }
        .navbar-nav .nav-link {
            color: #ffffff;
        }
        .navbar-nav .nav-link:hover {
            color: #007bff;
        }

        .card {
            background-color: #495057;
            border: none;
            color: #ffffff;
            margin: 20px;
        }
        .card-header {
            background-color: #343a40;
            border-bottom: 1px solid #6c757d;
        }
        
        .btn-custom {
            background-color: #28a745;
            border: none;
        }
        .btn-custom:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="#">Sistema Escolar</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
           <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="profesor.php?accion=verinfoprofesor">Mi Perfil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="profesor.php?accion=clases">Mis Clases</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="profesor.php?accion=cerrarSesion">Cerrar Sesión</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Mis Clases</h5>
            </div>
            <div class="card-body">
                <?php if ((isset($_smarty_tpl->tpl_vars['clases']->value)) && $_smarty_tpl->tpl_vars['clases']->value) {?>
                    <table class="table table-dark">
                        <thead>
                            <tr>
                                <th>ID Clase</th>
                                <th>Nombre</th>
                                <th>Grado</th>
                                <th>Asignatura</th>
                                <th>Horario</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['clases']->value, 'clase');
$_smarty_tpl->tpl_vars['clase']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['clase']->value) {
$_smarty_tpl->tpl_vars['clase']->do_else = false;
?>
                                <tr>
                                    <td><?php echo $_smarty_tpl->tpl_vars['clase']->value['id_clase'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['clase']->value['nombre'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['clase']->value['grado'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['clase']->value['id_asignatura'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['clase']->value['horario'];?>
</td>
                                    <td>
                                        <a href="profesor.php?accion=verestudiantes&id_clase=<?php echo $_smarty_tpl->tpl_vars['clase']->value['id_clase'];?>
" class="btn btn-custom">Ver Estudiantes</a>
                                    </td>
                                </tr>
                            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                        </tbody>
                    </table>
                <?php } else { ?>
                    <p>No tienes clases asignadas.</p>
                <?php }?>
            </div>
        </div>
  
    </div>

    <?php echo '<script'; ?>
 src="assets/dist/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
