<?php
/* Smarty version 4.5.3, created on 2024-08-07 18:03:58
  from 'C:\xampp2\htdocs\progra3\progra3\proyectocorto\view\templates\listarcuentas.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66b39aee79e509_81990762',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '18c778b50b5665852225522ebf425384d28acabe' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyectocorto\\view\\templates\\listarcuentas.tpl',
      1 => 1723046635,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66b39aee79e509_81990762 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp2\\htdocs\\progra3\\progra3\\proyectocorto\\libs\\smarty-4-5-3\\plugins\\modifier.count.php','function'=>'smarty_modifier_count',),));
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listar Cuentas - Banco</title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #121212; /* Tema oscuro */
            color: #ffffff;
        }
        .navbar {
            width: 100%;
            background-color: #1E1E1E;
            padding: 15px 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            top: 0;
            left: 0;
        }
        .navbar .logo img {
            width: 100px;
            height: auto;
        }
        .navbar ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }
        .navbar ul li {
            margin-left: 20px;
        }
        .navbar ul li a {
            color: #ffffff;
            text-decoration: none;
            font-size: 16px;
        }
        .navbar ul li a:hover {
            color: #ff9800;
        }
        .content {
            text-align: center;
            padding: 100px 20px 20px; 
        }
        .content h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }
        .content table {
            border-collapse: collapse;
            width: 100%;
            max-width: 800px;
            margin: 0 auto;
            margin-bottom: 30px;
        }
        .content table, .content th, .content td {
            border: 1px solid #ffffff;
        }
        .content th, .content td {
            padding: 10px;
            text-align: left;
        }
        .actions {
            display: flex;
            flex-direction: column;
            gap: 10px;
            align-items: center;
        }
        .actions form {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        .actions button {
            padding: 12px 25px;
            border-radius: 8px;
            background-color: #ff9800;
            color: #fff;
            border: none;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        .actions button:hover {
            background-color: #e68a00;
            transform: scale(1.05);
        }
        .actions button:active {
            transform: scale(0.95);
        }
        /* Responsividad */
        @media (max-width: 768px) {
            .navbar ul {
                flex-direction: column;
                align-items: center;
            }
            .navbar ul li {
                margin-left: 0;
                margin-bottom: 10px;
            }
            .actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="navbar">
        <div class="logo">
            <img src="logo.png" alt="Logo del Banco">
        </div>
        <ul>
            <li><a href="#">Inicio</a></li>
            <li><a href="#">Servicios</a></li>
            <li><a href="#">Contacto</a></li>
           <li><a href="index.php?accion=cerrar_sesion">Cerrar Sesión</a></li>
        </ul>
    </div>
    <div class="content">
        <h1>Mis Cuentas</h1>
        <?php if ((isset($_smarty_tpl->tpl_vars['cuentas']->value)) && smarty_modifier_count($_smarty_tpl->tpl_vars['cuentas']->value) > 0) {?>
            <table>
                <thead>
                    <tr>
                        <th>Número de Cuenta</th>
                        <th>Tipo de Cuenta</th>
                        <th>Saldo</th>
                        <th>Fecha de Creación</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['cuentas']->value, 'cuenta');
$_smarty_tpl->tpl_vars['cuenta']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['cuenta']->value) {
$_smarty_tpl->tpl_vars['cuenta']->do_else = false;
?>
                        <tr>
                            <td><?php echo $_smarty_tpl->tpl_vars['cuenta']->value['numero_cuenta'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['cuenta']->value['tipo_cuenta'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['cuenta']->value['saldo'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['cuenta']->value['fecha_creacion'];?>
</td>
                            <td class="actions">
                                <form method="POST" action="index.php">
                                    <input type="hidden" name="accion" value="borrar_cuenta">
                                    <input type="hidden" name="numero_cuenta" value="<?php echo $_smarty_tpl->tpl_vars['cuenta']->value['numero_cuenta'];?>
">
                                    <button type="submit">Borrar</button>
                                </form>
                                <form method="POST" action="index.php">
                                    <input type="hidden" name="accion" value="realizartransferencia">
                                    <input type="hidden" name="numero_cuenta" value="<?php echo $_smarty_tpl->tpl_vars['cuenta']->value['numero_cuenta'];?>
">
                                    <input type="number" name="monto" placeholder="Monto">
                                    <input type="text" name="cuenta_destino" placeholder="Cuenta Destino">
                                    <button type="submit">Transferir</button>
                                </form>
                                <form method="POST" action="index.php">
                                    <input type="hidden" name="accion" value="retiro_efectivo">
                                    <input type="hidden" name="numero_cuenta" value="<?php echo $_smarty_tpl->tpl_vars['cuenta']->value['numero_cuenta'];?>
">
                                    <input type="number" name="monto" placeholder="Monto">
                                    <button type="submit">Retirar</button>
                                </form>
                            </td>
                        </tr>
                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                </tbody>
            </table>
        <?php } else { ?>
            <p>No hay cuentas disponibles.</p>
        <?php }?>
        <div class="buttons">
    
            </form>
        </div>
    </div>
</body>
</html>
<?php }
}
