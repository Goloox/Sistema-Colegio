<?php
/* Smarty version 4.5.3, created on 2024-08-07 17:57:14
  from 'C:\xampp2\htdocs\progra3\progra3\proyectocorto\view\templates\crear_cuenta.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_66b3995a5861b4_88015767',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bab9b9398a89324980635646ef6b4ab19a7b1336' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\progra3\\progra3\\proyectocorto\\view\\templates\\crear_cuenta.tpl',
      1 => 1723040597,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66b3995a5861b4_88015767 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Cuenta - Banco</title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #121212; /* Tema oscuro */
            color: #ffffff;
        }
        .navbar {
            width: 100%;
            background-color: #1E1E1E;
            padding: 15px 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            top: 0;
            left: 0;
        }
        .navbar .logo img {
            width: 100px;
            height: auto;
        }
        .navbar ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }
        .navbar ul li {
            margin-left: 20px;
        }
        .navbar ul li a {
            color: #ffffff;
            text-decoration: none;
            font-size: 16px;
        }
        .navbar ul li a:hover {
            color: #ff9800;
        }
        .content {
            text-align: center;
            padding: 100px 20px 20px;
            margin-top: 60px; /* Ajusta el margen superior para evitar que el contenido se superponga con la navbar */
        }
        .content h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }
        .content p {
            font-size: 18px;
            margin-bottom: 30px;
            color: #aaaaaa;
        }
        .form-container {
            background-color: #1E1E1E;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
            width: 100%;
            max-width: 600px;
            margin: 0 auto;
        }
        .form-container img {
            display: block;
            margin: 0 auto 20px;
        }
        .form-container label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-container input,
        .form-container select {
            width: calc(100% - 30px); /* Ajusta el ancho para que los inputs y selects se alineen correctamente */
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid #333;
            border-radius: 5px;
            background-color: #121212;
            color: #ffffff;
            font-size: 16px;
        }
        .form-container button {
            padding: 15px 30px;
            border-radius: 5px;
            background-color: #ff9800;
            color: #fff;
            border: none;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .form-container button:hover {
            background-color: #e68a00;
        }
        /* Responsividad */
        @media (max-width: 768px) {
            .navbar ul {
                flex-direction: column;
                align-items: center;
            }
            .navbar ul li {
                margin-left: 0;
                margin-bottom: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="navbar">
        <div class="logo">
            <img src="logo.png" alt="Logo del Banco">
        </div>
        <ul>
            <li><a href="#">Inicio</a></li>
            <li><a href="#">Servicios</a></li>
            <li><a href="#">Contacto</a></li>
            <li><a href="#">Cerrar Sesión</a></li>
        </ul>
    </div>
    <div class="content">
        <h1>Crear Cuenta</h1>
        <p>Complete el siguiente formulario para crear una nueva cuenta.</p>
        <div class="form-container">
            <img src="img/logo.png" alt="Logo" width="72" height="57">
            <form id="crear_cuenta" action="index.php" method="post">
                <input type="hidden" name="accion" value="crear_cuenta">

                <div class="form-floating">
                    <input type="email" name="email" class="form-control" id="floatingInput" placeholder="name@example.com" required>
                    <label for="floatingInput">Email address</label>
                </div>
                <div class="form-floating">
                    <input type="password" name="pass" class="form-control" id="floatingPassword" placeholder="Password" required>
                    <label for="floatingPassword">Password</label>
                </div>

                <label for="id_usuario">ID Usuario:</label>
                <input type="number" id="id_usuario" name="id_usuario" required>

                <label for="numero_cuenta">Número de Cuenta:</label>
                <input type="text" id="numero_cuenta" name="numero_cuenta" required>

                <label for="tipo_cuenta">Tipo de Cuenta:</label>
                <select id="tipo_cuenta" name="tipo_cuenta" required>
                    <option value="Ahorro">Ahorro</option>
                    <option value="Corriente">Corriente</option>
                </select>

                <label for="saldo">Saldo Inicial:</label>
                <input type="number" id="saldo" name="saldo" min="0" required>

                <label for="fecha_creacion">Fecha de Creación:</label>
                <input type="date" id="fecha_creacion" name="fecha_creacion" required>

                <button type="submit" name="accion" value="crear_cuenta">Crear Cuenta</button>
            </form>
        </div>
    </div>
</body>
</html>
<?php }
}
