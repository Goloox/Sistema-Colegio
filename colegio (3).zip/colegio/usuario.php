<?php

require_once 'control/usuariocontrol.php';

$controller = new control();
$controller->gestor_procesos();
?>
