<?php
require_once "libs/smarty-4-5-3/config.php";
require_once "model/profesormodel.php";

class control {
    private $model;
    private $view;

    public function __construct() {
        session_start(); // Start the session
        $this->model = new model();
        $this->view  = new Smarty();
        $this->view->setTemplateDir('view/templates/');
        $this->view->setCompileDir('view/templates_c/');
        $this->view->setCacheDir('view/cache/');
        $this->view->setConfigDir('view/configs/');
    }

    public function gestor_procesos() {
        $accion = $_REQUEST["accion"] ?? 'login'; // Default action to 'login'

        switch ($accion) {
            case 'veradmin':
                $this->mostrarLoginAdmin();
                break;
            case 'clases':
                $this->mostrarClasesProfesor();
                break;
            case 'verprofe':
                $this->mostrarLoginProfesor();
                break;
            case 'verestu':
                $this->mostrarLoginEstudiante();
                break;
            case 'loginprofesor':
                $this->validarLoginProfesor();
                break;
            case 'verestudiantes':
                $this->mostrarEstudiantes();
                break;
            case 'actualizarCalificacion':
                $this->actualizarCalificacionEstudiante();
                break;
            case 'actualizar_estudiante':
                $this->actualizarDatosEstudiante();
                break;
            case 'veractualizar_estudiante':
                $this->vercambiarestudiante();
                break;
            case 'verinfoprofesor':
                $this->mostrarInfoProfesor();
                break;
                case 'normal':
                    $this->view->display('usuario_normal.tpl');
                    break;
            case 'CerrarSesion':
                $this->cerrarSesion();
                break;
            default:
                $this->mostrarLoginProfesor();
                break;
        }
    }

    // Mostrar el login para admin
    public function mostrarLoginAdmin() {
        $this->view->display('login.tpl');
    }

    // Mostrar las clases del profesor
    public function mostrarClasesProfesor() {
        $id_profesor = $_SESSION['id_usuario'];
        $clases = $this->model->obtenerClasesProfesor($id_profesor);
        $_SESSION['id_clase'] = $clases[0]['id_clase'] ?? null; 

        if ($clases) {
            $this->view->assign('clases', $clases);
            $this->view->display('profeclases.tpl');
        } else {
            $this->view->assign('error', 'No se encontraron clases asignadas.');
            $this->view->display('error.tpl');
        }
    }

    // Mostrar el login para profesor
    public function mostrarLoginProfesor() {
        $this->view->display('loginprofesor.tpl');
    }

    // Mostrar el login para estudiante
    public function mostrarLoginEstudiante() {
        $this->view->display('loginestudiante.tpl');
    }

    // Validar el login del profesor
    public function validarLoginProfesor() {
        if (isset($_REQUEST["email"]) && isset($_REQUEST["pass"])) {
            $email = $_REQUEST["email"];
            $pass  = $_REQUEST["pass"];
            $resultado = $this->model->autenticarProfesor($email, $pass);

            if (empty($resultado)) {
                $this->view->assign('error', 'Autenticación fallida.');
                $this->view->display('usuario_normal.tpl');
            } else {
                $_SESSION['id_usuario'] = $resultado['id_profesor'];
                $this->view->display('profesorhome.tpl');
            }
        } else {
            $this->view->assign('error', 'Error, faltan email o contraseña.');
            $this->view->display('login.tpl');
        }
    }

    // Mostrar los estudiantes de una clase
    public function mostrarEstudiantes() {
        $id_clase = $_REQUEST['id_clase'] ?? null;
        if ($id_clase) {
            $estudiantes = $this->model->obtenerEstudiantesPorClase($id_clase);
            $clase = $this->model->obtenerClasePorId($id_clase); // Fetch class details

            if ($estudiantes && $clase) {
                $this->view->assign('estudiantes', $estudiantes);
                $this->view->assign('clase', $clase); // Pass class details to view
                $this->view->display('verestudiantesporclase.tpl');
            } else {
                $this->view->assign('error', 'No se encontraron estudiantes o clase.');
                $this->view->display('error.tpl');
            }
        } else {
            $this->view->assign('error', 'ID de clase no proporcionado.');
            $this->view->display('error.tpl');
        }
    }


    
    public function vercambiarestudiante() {
        $id_clase = $_REQUEST['id_clase'] ?? null;
        $id_estudiante = $_REQUEST['id_estudiante'] ?? null;
    
        if ($id_clase && $id_estudiante) {
            // Obtener la lista de estudiantes y la información del estudiante seleccionado
            $estudiantes = $this->model->obtenerEstudiantesPorClase($id_clase);
            $estudiante = $this->model->obtenerEstudiantePorId($id_estudiante);
            
            if ($estudiantes && $estudiante) {
                $this->view->assign('estudiantes', $estudiantes);
                $this->view->assign('estudiante', $estudiante);
                $this->view->assign('id_clase', $id_clase);
                $this->view->display('verestudiantesporclase.tpl'); // Template to display students
            } else {
                $this->view->assign('error', 'No se encontraron estudiantes o el estudiante seleccionado no existe.');
                $this->view->display('error.tpl');
            }
        } else {
            $this->view->assign('error', 'ID de clase o ID de estudiante no proporcionados.');
            $this->view->display('error.tpl'); // Template to display error message
        }
    }
    public function actualizarDatosEstudiante() {
        if (isset($_POST['id_estudiante'], $_POST['calificacion'], $_POST['tardias'], $_POST['id_clase'])) {
            $id_estudiante = $_POST['id_estudiante'];
            $calificacion = $_POST['calificacion'];
            $tardias = $_POST['tardias'];
            $id_clase = $_POST['id_clase'];
    
            $resultado = $this->model->actualizarCalificacionTardias($id_estudiante, $id_clase, $calificacion, $tardias);
    
            if ($resultado) {
                $_SESSION['mensaje'] = 'Datos del estudiante actualizados con éxito.';
            } else {
                $_SESSION['error'] = 'No se pudo actualizar los datos del estudiante.';
            }
    
            header('Location: ?accion=verestudiantes&id_clase=' . urlencode($id_clase));
            exit();
        } else {
            $_SESSION['error'] = 'Faltan datos para actualizar el estudiante.';
            $this->view->display('error.tpl');
        }
    }
    

    // Actualizar la calificación de un estudiante
    public function actualizarCalificacionEstudiante() {
        if (isset($_REQUEST['id_estudiante'], $_REQUEST['id_clase'], $_REQUEST['calificacion'])) {
            $id_estudiante = $_REQUEST['id_estudiante'];
            $id_clase = $_REQUEST['id_clase'];
            $calificacion = $_REQUEST['calificacion'];

            $resultado = $this->model->actualizarCalificacion($id_estudiante, $id_clase, $calificacion);
            if ($resultado) {
                $_SESSION['mensaje'] = 'Calificación actualizada con éxito.';
            } else {
                $_SESSION['error'] = 'No se pudo actualizar la calificación.';
            }

            header('Location: ?accion=verestudiantes&id_clase=' . urlencode($id_clase));
            exit();
        } else {
            $_SESSION['error'] = 'Faltan datos para actualizar la calificación.';
            $this->view->display('error.tpl');
        }
    }

    // Actualizar los datos del estudiante
  

    // Agregar una tardía a un estudiante
    public function agregarTardiaEstudiante() {
        if (isset($_REQUEST['id_estudiante'], $_REQUEST['id_clase'])) {
            $id_estudiante = $_REQUEST['id_estudiante'];
            $id_clase = $_REQUEST['id_clase'];

            $resultado = $this->model->agregarTardia($id_estudiante, $id_clase);
            if ($resultado) {
                $_SESSION['mensaje'] = 'Tardía agregada con éxito.';
            } else {
                $_SESSION['error'] = 'No se pudo agregar la tardía.';
            }
            header('Location: ?accion=verestudiantes&id_clase=' . urlencode($id_clase));
            exit();
        } else {
            $_SESSION['error'] = 'Faltan datos para agregar la tardía.';
            $this->view->display('error.tpl');
        }
    }


    

    // Mostrar información del profesor
    public function mostrarInfoProfesor() {
        $id_profesor = $_SESSION['id_usuario'];
        $profesor = $this->model->obtenerInfoProfesor($id_profesor);
        if ($profesor) {
            $this->view->assign('profesor', $profesor);
            $this->view->display('infoprofesor.tpl');
        } else {
            $this->view->assign('error', 'No se encontró información del profesor.');
            $this->view->display('error.tpl');
        }
    }

    // Cerrar sesión
    public function cerrarSesion() {
        session_destroy();
        header('Location: ?accion=veradmin');
        exit();
    }
}
