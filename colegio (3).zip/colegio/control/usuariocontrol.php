<?php
require_once "libs/smarty-4-5-3/config.php";


class Control {
    private $model;
    private $view;

    public function __construct() {


        $this->view  = new Smarty();
        $this->view->setTemplateDir('view/templates/');
        $this->view->setCompileDir('view/templates_c/');
        $this->view->setCacheDir('view/cache/');
        $this->view->setConfigDir('view/configs/');
    }

    public function gestor_procesos() {
        $accion = $_REQUEST["accion"] ?? 'login'; // Default action is 'login'

        switch ($accion) {
            case 'ver_caracteristicas':
                $this->view->display('caracteristicas.tpl');
                break;
            case 'ver_servicios':
                $this->view->display('servicios.tpl');
                break;
            case 'ver_informacion':
                $this->view->display('informacioncole.tpl');
                break;
            case 'ver_proyectos':
                $this->view->display('proyectos.tpl');
                break;
            case 'estudiantelogin':
                $this->cl_validarlogin();
                break;
            case 'verestudiantes':
                $this->verEstudiantes();
                break;
            case 'verinfoestudiante':
                $this->verEstudianteHome();
                break;
            case 'matricular':
                $this->verClases();
                break;
            case 'matricularclase':
                $this->matricularEstudiante();
                break;
            case 'verclasesestudiante':
                $this->verClasesEstudiante();
                break;
            case'ver_clase':
                $this->verEstudiantesPorClase();
            break;
            case 'CerrarSesion':
                $this->cerrarSesion();
                break;
            case 'normal':
            $this->view->display('usuario_normal.tpl');
            break;
            default:
                $this->view->display('usuario_normal.tpl');
                break;
        }}}