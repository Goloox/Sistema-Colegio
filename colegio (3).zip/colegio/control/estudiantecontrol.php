<?php
require_once "libs/smarty-4-5-3/config.php";
require_once "model/estudiantemodel.php";

class Control {
    private $model;
    private $view;

    public function __construct() {
        session_start(); // Start session
        $this->model = new Model();
        $this->view  = new Smarty();
        $this->view->setTemplateDir('view/templates/');
        $this->view->setCompileDir('view/templates_c/');
        $this->view->setCacheDir('view/cache/');
        $this->view->setConfigDir('view/configs/');
    }

    public function gestor_procesos() {
        $accion = $_REQUEST["accion"] ?? 'login'; // Default action is 'login'

        switch ($accion) {
            case 'veradmin':
                $this->view->display('login.tpl');
                break;
            case 'clases':
                $this->verClases();
                break;
            case 'verprofe':
                $this->view->display('loginprofesor.tpl');
                break;
            case 'verestu':
                $this->view->display('loginestudiante.tpl');
                break;
            case 'estudiantelogin':
                $this->cl_validarlogin();
                break;
            case 'verestudiantes':
                $this->verEstudiantes();
                break;
            case 'verinfoestudiante':
                $this->verEstudianteHome();
                break;
            case 'matricular':
                $this->verClases();
                break;
            case 'matricularclase':
                $this->matricularEstudiante();
                break;
            case 'verclasesestudiante':
                $this->verClasesEstudiante();
                break;
            case'ver_clase':
                $this->verEstudiantesPorClase();
            break;
            case 'CerrarSesion':
                $this->cerrarSesion();
                break;
                case 'registrarse':
                    $this->view->display('signin.tpl');
                case 'signin':
                    $this->registrarse();
            case 'normal':
            $this->view->display('usuario_normal.tpl');
            break;
            default:
                $this->view->display('usuario_normal.tpl');
                break;
        }
    }


    public function registrarse() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $nombre = $_POST['nombre'];
            $apellido = $_POST['apellido'];
            $fecha_nacimiento = $_POST['fecha_nacimiento'];
            $grado = $_POST['grado'];
            $email = $_POST['email'];
            $pass = $_POST['pass'];
            $telefono = $_POST['telefono'];

            // Validar los datos aquí, como verificar si el email ya existe, etc.

            if ($this->model->registrarEstudiante($nombre, $apellido, $fecha_nacimiento, $grado, $email, $pass, $telefono)) {
                $this->view->assign('mensaje', 'Registro exitoso');
            } else {
                $this->view->assign('mensaje', 'Error en el registro');
            }

            $this->view->display('loginestudiante.tpl');
        } else {
            $this->view->display('signin.tpl');
        }
    }

    public function verEstudiantesPorClase() {
        if (isset($_REQUEST['id_clase'])) {
            $id_clase = $_REQUEST['id_clase'];
            $estudiantes = $this->model->obtenerEstudiantesPorClase($id_clase);
            $this->view->assign('estudiantes', $estudiantes);
            $this->view->display('estudiantes.tpl');
        } else {
            $this->view->assign('error', 'ID de clase no disponible.');
            $this->view->display('error.tpl');
        }
    }

    public function verClasesEstudiante() {
        if (isset($_SESSION['id_usuario'])) {
            $id_estudiante = $_SESSION['id_usuario'];
            $clases = $this->model->obtenerClasesPorEstudiante($id_estudiante); // Asumiendo que esta función existe y retorna las clases
            $this->view->assign('clases', $clases);
            $this->view->display('verclasesestudiante.tpl');
        } else {
            $this->view->assign('error', 'ID de estudiante no disponible.');
            $this->view->display('error.tpl');
        }
    }

    public function matricularEstudiante() {
        if (isset($_SESSION['id_usuario']) && isset($_REQUEST['id_clase'])) {
            $id_estudiante = $_SESSION['id_usuario'];
            $id_clase = $_REQUEST['id_clase'];

            $resultado = $this->model->matricularEstudianteEnClase($id_estudiante, $id_clase);
            if ($resultado) {
                $this->view->display('homeestudiante.tpl');
            } else {
                $this->view->assign('error', 'No se pudo matricular al estudiante en la clase.');
                $this->view->display('error.tpl');
            }
        } else {
            $this->view->assign('error', 'ID de estudiante o clase no disponible.');
            $this->view->display('error.tpl');
        }
    }

    public function verClases() {
        $clases = $this->model->obtenerClases();
        $profesores = $this->model->obtenerProfesores(); // Fetch list of professors
        $this->view->assign('clases', $clases);
        $this->view->assign('profesores', $profesores); // Assign list of professors
        $this->view->display('matricular.tpl');
    }
    
    public function verEstudiantes() {
        // Implement this method if you need to display student information
        // This is a placeholder method
        $estudiantes = $this->model->obtenerEstudiantes();
        $this->view->assign('estudiantes', $estudiantes);
        $this->view->display('verestudiantes.tpl');
    }
    
    public function verInfoProfesor() {
        // Implement this method if you need to display professor information
        // This is a placeholder method
        $profesores = $this->model->obtenerProfesores();
        $this->view->assign('profesores', $profesores);
        $this->view->display('verinfoProfesor.tpl');
    }

    public function verInfoEstudiante() {
        $id_estudiante = $_SESSION['id_usuario'];
        $estudiante = $this->model->obtenerInfoEstudiante($id_estudiante); // Changed variable name to $estudiante
        if ($estudiante) {
            $this->view->assign('estudiante', $estudiante);
            $this->view->display('infoestudiante.tpl');
        } else {
            $this->view->assign('error', 'No se encontró información del estudiante.'); // Changed error message to reflect 'estudiante'
            $this->view->display('error.tpl');
        }
    }
    
    
    public function verEstudianteHome() {
        if (isset($_SESSION['id_usuario'])) {
            $id_estudiante = $_SESSION['id_usuario'];
            $estudiante = $this->model->obtenerInfoEstudiante($id_estudiante);
            if ($estudiante) {
                // Assign data from the estudiante array
                $this->view->assign('id_estudiante', $estudiante['id_estudiante']);
                $this->view->assign('nombre', $estudiante['nombre']);
                $this->view->assign('apellido', $estudiante['apellido']);
                $this->view->assign('email', $estudiante['email']);
                $this->view->assign('telefono', $estudiante['telefono']);
                
                // Assign default values for missing fields
                $this->view->assign('fecha_nacimiento', $estudiante['fecha_nacimiento']);
                $this->view->assign('grado', $estudiante['grado']);
                $this->view->assign('pass', $estudiante['pass']);
                
                // Display the view
                $this->view->display('infoestudiante.tpl');
            } else {
                $this->view->assign('error', 'No se encontró información del estudiante.');
                $this->view->display('error.tpl');
            }
        } else {
            $this->view->assign('error', 'No se encontró el ID del estudiante en la sesión.');
            $this->view->display('error.tpl');
        }
    }
    

    public function cl_validarlogin() {
        if (isset($_REQUEST["email"]) && isset($_REQUEST["pass"])) {
            $email = $_REQUEST["email"];
            $pass  = $_REQUEST["pass"];
    
            $resultado = $this->model->autenticarestudiante($email, $pass);
    
            if ($resultado) {
                $_SESSION['id_usuario'] = $resultado['id_estudiante']; // Guarda el ID del usuario en la sesión
                $this->view->display('homeestudiante.tpl');
            } else {
                $this->view->assign('error', 'Autenticación fallida.');
                $this->view->display('usuario_normal.tpl');
            }
        } else {
            $this->view->assign('error', 'Error, faltan email o contraseña.');
            $this->view->display('login.tpl');
        }
    }

    public function cerrarSesion() {
        session_unset();
        session_destroy();
        $this->view->display('login.tpl');
    }
}
?>
