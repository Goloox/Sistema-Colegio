<?php
require_once "libs/smarty-4-5-3/config.php";
require_once "model/model.php";

class control {
    private $model;
    private $view;

    public function __construct() {
        $this->model = new model();
        $this->view  = new Smarty();
        $this->view->setTemplateDir('view/templates/');
        $this->view->setCompileDir('view/templates_c/');
        $this->view->setCacheDir('view/cache/');
        $this->view->setConfigDir('view/configs/');
    }

    public function gestor_procesos() {
        if (isset($_REQUEST["accion"])) {
            $accion = $_REQUEST["accion"];
            switch ($accion) {
                case 'veradmin':
                    $this->view->display('login.tpl');
                    break;
                case 'verprofe':
                    $this->view->display('loginprofesor.tpl');
                    break;
                case 'verestu':
                    $this->view->display('loginestudiante.tpl');
                    break;
                case 'Home':
                    $this->view->display('adminhome.tpl');
                    break;
                case 'loginadministrador':
                    $this->autenticarAdministrador();
                    break;
                case 'estudiante':
                    $this->autenticarEstudiante();
                    break;
                case 'loginprofesor':
                    $this->autenticarProfesor();
                    break;
                case 'gestionarasignaturasver':
                    $this->view->display('gestionarasignaturas.tpl');
                    break;
                case 'gestionar_clases_ver':
                    $this->view->display('gestionarclases.tpl');
                    break;
                case 'guardar_asignatura':
                    $this->procesarGuardarAsignatura();
                    break;
                    case 'gestionar_estudiantes':
                        $this->gestionar_estudiantes();
                        break;
                case 'gestionar_clases':
                    $this->gestionar_clases();
                    break;
                case 'guardar_clase':
                    $this->guardar_clase();
                    break;
                case 'eliminarClase':
                    $this->eliminarClase();
                    break;
                case 'gestionar_profesores':
                    $this->gestionar_profesores();
                    break;
                case 'guardar_profesor':
                    $this->guardarProfesor();
                    break;
                case 'editar_profesor':
                    $this->actualizar_profesor();
                    break;
                case 'eliminar_profesor':
                    $this->eliminarProfesor();
                    break;
                case 'guardar_estudiante':
                    $this->guardar_estudiante();
                    break;
                case 'actualizar_estudiante':
                    $this->actualizar_estudiante();
                    break;
                case 'eliminar_estudiante':
                    $this->eliminar_estudiante();
                    break;
                case 'gestionar_estudiantes':
                    $this->ver_estudiantes_inscritos();
                    break;
                case 'verporclase':
                    $this->ver_estudiantes_inscritos();
                    break;
                case 'CerrarSesion':
                    session_destroy();
                    $this->view->display('login.tpl');
                    break;
                    case 'ver_clases':
                        $this->ver_clases();
                        break;
                default:
                    $this->view->display('login.tpl');
                    break;
            }
        } else {
            $this->view->display('login.tpl');
        }
    }

    public function ver_clases() {
        // Obtener todas las clases
        $clases = $this->model->obtenerClases();
        $this->view->assign('clases', $clases);

        // Mostrar la vista para ver estudiantes por clase
        $this->view->display('adminest.tpl');
    }

    public function ver_estudiantes_inscritos() {
        if (isset($_POST['id_clase'])) {
            $id_clase = $_POST['id_clase'];
            // Obtener estudiantes inscritos en la clase seleccionada
            $estudiantes = $this->model->obtenerEstudiantesPorClase($id_clase);
        } else {
            $estudiantes = [];
        }

        // Obtener todas las clases para el select
        $clases = $this->model->obtenerClases();

        $this->view->assign('clases', $clases);
        $this->view->assign('estudiantes', $estudiantes);
        $this->view->display('adminest.tpl');
    }

  


    
    public function mostrarEstudiantes($mensaje = '') {
        $estudiantes = $this->model->obtenerInfoEstudiante(); // Asegúrate de que esto incluye 'grado'
        
        // Asignar datos al template
        $this->view->assign('estudiantes', $estudiantes);
        $this->view->assign('mensaje', $mensaje);
        $this->view->display('gestionarestudiantes.tpl');
    }

    public function gestionar_estudiantes() {
        // Obtiene la información de todos los estudiantes a través del modelo
        $estudiantes = $this->model->obtenerInfoEstudiante();
        
        // Asigna los datos de los estudiantes a la vista con la clave 'estudiantes'
        $this->view->assign('estudiantes', $estudiantes);
        
        // Muestra la plantilla 'gestionarestudiantes.tpl' utilizando la vista
        $this->view->display('gestionarestudiantes.tpl');
    }
    
    public function guardar_estudiante() {
        // Obtener datos del formulario
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $email = $_POST['email'];
        $pass = $_POST['pass'];
        $grado = $_POST['grado'];
        
        // Validar y procesar los datos
        $this->model->guardarEstudiante($nombre, $apellido, $email, $pass, $grado);
    
        // Redirigir o mostrar mensaje
        $mensaje = "Estudiante guardado exitosamente";
        $this->mostrarEstudiantes($mensaje);
    }
    
    public function actualizar_estudiante() {
        // Obtener datos del formulario
        $id = $_POST['id'];
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $email = $_POST['email'];
        $pass = $_POST['pass'];
        $grado = $_POST['grado'];
    
        // Validar y procesar los datos
        $this->model->actualizarEstudiante($id, $nombre, $apellido, $email, $pass, $grado);
    
        // Redirigir o mostrar mensaje
        $mensaje = "Estudiante actualizado exitosamente";
        $this->mostrarEstudiantes($mensaje);
    }
    
    public function eliminar_estudiante() {
        $id = $_POST['id'];
        $this->model->eliminarEstudiante($id);
        header("Location: index.php?accion=gestionar_estudiantes");
    }

    public function gestionar_profesores() {
        // Obtiene la lista de profesores a través del modelo
        $profesores = $this->model->obtenerListaProfesores();
        
        // Asigna los datos de los profesores a la vista
        $this->view->assign('profesores', $profesores);
        
        // Muestra la plantilla 'gestionarprofesores.tpl' utilizando la vista
        $this->view->display('gestionarprofesores.tpl');
    }


    public function actualizar_profesor() {
        // Obtener datos del formulario
        $id = $_POST['id'];
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $email = $_POST['email'];
        $pass = $_POST['pass'];
        $telefono = $_POST['telefono'];
        $especialidad = $_POST['especialidad'];
    
        // Validar y procesar los datos
        $resultado = $this->model->actualizarProfesor($id, $nombre, $apellido, $email, $pass, $telefono, $especialidad);
    
        if ($resultado) {
            $mensaje = "Profesor actualizado exitosamente";
        } else {
            $mensaje = "Error al actualizar el profesor";
        }
    
        $this->mostrarProfesores($mensaje);
    }
    public function eliminarProfesor() {
        $id = $_POST['id'];
        $resultado = $this->model->eliminarProfesor($id);
    
        if ($resultado) {
            $mensaje = "Profesor eliminado exitosamente";
        } else {
            $mensaje = "Error al eliminar el profesor";
        }
    
        header("Location: index.php?accion=gestionar_profesores&mensaje=" . urlencode($mensaje));
    }
    

    private function mostrarProfesores($mensaje = '') {
        $profesores = $this->model->obtenerListaProfesores();
        require 'view/profesores.tpl'; // Nombre del archivo de la vista
    }

    private function volverHome() {
        header("Location: index.php");
        exit();
    }

    


    public function guardarProfesor() {
        if (isset($_POST['nombre']) && isset($_POST['apellido']) && isset($_POST['email']) && isset($_POST['pass']) && isset($_POST['telefono']) && isset($_POST['especialidad'])) {
            $nombre = $_POST['nombre'];
            $apellido = $_POST['apellido'];
            $email = $_POST['email'];
            $pass = $_POST['pass'];
            $telefono = $_POST['telefono'];
            $especialidad = $_POST['especialidad'];

            $resultado = $this->model->guardarProfesor($nombre, $apellido, $email, $pass, $telefono, $especialidad);

            if ($resultado) {
                header("Location: index.php?accion=gestionar_profesores");
                exit();
            } else {
                $this->view->assign('mensaje', 'Error al guardar el profesor.');
                $this->view->display('gestionarprofesores.tpl');
            }
        } else {
            $this->view->display('gestionarprofesores.tpl');
        }
    }

    public function gestionar_clases() {
        $clases = $this->model->obtenerClases();
        $profesores = $this->model->obtenerProfesores();
        $asignaturas = $this->model->obtenerAsignaturas();

        $this->view->assign('clases', $clases);
        $this->view->assign('profesores', $profesores);
        $this->view->assign('asignaturas', $asignaturas);

        $this->view->display('gestionarclases.tpl');
    }

    public function guardar_clase() {
        if (isset($_POST['nombre_clase']) && isset($_POST['grado']) && isset($_POST['id_profesor']) && isset($_POST['id_asignatura']) && isset($_POST['horario'])) {
            $nombre_clase = $_POST['nombre_clase'];
            $grado = $_POST['grado'];
            $id_profesor = $_POST['id_profesor'];
            $id_asignatura = $_POST['id_asignatura'];
            $horario = $_POST['horario'];
            $resultado = $this->model->guardarClase($nombre_clase, $grado, $id_profesor, $id_asignatura, $horario);
            if ($resultado) {
                header('Location: index.php?accion=gestionar_clases');
            } else {
                $this->view->assign('error', 'Error al guardar la clase.');
                $this->view->display('gestionarclases.tpl');
            }
        } else {
            $this->view->assign('error', 'Datos incompletos.');
            $this->view->display('gestionarclases.tpl');
        }
    }

    public function procesarGuardarAsignatura() {
        if (isset($_POST['nombre_asignatura']) && isset($_POST['descripcion_asignatura'])) {
            $nombre = $_POST['nombre_asignatura'];
            $descripcion = $_POST['descripcion_asignatura'];

            $resultado = $this->model->guardarAsignatura($nombre, $descripcion);
            if ($resultado) {
                $this->view->assign('mensaje', 'Asignatura guardada correctamente.');
            } else {
                $this->view->assign('mensaje', 'Error al guardar la asignatura.');
            }
            $this->view->display('adminhome.tpl');
        } else {
            $this->view->display('adminhome.tpl');
        }
    }

    public function autenticarAdministrador() {
        if (isset($_POST['email']) && isset($_POST['pass'])) {
            $email = $_POST['email'];
            $password = $_POST['pass'];

            $usuario = $this->model->autenticarAdministrador($email, $password);
            if ($usuario) {
                // Redirigir a la página de inicio del administrador
                $this->view->display('adminhome.tpl');
                exit();
            } else {
                $this->view->assign('mensaje', 'Credenciales incorrectas');
                $this->view->display('login.tpl');
            }
        } else {
            $this->view->assign('mensaje', 'Por favor ingrese todos los datos');
            $this->view->display('login.tpl');
        }
    }

    public function autenticarEstudiante() {
        if (isset($_POST['email']) && isset($_POST['pass'])) {
            $email = $_POST['email'];
            $password = $_POST['pass'];

            $usuario = $this->model->autenticarEstudiante($email, $password);
            if ($usuario) {
                // Redirigir a la página de inicio del estudiante
                $this->view->display('alumno.tpl');
                exit();
            } else {
                $this->view->assign('mensaje', 'Credenciales incorrectas');
                $this->view->display('loginestudiante.tpl');
            }
        } else {
            $this->view->assign('mensaje', 'Por favor ingrese todos los datos');
            $this->view->display('loginestudiante.tpl');
        }
    }

    public function autenticarProfesor() {
        if (isset($_POST['email']) && isset($_POST['pass'])) {
            $email = $_POST['email'];
            $password = $_POST['pass'];

            $usuario = $this->model->autenticarProfesor($email, $password);
            if ($usuario) {
                // Redirigir a la página de inicio del profesor
                $this->view->display('profesor.tpl');
                exit();
            } else {
                $this->view->assign('mensaje', 'Credenciales incorrectas');
                $this->view->display('loginprofesor.tpl');
            }
        } else {
            $this->view->assign('mensaje', 'Por favor ingrese todos los datos');
            $this->view->display('loginprofesor.tpl');
        }
    }

    public function eliminarClase() {
        if (isset($_POST['id_clase'])) {
            $id_clase = $_POST['id_clase'];
            $resultado = $this->model->eliminarClase($id_clase);
    
            if ($resultado) {
                $mensaje = "Clase eliminada exitosamente";
            } else {
                $mensaje = "Error al eliminar la clase";
            }
    
            // Redirigir con el mensaje
            header("Location: index.php?accion=gestionar_clases&mensaje=" . urlencode($mensaje));
        } else {
            // Si no se proporciona el ID de la clase, redirigir con un mensaje de error
            header("Location: index.php?accion=gestionar_clases&mensaje=" . urlencode("ID de clase no proporcionado"));
        }
    }
    
    
    public function verinfo() {
        $estudiantes = $this->model->obtenerInfoEstudiante();
        $this->view->assign('estudiantes', $estudiantes);
        $this->view->display('info.tpl');
    }
}
?>
