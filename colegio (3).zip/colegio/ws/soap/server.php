<?php

require_once "../conn/conn.php";

$tipo = $_SERVER['REQUEST_METHOD'];

switch($tipo){

   
     
    case 'GET':
        fn_lista_usuario();
        break;
    case 'BUSCAR':
        fn_get_usuario();
        break; 
    
       

    default:
        fn_error();
}



function fn_error(){
    header('HTTP/1.1 405 method not allowed');
}





function fn_lista_usuario(){
    header('HTTP/1.1 200 Correcto');
    $db = new conn();
    $db->conectar();

    $sql = "SELECT id_usuario, email, nombre, apellido, apellido2, pass FROM usuarios;";

    $rs =  $db->ejecutarSQL($sql);

    $datos =  array();

    while ($fila = $rs->fetch_assoc()) {
        $linea = array(); 
        $linea['id_usuario'] = $fila['id_usuario'];
            $linea['nombre'] = $fila['nombre'];
            $linea['apellido'] = $fila['apellido'];
            $linea['apellido2'] = $fila['apellido2'];
            $linea['pass'] = $fila['pass'];
            $linea['email'] = $fila['email'];
            $datos[] = $linea;
        }
    $db->desconectar();

    echo json_encode($datos);

}

function fn_get_usuario(){
    header('HTTP/1.1 200 Correcto');
    $db = new conn();
    $db->conectar();

    $id_usuario = $_REQUEST['id_usuario'];
    $sql = "SELECT id_usuario, email, nombre, apellido, apellido2, pass FROM usuarios where id_usuario=$id_usuario";

   

    $rs =  $db->ejecutarSQL($sql);

    $datos =  array();

    while ($fila = $rs->fetch_assoc()) {
        $linea = array(); 
        $linea['id_usuario'] = $fila['id_usuario'];
            $linea['nombre'] = $fila['nombre'];
            $linea['apellido'] = $fila['apellido'];
            $linea['apellido2'] = $fila['apellido2'];
            $linea['pass'] = $fila['pass'];
            $linea['email'] = $fila['email'];
        $datos[] = $linea;
    }
    $db->desconectar();

    echo json_encode($datos);

}

function  fn_borrar_usuario(){

        $id = $_REQUEST['id_usuario'];

        $db = new conn();
        $db->conectar();
        $sql = "delete from usuarios where ID_USUARIO=$id";
        $rs =  $db->ejecutarSQL($sql);
        $db->desconectar();
        echo 'Usuario borrado correctamente';
}

?>