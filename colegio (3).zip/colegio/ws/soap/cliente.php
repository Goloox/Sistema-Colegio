<?php
$uri = "http://localhost/progra3/progra3/proyecto/ws/soap/";
$cliente = new SoapClient(null, array('location' => $uri . 'server.php', 'uri' => $uri));

if (isset($_GET['id_usuario_b'])) {
    $idUsuario = $_GET['id_usuario_b'];
    echo $cliente->BorrarUsuario($idUsuario);
}

echo $cliente->ListarUsuarios();
?>
