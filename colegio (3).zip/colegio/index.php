<?php

require_once 'control/control.php';

$controller = new control();
$controller->gestor_procesos();
?>
