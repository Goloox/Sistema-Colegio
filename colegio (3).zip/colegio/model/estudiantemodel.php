<?php
require_once "conn/conn.php";
class Model {
    private $conn;

    public function __construct() {
        $this->conn = new conn(); // Assuming conn class handles the DB connection correctly
    }

    private function connect() {
        $this->conn->conectar();
    }

    private function disconnect() {
        $this->conn->desconectar();
    }

    public function autenticarestudiante($email, $pass) {
        $this->connect();
        $sql = "SELECT id_estudiante, nombre, apellido, fecha_nacimiento, grado, email, pass, telefono 
                FROM estudiantes 
                WHERE email = ? AND pass = ?";
        
        $stmt = $this->conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param('ss', $email, $pass);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $datos = $result->fetch_assoc() ?: [];
            $stmt->close();
        } else {
            error_log("Error preparing student authentication query: " . $this->conn->error);
        }
        
        $this->disconnect();
        return $datos;
    }

    public function obtenerProfesores() {
        $this->conn->conectar();
        $sql = "SELECT id_profesor, nombre, apellido FROM profesores";
        
        $stmt = $this->conn->prepare($sql);
        $profesores = [];
        if ($stmt) {
            $stmt->execute();
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()) {
                $profesores[] = $row;
            }
            $stmt->close();
        } else {
            error_log("Error preparing professors query: " . $this->conn->error);
        }
        
        $this->conn->desconectar();
        return $profesores;
    }
    

    public function obtenerClasePorId($id_clase) {
        $this->conn->conectar();
        $sql = "SELECT id_clase, nombre, grado, id_profesor, id_asignatura, horario 
                FROM clases 
                WHERE id_clase = ?";
        
        $stmt = $this->conn->prepare($sql);
        $clase = null;
        if ($stmt) {
            $stmt->bind_param('i', $id_clase);
            $stmt->execute();
            $result = $stmt->get_result();
            $clase = $result->fetch_assoc();
            $stmt->close();
        } else {
            error_log("Error preparing class query: " . $this->conn->error);
        }
        
        $this->conn->desconectar();
        return $clase;
    }
    public function registrarEstudiante($nombre, $apellido, $fecha_nacimiento, $grado, $email, $pass, $telefono) {
        $sql = "INSERT INTO estudiantes (nombre, apellido, fecha_nacimiento, grado, email, pass, telefono)
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sssssss", $nombre, $apellido, $fecha_nacimiento, $grado, $email, $pass, $telefono);
        return $stmt->execute();
    }
    public function obtenerInfoProfesor($id_profesor) {
        $this->conn->conectar();
        $sql = "SELECT id_profesor, nombre, apellido, especialidad, email, pass, telefono 
                FROM profesores 
                WHERE id_profesor = ?";
        
        $stmt = $this->conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param('i', $id_profesor);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $profesor = null;
            if ($fila = $result->fetch_assoc()) {
                $profesor = $fila;
            }
            
            $stmt->close();
        } else {
            error_log("Error preparando la consulta para obtener información del profesor: " . $this->conn->error);
        }
        
        $this->conn->desconectar();
        return $profesor;
    }

  

    public function obtenerInfoEstudiante($id_estudiante) {
        $stmt = $this->conn->prepare("SELECT nombre, apellido, email, telefono,grado,fecha_nacimiento, id_estudiante,pass FROM estudiantes WHERE id_estudiante = ?");
        $stmt->bind_param("i", $id_estudiante);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $estudiante = $resultado->fetch_assoc();
        $stmt->close();
        return $estudiante;
    }
    
    

    public function obtenerEstudiantesPorClase($id_clase) {
        $sql = "SELECT e.id_estudiante, e.nombre, e.apellido, e.fecha_nacimiento, e.grado, e.email, e.telefono
                FROM estudiantes e 
                INNER JOIN estudiantes_clases ec ON e.id_estudiante = ec.id_estudiante 
                WHERE ec.id_clase = ?";
        
        $stmt = $this->conn->prepare($sql);
        if (!$stmt) {
            die("Prepare failed: " . $this->conn->error);
        }
    
        $stmt->bind_param("i", $id_clase);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $estudiantes = [];
        while ($row = $result->fetch_assoc()) {
            $estudiantes[] = $row;
        }
        
        $stmt->close();
        return $estudiantes;
    }

    public function obtenerClases() {
        $this->conn->conectar();
        $query = "SELECT id_clase, nombre, grado, id_profesor, id_asignatura, horario FROM clases";
        $stmt = $this->conn->prepare($query);
        $clases = [];
        
        if ($stmt) {
            $stmt->execute();
            $result = $stmt->get_result();
            
            while ($row = $result->fetch_assoc()) {
                $clases[] = $row;
            }
            
            $stmt->close();
        } else {
            error_log("Error preparando la consulta para clases: " . $this->conn->error);
        }
        
        $this->conn->desconectar();
        return $clases;
    }

    public function obtenerClasesProfesor($id_profesor) {
        $query = "SELECT id_clase, nombre, grado, id_asignatura, horario FROM clases WHERE id_profesor = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $id_profesor);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC); // Fetch all classes as an associative array
    }
    public function matricularEstudianteEnClase($id_estudiante, $id_clase) {
        $this->connect();
        
        // Verificar si la relación ya existe
        $sql = "SELECT COUNT(*) FROM estudiantes_clases WHERE id_estudiante = ? AND id_clase = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param('ii', $id_estudiante, $id_clase);
        $stmt->execute();
        $result = $stmt->get_result();
        $count = $result->fetch_column();
        $stmt->close();
        
        if ($count > 0) {
            // Ya existe la relación
            $this->disconnect();
            return false; // O cualquier otro valor que indique un fallo
        }
        
        // Insertar nueva relación
        $sql = "INSERT INTO estudiantes_clases (id_estudiante, id_clase) VALUES (?, ?)";
        $stmt = $this->conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param('ii', $id_estudiante, $id_clase);
            $resultado = $stmt->execute();
            $stmt->close();
        } else {
            error_log("Error preparando la consulta para matricular: " . $this->conn->error);
            $resultado = false;
        }
        
        $this->disconnect();
        return $resultado;
    }
    public function obtenerClasesPorEstudiante($id_estudiante) {
        $this->conn->conectar();
        $sql = "SELECT 
                    c.id_clase, 
                    c.nombre, 
                    c.grado, 
                    c.horario,
                    ec.calificacion,
                    ec.tardias
                FROM clases c
                INNER JOIN estudiantes_clases ec ON c.id_clase = ec.id_clase
                WHERE ec.id_estudiante = ?";
        
        $stmt = $this->conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param('i', $id_estudiante);
            $stmt->execute();
            $result = $stmt->get_result();
            $clases = [];
            while ($row = $result->fetch_assoc()) {
                $clases[] = $row;
            }
            $stmt->close();
        } else {
            error_log("Error preparando la consulta para obtener clases del estudiante: " . $this->conn->error);
        }
        
        $this->conn->desconectar();
        return $clases;
    }
}    