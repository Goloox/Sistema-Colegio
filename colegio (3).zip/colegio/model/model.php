<?php
require_once "conn/conn.php";

class Model {
    private $conn;

    public function __construct() {
        $this->conn = new conn(); // Suponiendo que la clase conn maneja correctamente la conexión a la base de datos
    }

   
    public function autenticarAdministrador($email, $password) {
        $this->conn->conectar();
        $sql = "SELECT id, nombre, apellido, email, password, fecha_creacion 
                FROM administradores 
                WHERE email = ? AND password = ?";
        
        $stmt = $this->conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param('ss', $email, $password);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $datos = array();
            if ($fila = $result->fetch_assoc()) {
                $datos = $fila;
            }
            
            $stmt->close();
        } else {
            error_log("Error preparando la consulta para administradores: " . $this->conn->error);
        }
        
        $this->conn->desconectar();
        return $datos;
    }
    
    public function autenticarProfesor($email, $password) {
        $this->conn->conectar();
        $sql = "SELECT id_profesor, nombre, apellido, especialidad, email, pass, telefono 
                FROM profesores 
                WHERE email = ? AND pass = ?";
        
        $stmt = $this->conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param('ss', $email, $password);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $datos = array();
            $usuario = null;
            if ($fila = $result->fetch_assoc()) {
                $datos = $fila;
                $id_usuario = $fila['id_profesor'];
            }
            
            $stmt->close();
        } else {
            error_log("Error preparando la consulta para profesores: " . $this->conn->error);
        }
        
        $this->conn->desconectar();
        return $datos;
    }
    public function obtenerInfoEstudiante() {
        $stmt = $this->conn->prepare("SELECT nombre, apellido, email, telefono, grado, fecha_nacimiento, id_estudiante, pass FROM estudiantes");
        // No es necesario usar bind_param() ya que no hay parámetros en la consulta
        $stmt->execute();
        $resultado = $stmt->get_result();
        $estudiantes = [];
        
        while ($estudiante = $resultado->fetch_assoc()) {
            $estudiantes[] = $estudiante;
        }
        
        $stmt->close();
        return $estudiantes;
    }
    
    public function autenticarEstudiante($email, $password) {
        $this->conn->conectar();
        $sql = "SELECT id_estudiante, nombre, apellido, fecha_nacimiento, grado, email, pass, telefono 
                FROM estudiantes 
                WHERE email = ? AND pass = ?";
        
        $stmt = $this->conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param('ss', $email, $password);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $datos = array();
            if ($fila = $result->fetch_assoc()) {
                $datos = $fila;
                $id_usuario = $fila['id_estudiante'];
            }
            
            $stmt->close();
        } else {
            error_log("Error preparando la consulta para estudiantes: " . $this->conn->error);
        }
        
        $this->conn->desconectar();
        return $datos;
    }

    public function obtenerClases() {
        $query = "SELECT id_clase, nombre, grado, id_profesor, id_asignatura, horario FROM clases";
        $stmt = $this->conn->prepare($query);
        if ($stmt) {
            $stmt->execute();
            $result = $stmt->get_result();
            $clases = [];
            while ($row = $result->fetch_assoc()) {
                $clases[] = $row;
            }
            $stmt->close();
            return $clases;
        } else {
            error_log("Error preparando la consulta para clases: " . $this->conn->error);
            return [];
        }
    }

    public function obtenerAsignaturas() {
        $query = "SELECT id_asignatura, nombre, descripcion FROM asignaturas";
        $stmt = $this->conn->prepare($query);
        if ($stmt) {
            $stmt->execute();
            $result = $stmt->get_result();
            $asignaturas = [];
            while ($row = $result->fetch_assoc()) {
                $asignaturas[] = $row;
            }
            $stmt->close();
            return $asignaturas;
        } else {
            error_log("Error preparando la consulta para asignaturas: " . $this->conn->error);
            return [];
        }
    }

    public function obtenerProfesores() {
        $query = "SELECT id_profesor AS id, nombre FROM profesores";
        $stmt = $this->conn->prepare($query);
        if ($stmt) {
            $stmt->execute();
            $result = $stmt->get_result();
            $profesores = [];
            while ($row = $result->fetch_assoc()) {
                $profesores[] = $row;
            }
            $stmt->close();
            return $profesores;
        } else {
            error_log("Error preparando la consulta para profesores: " . $this->conn->error);
            return [];
        }
    }

    public function guardarClase($nombre, $grado, $id_profesor, $id_asignatura, $horario) {
        $query = "INSERT INTO clases (nombre, grado, id_profesor, id_asignatura, horario) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        if ($stmt) {
            $stmt->bind_param('siisi', $nombre, $grado, $id_profesor, $id_asignatura, $horario);
            $result = $stmt->execute();
            $stmt->close();
            return $result;
        } else {
            error_log("Error preparando la consulta para guardar clase: " . $this->conn->error);
            return false;
        }
    }

    public function eliminarClase($id_clase) {
        $id_clase = (int)$id_clase; // Sanitizar el ID
        $sql = "DELETE FROM clases WHERE id_clase = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id_clase);
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }

    
    public function obtenerClasesE() {
        $query = "SELECT id_clase, nombre FROM clases";
        $result = $this->db->query($query);
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
   
    public function obtenerEstudiantesPorClase($id_clase) {
        $query = "
            SELECT e.id_estudiante, e.nombre, e.apellido, e.email
            FROM estudiantes e
            JOIN inscripciones i ON e.id_estudiante = i.id_estudiante
            WHERE i.id_clase = ?";
        
        // Preparar la consulta
       

        if ($stmt === false) {
            die("Error en la preparación de la consulta: " . $this->db->error);
        }

        // Vincular parámetros
        $stmt->bind_param('i', $id_clase);

        // Ejecutar la consulta
        $stmt->execute();

        // Obtener el resultado
        $result = $stmt->get_result();
        
        if ($result === false) {
            die("Error al obtener el resultado: " . $this->db->error);
        }

        // Obtener todos los datos como un array asociativo
        $estudiantes = $result->fetch_all(MYSQLI_ASSOC);

        // Cerrar la declaración
        $stmt->close();

        return $estudiantes;
    }
    public function mostrarClases($mensaje = "") {
        $clases = $this->model->obtenerClases(); // Método para obtener las clases
        $profesores = $this->model->obtenerProfesores(); // Método para obtener los profesores
        $asignaturas = $this->model->obtenerAsignaturas(); // Método para obtener las asignaturas
        
        // Asignar datos a la vista
        $smarty->assign('clases', $clases);
        $smarty->assign('profesores', $profesores);
        $smarty->assign('asignaturas', $asignaturas);
        $smarty->assign('mensaje', $mensaje);
        
        // Mostrar la plantilla
        $smarty->display('tu_plantilla.tpl');
    }
    

    public function guardarProfesor($nombre, $apellido, $email, $pass, $telefono, $especialidad) {
        $query = "INSERT INTO profesores (nombre, apellido, email, pass, telefono, especialidad) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        if ($stmt) {
            $stmt->bind_param('ssssss', $nombre, $apellido, $email, $pass, $telefono, $especialidad);
            $result = $stmt->execute();
            $stmt->close();
            return $result;
        } else {
            error_log("Error preparando la consulta para guardar profesor: " . $this->conn->error);
            return false;
        }
    }

    public function guardarAsignatura($nombre, $descripcion) {
        $query = "INSERT INTO asignaturas (nombre, descripcion) VALUES (?, ?)";
        $stmt = $this->conn->prepare($query);
        if ($stmt) {
            $stmt->bind_param('ss', $nombre, $descripcion);
            $result = $stmt->execute();
            $stmt->close();
            return $result;
        } else {
            error_log("Error preparando la consulta para guardar asignatura: " . $this->conn->error);
            return false;
        }
    }

    public function obtenerEstudiantes() {
        $query = "SELECT id_estudiante, nombre, apellido, email FROM estudiantes";
        $stmt = $this->conn->prepare($query);
        if ($stmt) {
            $stmt->execute();
            $result = $stmt->get_result();
            $estudiantes = [];
            while ($row = $result->fetch_assoc()) {
                $estudiantes[] = $row;
            }
            $stmt->close();
            return $estudiantes;
        } else {
            error_log("Error preparando la consulta para estudiantes: " . $this->conn->error);
            return [];
        }
    }

    public function guardarEstudiante($nombre, $apellido, $email, $pass, $grado) {
        $query = "INSERT INTO estudiantes (nombre, apellido, email, pass, grado) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        if ($stmt) {
            $stmt->bind_param('sssss', $nombre, $apellido, $email, $pass, $grado);
            $result = $stmt->execute();
            $stmt->close();
            return $result;
        } else {
            error_log("Error preparando la consulta para guardar estudiante: " . $this->conn->error);
            return false;
        }
    }

    public function actualizarEstudiante($id, $nombre, $apellido, $email, $pass, $grado) {
        $query = "UPDATE estudiantes SET nombre = ?, apellido = ?, email = ?, pass = ?, grado = ? WHERE id_estudiante = ?";
        $stmt = $this->conn->prepare($query);
        if ($stmt) {
            $stmt->bind_param('sssssi', $nombre, $apellido, $email, $pass, $grado, $id);
            $result = $stmt->execute();
            $stmt->close();
            return $result;
        } else {
            error_log("Error preparando la consulta para actualizar estudiante: " . $this->conn->error);
            return false;
        }
    }

    public function obtenerListaProfesores() {
        $this->conn->conectar();
    
        $sql = "SELECT id_profesor, nombre, apellido, especialidad, email, telefono FROM profesores";
        
        $result = $this->conn->ejecutarSQL($sql);
    
        $profesores = [];
        
        if ($result) {
            while ($fila = $result->fetch_assoc()) {
                $profesores[] = $fila;
            }
        } else {
            error_log("Error al obtener la lista de profesores: " . $this->conn->getConexion()->error);
        }
    
        $this->conn->desconectar();
    
        return $profesores;
    }
    

    public function actualizarProfesor($id, $nombre, $apellido, $email, $pass, $telefono, $especialidad) {
        // Preparar la consulta SQL
        $sql = "UPDATE profesores 
                SET nombre = ?, apellido = ?, email = ?, pass = ?, telefono = ?, especialidad = ? 
                WHERE id_profesor = ?";
    
        // Preparar la consulta
        $stmt = $this->conn->prepare($sql);
    
        if ($stmt) {
            // Bind parameters
            $stmt->bind_param("ssssssi", $nombre, $apellido, $email, $pass, $telefono, $especialidad, $id);
    
            // Ejecutar la consulta
            $result = $stmt->execute();
    
            // Verificar el resultado
            if ($result) {
                $stmt->close();
                return true;
            } else {
                error_log("Error al actualizar el profesor: " . $stmt->error);
                $stmt->close();
                return false;
            }
        } else {
            error_log("Error al preparar la consulta para actualizar profesor: " . $this->conn->getConexion()->error);
            return false;
        }
    }
   
  

    public function eliminarProfesor($id_profesor) {
        $sql = "DELETE FROM profesores WHERE id_profesor = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id_profesor);
        return $stmt->execute();
    }
    
    // Método para obtener la información de un profesor específico por su ID
    public function obtenerInfoProfesor($id_profesor) {
        $this->conn->conectar();

        $sql = "SELECT id_profesor, nombre, apellido, especialidad, email, telefono 
                FROM profesores 
                WHERE id_profesor = ?";
        
        $stmt = $this->conn->prepare($sql);
        $profesor = null;

        if ($stmt) {
            $stmt->bind_param('i', $id_profesor);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($fila = $result->fetch_assoc()) {
                $profesor = $fila;
            }
            
            $stmt->close();
        } else {
            error_log("Error preparando la consulta para obtener información del profesor: " . $this->conn->error);
        }

        $this->conn->desconectar();

        return $profesor;
    }
    

    public function eliminarEstudiante($id_estudiante) {
        // Eliminar las relaciones en estudiantes_clases primero
        $query = "DELETE FROM estudiantes_clases WHERE id_estudiante = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $id_estudiante);
        $stmt->execute();
    
        // Luego, eliminar el estudiante
        $query = "DELETE FROM estudiantes WHERE id_estudiante = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $id_estudiante);
        $stmt->execute();
    }
    
    
}
