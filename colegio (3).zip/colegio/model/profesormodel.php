<?php
require_once "conn/conn.php";

class Model {
    private $conn;

    public function __construct() {
        $this->conn = new conn(); // Assuming conn class handles the DB connection correctly
    }

    public function autenticarProfesor($email, $pass) {
        $this->conn->conectar();
        $sql = "SELECT id_profesor, nombre, apellido, especialidad, email, pass, telefono 
                FROM profesores 
                WHERE email = ? AND pass = ?";
        
        $stmt = $this->conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param('ss', $email, $pass);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $datos = array();
            if ($fila = $result->fetch_assoc()) {
                $datos = $fila;
            }
            
            $stmt->close();
        } else {
            error_log("Error preparando la consulta para profesores: " . $this->conn->error);
        }
        
        $this->conn->desconectar();
        return $datos;
    }


    public function obtenerClasePorId($id_clase) {
        $this->conn->conectar();
        $sql = "SELECT id_clase, nombre AS nombre_clase, grado, id_profesor, id_asignatura, horario
                FROM clases
                WHERE id_clase = ?";
        
        $stmt = $this->conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param('i', $id_clase);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $datos = array();
            if ($fila = $result->fetch_assoc()) {
                $datos = $fila;
            }
            
            $stmt->close();
        } else {
            error_log("Error preparando la consulta para clase: " . $this->conn->error);
        }
        
        $this->conn->desconectar();
        return $datos;
    }
    
    public function obtenerInfoProfesor($id_profesor) {
        $this->conn->conectar();
        $sql = "SELECT id_profesor, nombre, apellido, especialidad, email, pass, telefono 
                FROM profesores 
                WHERE id_profesor = ?";
        
        $stmt = $this->conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param('i', $id_profesor);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $profesor = null;
            if ($fila = $result->fetch_assoc()) {
                $profesor = $fila;
            }
            
            $stmt->close();
        } else {
            error_log("Error preparando la consulta para obtener información del profesor: " . $this->conn->error);
        }
        
        $this->conn->desconectar();
        return $profesor;
    }


    public function verEstudiantes() {
        $id_clase = $_REQUEST['id_clase'] ?? 0;
        
        if ($id_clase) {
            $estudiantes = $this->model->obtenerEstudiantesPorClase($id_clase);
            $this->view->assign('estudiantes', $estudiantes);
            $this->view->display('estudiantes.tpl');
        } else {
            $this->view->assign('error', 'No se especificó ninguna clase.');
            $this->view->display('error.tpl'); // Template to display error message
        }
    }
    public function actualizarCalificacionTardias($id_estudiante, $id_clase, $calificacion = null, $tardias = null) {
        $this->conn->conectar();
        
        $sql = "UPDATE estudiantes_clases SET ";
        $params = [];
        $types = "";
        
        if ($calificacion !== null) {
            $sql .= "calificacion = ?, ";
            $params[] = $calificacion;
            $types .= "i";
        }
        
        if ($tardias !== null) {
            $sql .= "tardias = ?, ";
            $params[] = $tardias;
            $types .= "i";
        }
        
        // Remove the trailing comma and space
        $sql = rtrim($sql, ", ") . " WHERE id_estudiante = ? AND id_clase = ?";
        $params[] = $id_estudiante;
        $params[] = $id_clase;
        $types .= "ii";
        
        $stmt = $this->conn->prepare($sql);
        if (!$stmt) {
            die("Prepare failed: " . $this->conn->error);
        }
        
        $stmt->bind_param($types, ...$params);
        
        if (!$stmt->execute()) {
            die("Execute failed: " . $stmt->error);
        }
    
        $stmt->close();
        $this->conn->desconectar();
    }
    
    public function actualizarDatosEstudiante() {
        if (isset($_POST['id_estudiante'], $_POST['id_clase'], $_POST['calificacion'], $_POST['tardias'])) {
            $id_estudiante = $_POST['id_estudiante'];
            $id_clase = $_POST['id_clase']; // Agregado para id_clase
            $calificacion = $_POST['calificacion'];
            $tardias = $_POST['tardias'];
    
            $resultado = $this->model->actualizarCalificacionTardias($id_estudiante, $id_clase, $calificacion, $tardias);
    
            if ($resultado) {
                $_SESSION['mensaje'] = 'Datos del estudiante actualizados con éxito.';
            } else {
                $_SESSION['error'] = 'No se pudo actualizar los datos del estudiante.';
            }
    
            header('Location: ?accion=verestudiantes&id_clase=' . urlencode($id_clase));
            exit();
        } else {
            $_SESSION['error'] = 'Faltan datos para actualizar el estudiante.';
            $this->view->display('error.tpl');
        }
    }
    


    public function obtenerEstudiantesPorClase($id_clase) {
        $sql = "SELECT e.id_estudiante, e.nombre, e.apellido, e.email, ec.calificacion, ec.tardias 
                FROM estudiantes e 
                INNER JOIN estudiantes_clases ec ON e.id_estudiante = ec.id_estudiante 
                WHERE ec.id_clase = ?";
        
        $stmt = $this->conn->prepare($sql);
        if (!$stmt) {
            die("Prepare failed: " . $this->conn->error);
        }
    
        $stmt->bind_param("i", $id_clase);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $estudiantes = [];
        while ($row = $result->fetch_assoc()) {
            $estudiantes[] = $row;
        }
        
        $stmt->close();
        return $estudiantes; // Corrección del nombre de la variable de retorno
    }
    
    public function obtenerClasesProfesor($id_profesor) {
        $query = "SELECT id_clase, nombre, grado, id_asignatura, horario FROM clases WHERE id_profesor = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $id_profesor);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC); // Fetch all classes as an associative array
    }
    // Método para actualizar la calificación de un estudiante en una clase
    public function actualizarCalificacion($id_estudiante, $id_clase, $calificacion) {
        $calificacion = max(0, min(100, $calificacion)); // Asegura que la calificación esté entre 0 y 100
        $query = "UPDATE `estudiantes_clases` SET `calificacion` = ? WHERE `id_estudiante` = ? AND `id_clase` = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("iii", $calificacion, $id_estudiante, $id_clase);
        return $stmt->execute();
    }

    // Método para agregar una tardía a un estudiante en una clase
    public function agregarTardia($id_estudiante, $id_clase) {
        $query = "UPDATE estudiantes_clases SET tardias = tardias + 1 WHERE id_estudiante = ? AND id_clase = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $id_estudiante, $id_clase);
        return $stmt->execute();
    }
    public function actualizarEstudiante($id_estudiante, $calificacion, $tardias) {
        $query = "UPDATE estudiantes_clases 
                  SET calificacion = ?, tardias = ? 
                  WHERE id_estudiante = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("iii", $calificacion, $tardias, $id_estudiante);
        return $stmt->execute();
    }
}    
    


?>