<?php

require_once 'control/estudiantecontrol.php';

$controller = new control();
$controller->gestor_procesos();
?>
