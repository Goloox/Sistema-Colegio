function js_cargarlista_usuarios(){


    var settings = {
      "url": "ws/soap/server.php",
      "method": "GET",
      "timeout": 0,
      dataType: 'json',
    };
    
    $.ajax(settings).done(function (response) {
     
  
      var len = response.length;
  
  
      for( var i = 0; i<len; i++){
        var id = response[i]['id_usuario'];
  
        var name = response[i]['nombre'] + ' '+response[i]['apellido']+ ' '+response[i]['apellido2'] ;
        
        $("#LST_USUARIOS").append("<option value='"+id+"'>"+name+"</option>");
        
        }
    });
  
  }